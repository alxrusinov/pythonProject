import { ComponentProps, ReactNode } from 'react';

import {
  DataService,
  ErrorBoundary,
  Icons,
  SettingPanel,
} from 'shared_ui/components';
import { IDataServiceInitialConfig } from 'shared_ui/components/DataService';

interface CalculationFilterProviderProps {
  config: IDataServiceInitialConfig;
  children: ReactNode;
  scope: string;
}

const settingPanelModel: ComponentProps<typeof SettingPanel>['model'] = [
  {
    icon: <Icons.Filter.Md />,
    title: 'Фильтр',
    subTitle: 'Выбор условий расчета',
    component: (
      <ErrorBoundary>
        <DataService.Filter.FilterSidebar />
      </ErrorBoundary>
    ),
  },
  {
    icon: <Icons.Settings.Slider.Md />,
    title: 'Атрибуты',
    subTitle: 'Выбор атрибутов для таблицы',
    component: (
      <ErrorBoundary>
        <DataService.Attributes.AttributesSidebar />
      </ErrorBoundary>
    ),
  },
];

export const CalculationFilterProvider = ({
  config,
  children,
  scope,
}: CalculationFilterProviderProps) => {
  return (
    <DataService.DataServiceProvider scope={scope} config={config}>
      <div className="flex gap-2 flex-row align-items-stretch w-full">
        <div className="flex flex-grow-1 flex-column w-full overflow-auto">
          {children}
        </div>
        <SettingPanel model={settingPanelModel} />
      </div>
    </DataService.DataServiceProvider>
  );
};
