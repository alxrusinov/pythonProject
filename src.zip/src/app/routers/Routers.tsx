import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';

import { Progress } from 'shared_ui/components';

import { CreateInstruction } from 'pages/CreateInstruction';
import { CreateInstructionType } from 'pages/CreateInstructionType';
import { CreateOrgEmail } from 'pages/CreateOrgEmail';
import { DeleteOrgEmail } from 'pages/DeleteOrgEmail';
import { EditInstruction } from 'pages/EditInstruction';
import { EditInstructionType } from 'pages/EditInstructionType';
import { EditOrgEmail } from 'pages/EditOrgEmail';
import { InstructionTablePage } from 'pages/InstructionTablePage';
import { InstructionTemplatesTablePage } from 'pages/InstructionTemplatesTablePage';
import { OrgEmailsTablePage } from 'pages/OrgEmailsTablePage';

import { MainNavigate } from 'widgets/MainNavigate';

import { paths } from 'shared/routes/paths';

export const CreateInstructionLazy = lazy(() =>
  import('pages/CreateInstruction').then(module => ({
    default: module.CreateInstruction,
  })),
);
export const CreateInstructionTypeLazy = lazy(() =>
  import('pages/CreateInstructionType').then(module => ({
    default: module.CreateInstructionType,
  })),
);
export const EditInstructionLazy = lazy(() =>
  import('pages/EditInstruction').then(module => ({
    default: module.EditInstruction,
  })),
);
export const EditInstructionTypeLazy = lazy(() =>
  import('pages/EditInstructionType').then(module => ({
    default: module.EditInstructionType,
  })),
);

export const Routers = () => {
  const location = useLocation();

  return (
    <Suspense fallback={<Progress />}>
      <div className="flex flex-column flex-1 min-h-0 h-full overflow-hidden">
        <Routes>
          <Route path="/" element={<MainNavigate />}>
            <Route index element={<Navigate to={paths.carInstructions} />} />
            <Route
              path={paths.carInstructionTemplates}
              element={<InstructionTemplatesTablePage />}
            />
            <Route
              path={paths.carInstructions}
              element={<InstructionTablePage />}
            />
            <Route path={paths.orgEmails} element={<OrgEmailsTablePage />} />
          </Route>
          <Route
            path={paths.createInstructionTemplate}
            element={
              <CreateInstructionType
                key={`${location.pathname}${location.search}`}
              />
            }
          />
          <Route
            path={paths.editInstructionTemplate}
            element={
              <EditInstructionType
                key={`${location.pathname}${location.search}`}
              />
            }
          />
          <Route
            path={paths.createInstruction}
            element={
              <CreateInstruction
                key={`${location.pathname}${location.search}`}
              />
            }
          />
          <Route
            path={paths.editInstruction}
            element={
              <EditInstruction key={`${location.pathname}${location.search}`} />
            }
          />
          <Route
            path={paths.createOrgEmail}
            element={<CreateOrgEmail key={location.pathname} />}
          />
          <Route
            path={paths.editOrgEmail}
            element={<EditOrgEmail key={location.pathname} />}
          />
          <Route
            path={paths.deleteOrgEmail}
            element={<DeleteOrgEmail key={location.pathname} />}
          />
        </Routes>
      </div>
    </Suspense>
  );
};
