import { InstructionForm } from 'widgets/InstructionForm';

import { InstructionFormLayout } from 'shared/ui/InstructionFormLayout';

export const EditInstruction = () => {
  return (
    <InstructionFormLayout>
      <InstructionForm />
    </InstructionFormLayout>
  );
};
