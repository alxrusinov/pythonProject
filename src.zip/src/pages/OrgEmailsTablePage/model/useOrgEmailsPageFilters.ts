import { useCallback, useState } from 'react';

import { FilterMatchMode, FilterOperator } from 'shared_ui/api';
import { DataTableStateEvent } from 'shared_ui/primereact';

import { FilterMeta } from 'widgets/CustomTable';

import type { OrgEmailTableData } from './useOrgEmailsPage';

const STORAGE_KEY = 'org-emails-table-filters';

const defaultFilters: FilterMeta<OrgEmailTableData> = {
  global: { value: null, matchMode: FilterMatchMode.CONTAINS },
  organizationName: { value: null, matchMode: FilterMatchMode.IN },
  email: { value: null, matchMode: FilterMatchMode.IN },
  orgId: { value: null, matchMode: FilterMatchMode.IN },
  dateFrom: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
  dateTo: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
};

function loadFilters(): FilterMeta<OrgEmailTableData> {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as FilterMeta<OrgEmailTableData>;
  } catch {
    /* ignore */
  }
  return defaultFilters;
}

function saveFilters(filters: FilterMeta<OrgEmailTableData>) {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(filters));
  } catch {
    /* ignore */
  }
}

export const useOrgEmailsPageFilters = () => {
  const [filters, setFilters] =
    useState<FilterMeta<OrgEmailTableData>>(loadFilters);

  const clearFilters = () => {
    const clean = { ...defaultFilters };
    setFilters(clean);
    saveFilters(clean);
  };

  const onGlobalFilterChange = useCallback((value: string) => {
    setFilters(prev => {
      const next = {
        ...prev,
        global: { value, matchMode: FilterMatchMode.CONTAINS },
      };
      saveFilters(next);
      return next;
    });
  }, []);

  const onFilterChange = useCallback((e: DataTableStateEvent) => {
    setFilters(e.filters);
    saveFilters(e.filters as FilterMeta<OrgEmailTableData>);
  }, []);

  const globalFilterValue =
    (filters.global as { value: string | null })?.value ?? '';

  return {
    filters,
    globalFilterValue,
    clearFilters,
    onGlobalFilterChange,
    onFilterChange,
  };
};
