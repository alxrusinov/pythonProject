import {
  IrcOrgEmail,
  IrcOrgEmailFilterInput,
  IrcOrgEmailsForTableQuery,
  IrcOrgEmailsForTableQueryVariables,
  useIrcOrgEmailsForTableLazyQuery,
} from 'graphql/generated/generated';
import { useContext, useEffect, useMemo } from 'react';

import { useApolloLazyQueryPage } from 'core_client/apollo';

import { DataService } from 'shared_ui/components';

import { ColumnsMetaDataType } from 'widgets/InstructionTableTemplate/lib/types';

import { getStableRequestDate } from 'shared/utils/date';
import { transformData } from 'shared/utils/transformData';

import { orgEmailsColumnsMetaConfig } from '../lib/orgEmailsColumnsMetaConfig';

export type OrgEmailTableData = Omit<
  IrcOrgEmail,
  'dateFrom' | 'dateTo' | 'id'
> & {
  id: string;
  orgId?: number | null;
  organizationName?: string;
  dateFrom?: Date | null;
  dateTo?: Date | null;
};

type UseOrgEmailsPageOptions = {
  requestDate?: Date;
};

function getOrgEmailsTableColumns(): ColumnsMetaDataType<OrgEmailTableData>[] {
  return orgEmailsColumnsMetaConfig.fields
    .filter(
      (f): f is typeof f & { table: NonNullable<typeof f.table> } =>
        f.table != null,
    )
    .map((f, index) => ({
      ...f.table,
      field: f.name as Extract<keyof OrgEmailTableData, string>,
      header: f.table?.header ?? f.displayName,
      index,
    }));
}

export const useOrgEmailsPage = (options: UseOrgEmailsPageOptions) => {
  const { filtersWhereGraphQLStatement } = useContext(
    DataService.DataServiceContext,
  );

  const { tableColumns: orgEmailsColumnsMetaDataFromContext } = useContext(
    DataService.DataServiceContext,
  );

  const where = useMemo((): IrcOrgEmailFilterInput => {
    const base = (filtersWhereGraphQLStatement ?? {}) as IrcOrgEmailFilterInput;
    return base;
  }, [filtersWhereGraphQLStatement]);

  const extractData = (
    data: IrcOrgEmailsForTableQuery | undefined | null,
  ): IrcOrgEmailsForTableQuery['ircOrgEmails'] | undefined =>
    data?.ircOrgEmails;

  const [getOrgEmails] = useIrcOrgEmailsForTableLazyQuery();
  const {
    items: rawItems,
    loading,
    load,
  } = useApolloLazyQueryPage({
    pageSize: 100,
    total: 1000,
    extractData,
    lazyQuery: getOrgEmails,
  });

  useEffect(() => {
    if (
      !filtersWhereGraphQLStatement ||
      Object.keys(filtersWhereGraphQLStatement).length === 0
    ) {
      return;
    }
    const variables: IrcOrgEmailsForTableQueryVariables = {
      where,
      requestDate:
        options?.requestDate?.toISOString() ?? getStableRequestDate(),
    };
    load({
      variables,
      fetchPolicy: 'no-cache',
    });
  }, [filtersWhereGraphQLStatement, where, options?.requestDate]);

  const orgEmailsColumnsMetaData =
    (orgEmailsColumnsMetaDataFromContext?.length
      ? orgEmailsColumnsMetaDataFromContext
      : getOrgEmailsTableColumns()) ?? getOrgEmailsTableColumns();

  const transformedData = useMemo((): OrgEmailTableData[] => {
    const items = transformData<IrcOrgEmail, 'dateFrom' | 'dateTo', never>({
      data: (rawItems || []) as IrcOrgEmail[],
      fieldsToConvertDate: ['dateFrom', 'dateTo'],
    });
    return items.map((item): OrgEmailTableData => {
      const orgLabel =
        item.organization?.shortName || item.organization?.name || '';
      return {
        ...item,
        id: String(item.id ?? ''),
        orgId: item.organization?.id ?? null,
        organizationName: orgLabel,
      };
    });
  }, [rawItems]);

  return {
    orgEmailsColumnsMetaData:
      orgEmailsColumnsMetaData as ColumnsMetaDataType<OrgEmailTableData>[],
    transformedData,
    loading,
  };
};
