import { useRef } from 'react';
import { generatePath, useNavigate } from 'react-router-dom';

import {
  DataTableRowEvent,
  DataTableSelectionSingleChangeEvent,
  DataTableValueArray,
  IContextMenuRef,
} from 'shared_ui/components';
import {
  DataTableContextMenuSelectionChangeEvent,
  DataTableRowClickEvent,
} from 'shared_ui/primereact';

import { useOrgEmailSelected } from 'widgets/ActionPanel/store/OrgEmailSelected';

import { useClearSelectedRows } from 'shared/hooks/useClearSelectedRows';
import { paths } from 'shared/routes/paths';
import { OrgEmailModels } from 'shared/types/common';
import { buildPath } from 'shared/utils/buildPath';

const toRequestDateTimestamp = (date: Date) => date.getTime();

export type UseOrgEmailsTableOptions = {
  requestDate?: Date;
};

export const useOrgEmailsTable = (
  stateKey?: string,
  options?: UseOrgEmailsTableOptions,
) => {
  const navigate = useNavigate();
  const requestDate = options?.requestDate;

  const { selectedOrgEmail, onSelectOrgEmail } = useOrgEmailSelected();

  const cm = useRef<IContextMenuRef | null>(null);

  const onContextMenuSelectionChange = (
    e: DataTableContextMenuSelectionChangeEvent<DataTableValueArray>,
  ) => {
    let nextValue = e.value as OrgEmailModels | null;

    if (nextValue && nextValue.id === selectedOrgEmail?.id) {
      nextValue = null;
    }

    onSelectOrgEmail(nextValue);
  };

  const clearSelectedOrgEmails = useClearSelectedRows({
    stateKey,
    cb: () => onSelectOrgEmail(null),
  });

  const onSelectionChange = (
    e: DataTableSelectionSingleChangeEvent<DataTableValueArray>,
  ) => {
    onSelectOrgEmail(e.value as OrgEmailModels);
  };

  const buildQuery = (orgId?: number | null) => {
    const params = new URLSearchParams();
    if (requestDate != null) {
      params.set('requestDate', String(toRequestDateTimestamp(requestDate)));
    }
    if (orgId != null) {
      params.set('orgId', String(orgId));
    }
    const query = params.toString();
    return query ? `?${query}` : '';
  };

  const onRowDoubleClick = (e: DataTableRowClickEvent) => {
    const row = e?.data as OrgEmailModels;
    if (row?.id) {
      const rowOrgId =
        (e?.data as { organization?: { id?: number | null } })?.organization
          ?.id ?? null;
      navigate(
        buildPath(
          generatePath(paths.editOrgEmail, {
            masterId: row.id,
          }),
        ) + buildQuery(rowOrgId),
      );
      clearSelectedOrgEmails();
    }
  };

  const onContextMenu = (e: DataTableRowEvent) => {
    cm?.current?.show(e.originalEvent);
  };

  const onOrgToolbarCommand = (command: 'create' | 'edit') => {
    switch (command) {
      case 'edit':
        if (selectedOrgEmail?.id) {
          const selectedOrgId =
            (selectedOrgEmail as { organization?: { id?: number | null } })
              ?.organization?.id ?? null;
          navigate(
            buildPath(
              generatePath(paths.editOrgEmail, {
                masterId: selectedOrgEmail.id,
              }),
            ) + buildQuery(selectedOrgId),
          );
        }
        clearSelectedOrgEmails();
        break;
      case 'create':
        clearSelectedOrgEmails();
        navigate(buildPath(paths.createOrgEmail) + buildQuery());
        break;
      default:
        return null;
    }
  };

  return {
    cm,
    onContextMenuSelectionChange,
    onSelectionChange,
    onRowDoubleClick,
    onContextMenu,
    onOrgToolbarCommand,
  };
};
