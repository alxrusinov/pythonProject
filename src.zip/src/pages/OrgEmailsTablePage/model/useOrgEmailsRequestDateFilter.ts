import { useState } from 'react';

export const useOrgEmailsRequestDateFilter = () => {
  const [requestDate, setRequestDate] = useState<Date | undefined>(undefined);

  const onRequestDateClearFilter = () => {
    setRequestDate(undefined);
  };

  const onRequestDateFilterChange = (value: Date | undefined) => {
    setRequestDate(value);
  };

  return {
    requestDate,
    onRequestDateClearFilter,
    onRequestDateFilterChange,
  };
};
