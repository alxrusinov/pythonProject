import {
  useIrcCreateOrUpdateOrgEmailsMutation,
  useIrcOrgEmailsByOrgIdLazyQuery,
} from 'graphql/generated/generated';
import { useContext, useState } from 'react';

import {
  Box,
  Button,
  DataService,
  makeNotification,
} from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { useOrgEmailSelected } from 'widgets/ActionPanel/store/OrgEmailSelected';
import { InstructionTableTemplate } from 'widgets/InstructionTableTemplate';

import { FiltersPlaceholder, TableFilterProvider } from 'shared/components';
import { OrgEmailModels } from 'shared/types/common';
import { Modal } from 'shared/ui/Modal';
import { getStableRequestDate } from 'shared/utils/date';

import { orgEmailsColumnsMetaConfig } from '../lib/orgEmailsColumnsMetaConfig';
import { OrgEmailTableData, useOrgEmailsPage } from '../model/useOrgEmailsPage';
import { useOrgEmailsPageFilters } from '../model/useOrgEmailsPageFilters';
import { useOrgEmailsTable } from '../model/useOrgEmailsTable';
import { OrgEmailsTableHeader } from './OrgEmailsTableHeader';

const DATA_KEY = 'id';

interface IProps {
  onOpenFilters: VoidFunction;
}

const OrgEmailsPageComponent = ({ onOpenFilters }: IProps) => {
  const { filters, globalFilterValue, onFilterChange, onGlobalFilterChange } =
    useOrgEmailsPageFilters();
  const { filtersWhereGraphQLStatement } = useContext(
    DataService.DataServiceContext,
  );
  const hasFilters =
    filtersWhereGraphQLStatement &&
    Object.keys(filtersWhereGraphQLStatement).length > 0;

  const { selectedOrgEmail, onSelectOrgEmail } = useOrgEmailSelected();
  const [deletedEmailIds, setDeletedEmailIds] = useState<string[]>([]);
  const [isDeleteModalVisible, setDeleteModalVisible] = useState(false);
  const [pendingDeleteRow, setPendingDeleteRow] =
    useState<OrgEmailTableData | null>(null);
  const [getOrgEmailsByOrgId] = useIrcOrgEmailsByOrgIdLazyQuery();
  const [saveOrgEmails] = useIrcCreateOrUpdateOrgEmailsMutation();

  const {
    onContextMenuSelectionChange,
    onSelectionChange,
    onRowDoubleClick,
    onContextMenu,
    onOrgToolbarCommand,
  } = useOrgEmailsTable('org-emails-table');

  const handleEdit = () => {
    onOrgToolbarCommand('edit');
  };

  const handleCreate = () => {
    onOrgToolbarCommand('create');
  };

  const { transformedData, orgEmailsColumnsMetaData, loading } =
    useOrgEmailsPage({});
  const selectedRow = transformedData.find(
    item => String(item.id) === String(selectedOrgEmail?.id),
  );
  const filteredData = transformedData.filter(
    item => !deletedEmailIds.includes(String(item.id)),
  );

  const handleDelete = async (rowToDelete: OrgEmailTableData | null) => {
    if (!rowToDelete?.organization?.id || !rowToDelete?.email) {
      return;
    }

    try {
      const requestDate = getStableRequestDate();
      const orgId = Number(rowToDelete.organization.id);
      const selectedEmail = rowToDelete.email.trim().toLowerCase();
      const byOrgIdResult = await getOrgEmailsByOrgId({
        variables: {
          orgId,
          requestDate,
        },
        fetchPolicy: 'no-cache',
      });

      const emails = (byOrgIdResult.data?.ircOrgEmails?.items ?? [])
        .map(item => item?.email?.trim() ?? '')
        .filter(Boolean);

      const nextEmails = emails.filter(
        email => email.toLowerCase() !== selectedEmail,
      );

      await saveOrgEmails({
        variables: {
          input: {
            correlationId: UUID(),
            orgId,
            emails: nextEmails,
          },
        },
      });

      setDeletedEmailIds(prev => [...prev, String(rowToDelete.id)]);
      onSelectOrgEmail(null);
      makeNotification({
        variant: 'success',
        title: 'Успех!',
        message: 'Email-адрес удален',
      });
    } catch {
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Ошибка удаления email-адреса',
      });
    }
  };

  const handleOpenDeleteModal = () => {
    setPendingDeleteRow(selectedRow ?? null);
    setDeleteModalVisible(true);
  };

  const handleCloseDeleteModal = () => {
    setDeleteModalVisible(false);
    setPendingDeleteRow(null);
  };

  const handleConfirmDelete = async () => {
    setDeleteModalVisible(false);
    await handleDelete(pendingDeleteRow);
    setPendingDeleteRow(null);
  };

  if (!hasFilters) {
    return <FiltersPlaceholder onOpenFilters={onOpenFilters} />;
  }

  return (
    <div className="flex flex-column gap-2 flex-1 min-h-0 h-full">
      <Box className="p-2" rounded>
        <OrgEmailsTableHeader
          onSearch={onGlobalFilterChange}
          searchValue={globalFilterValue}
          value={filteredData}
          tableMetaData={orgEmailsColumnsMetaData}
          onCreate={handleCreate}
          onEdit={handleEdit}
          onDelete={handleOpenDeleteModal}
          disabled={{
            edit: !selectedOrgEmail,
            delete: !selectedOrgEmail,
          }}
        />
      </Box>
      <InstructionTableTemplate<OrgEmailTableData>
        dataKey={DATA_KEY}
        value={filteredData}
        tableMetaData={orgEmailsColumnsMetaData}
        filters={filters}
        onFilter={onFilterChange}
        loading={loading}
        onSelect={value => onSelectOrgEmail(value as OrgEmailModels | null)}
        selectedItem={selectedOrgEmail}
        onContextMenuSelectionChange={onContextMenuSelectionChange}
        onContextMenu={onContextMenu}
        onSelectionChange={onSelectionChange}
        onRowDoubleClick={onRowDoubleClick}
        stateKey="org-emails-table"
      />
      <Modal
        visible={isDeleteModalVisible}
        title="Удаление email-адреса организации"
        onClose={handleCloseDeleteModal}
      >
        <div className="flex flex-column gap-4 p-2">
          <p className="m-0">
            Вы хотите удалить выбранный email-адрес организации?
          </p>
          <div className="flex justify-content-between">
            <Button
              size="medium"
              variant="secondary"
              className="md:w-8rem"
              onClick={handleCloseDeleteModal}
            >
              Нет
            </Button>
            <Button
              size="medium"
              variant="primary"
              className="md:w-8rem"
              onClick={handleConfirmDelete}
            >
              Да
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export const OrgEmailsTablePage = () => {
  const [activeTab, setActiveTab] = useState<number | undefined>();
  const openFilters = () => {
    setActiveTab(undefined);
    queueMicrotask(() => setActiveTab(0));
  };

  return (
    <TableFilterProvider
      scope="orgEmailsScope"
      config={
        orgEmailsColumnsMetaConfig as Parameters<
          typeof TableFilterProvider
        >[0]['config']
      }
      active={activeTab}
    >
      <OrgEmailsPageComponent onOpenFilters={openFilters} />
    </TableFilterProvider>
  );
};
