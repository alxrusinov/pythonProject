import { ITableColumn } from 'shared_ui/components';

import { ActionPanel } from 'widgets/ActionPanel';
import { TableProps } from 'widgets/CustomTable';

import { TableHeaderTemplate } from 'shared/components';

interface IProps {
  onSearch?: (value: string) => void;
  searchValue?: string;
  value: TableProps['value'];
  tableMetaData: ITableColumn[];
  onCreate: VoidFunction;
  onEdit: VoidFunction;
  onDelete: VoidFunction;
  disabled: { edit: boolean; delete: boolean };
}

export const OrgEmailsTableHeader = ({
  onSearch,
  searchValue,
  onCreate,
  onEdit,
  onDelete,
  disabled,
}: IProps) => {
  return (
    <TableHeaderTemplate onSearch={onSearch} searchValue={searchValue}>
      <ActionPanel
        onCreate={onCreate}
        onEdit={onEdit}
        onDelete={onDelete}
        disabled={disabled}
      />
    </TableHeaderTemplate>
  );
};
