import { lazy } from 'react';

export const OrgEmailsTablePageLazy = lazy(() =>
  import('./OrgEmailsTablePage').then(module => ({
    default: module.OrgEmailsTablePage,
  })),
);
