import { IrcOrgEmail } from 'graphql/generated/generated';

import {
  baseField,
  componentCellRenderDateTimeWithTime,
  datetimeColumnFilterParams,
  InstructionMetaDataType,
  multiColumnFilterParams,
} from 'widgets/CustomTable';

type OrgEmailRow = IrcOrgEmail & {
  id: string;
  orgId?: number | null;
  organizationName?: string;
};

export const orgEmailsColumnsMetaConfig: InstructionMetaDataType<OrgEmailRow> =
  {
    dataService: 'IrcOrgEmails',
    fields: [
      {
        ...baseField,
        name: 'organizationName',
        displayName: 'Организация',
        table: {
          ...baseField.table,
          ...multiColumnFilterParams,
        },
      },
      {
        ...baseField,
        name: 'email',
        displayName: 'Email',
        filter: {
          dataType: 'string',
          lookup: {
            fieldName: 'email',
            dataType: 'string',
          },
        },
        table: {
          ...baseField.table,
          ...multiColumnFilterParams,
        },
      },
      {
        ...baseField,
        name: 'orgId',
        displayName: 'Код организации',
        filter: {
          dataType: 'number',
          lookup: {
            fieldName: 'organization',
            dataType: 'number',
            nested: {
              fieldName: 'id',
            },
          },
        },
        table: {
          ...baseField.table,
          ...multiColumnFilterParams,
        },
      },
      {
        ...baseField,
        name: 'dateFrom',
        displayName: 'Действует с',
        filter: {
          dataType: 'dateTime',
        },
        table: {
          filter: true,
          sortable: true,
          ...datetimeColumnFilterParams,
          body: componentCellRenderDateTimeWithTime,
        },
      },
      {
        ...baseField,
        name: 'dateTo',
        displayName: 'Действует по',
        filter: {
          dataType: 'dateTime',
        },
        table: {
          filter: true,
          sortable: true,
          ...datetimeColumnFilterParams,
          body: componentCellRenderDateTimeWithTime,
        },
      },
    ],
  };
