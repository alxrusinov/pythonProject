import { OrgEmailForm } from 'widgets/OrgEmailForm';

export const CreateOrgEmail = () => {
  return <OrgEmailForm mode="create" />;
};
