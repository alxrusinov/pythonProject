import { Box } from 'shared_ui/components';

import { InstructionTypeFormLayout } from 'shared/ui/InstructionTypeFormLayout';

export const DeleteOrgEmail = () => {
  return (
    <InstructionTypeFormLayout>
      <Box className="p-3" rounded />
    </InstructionTypeFormLayout>
  );
};
