import {
  IrcInstructionType,
  IrcInstructionTypeFilterInput,
  useInstructionTypesForTableLazyQuery,
} from 'graphql/generated/generated';
import { useContext, useEffect, useMemo, useRef } from 'react';

import { useApolloLazyQueryPage } from 'core_client/apollo';

import { DataService } from 'shared_ui/components';

import { ColumnsMetaDataType } from 'widgets/InstructionTableTemplate/lib/types';

import { getStableRequestDate } from 'shared/utils/date';
import { transformData } from 'shared/utils/transformData';

import { instructionTempalteColumnsMetaConfig } from '../lib/instructionTemplatesColumnsMetaConfig';

/** Плоские строковые поля для фильтра/отображения (как typeName в журнале инструкций) */
export type InstructionTypeTableData = IrcInstructionType & {
  id: string;
  countryFromName?: string;
  countryToName?: string;
  clientName?: string;
};

export type InstructionTypePageSort = {
  sortField?: string;
  sortOrder?: 1 | -1;
};

type UseInstructionTypePageOptions = {
  requestDate?: Date;
  searchId?: string; // используется только как global filter, без uuid-логики
};

/** Собираем колонки таблицы из конфига, чтобы фильтры всегда отображались (не зависят от инициализации DataService) */
function getInstructionTypeTableColumns(): ColumnsMetaDataType<InstructionTypeTableData>[] {
  return instructionTempalteColumnsMetaConfig.fields
    .filter(
      (f): f is typeof f & { table: NonNullable<typeof f.table> } =>
        f.table != null,
    )
    .map((f, index) => ({
      ...f.table,
      field: f.name as Extract<keyof InstructionTypeTableData, string>,
      header: f.table?.header ?? f.displayName,
      index,
    }));
}

export const useInstructionTypePage = (
  options: UseInstructionTypePageOptions,
) => {
  const { filtersWhereGraphQLStatement } = useContext(
    DataService.DataServiceContext,
  );

  const { tableColumns: instructionTypeColumnsMetaData } = useContext(
    DataService.DataServiceContext,
  );

  const where = useMemo((): IrcInstructionTypeFilterInput => {
    const base = (filtersWhereGraphQLStatement ??
      {}) as IrcInstructionTypeFilterInput;
    return base;
  }, [filtersWhereGraphQLStatement]);

  const extractData = (data: any) => data?.ircInstructionTypes;
  const [getInstructionTypes] = useInstructionTypesForTableLazyQuery();
  const {
    items: rawItems,
    loading,
    load,
  } = useApolloLazyQueryPage({
    pageSize: 100,
    total: 1000,
    extractData,
    lazyQuery: getInstructionTypes,
  });

  const loadRef = useRef(load);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastRequestKeyRef = useRef<string>('');

  useEffect(() => {
    loadRef.current = load;
  }, [load]);

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (
      !filtersWhereGraphQLStatement ||
      Object.keys(filtersWhereGraphQLStatement).length === 0
    ) {
      return;
    }
    const variables = {
      where,
      requestDate:
        options?.requestDate?.toISOString() ?? getStableRequestDate(),
    };
    const requestKey = JSON.stringify(variables);
    if (requestKey === lastRequestKeyRef.current) {
      return;
    }

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(() => {
      lastRequestKeyRef.current = requestKey;
      void loadRef.current({
        variables,
        fetchPolicy: 'no-cache',
      } as any);
    }, 250);
  }, [filtersWhereGraphQLStatement, where, options?.requestDate]);

  const transformedData = useMemo((): InstructionTypeTableData[] => {
    const items = transformData({
      data: (rawItems || []) as any[],
    });
    return items.map((item: any) => {
      const row = item as Record<string, unknown> & {
        countryFrom?: { name?: string | null } | null;
        countryTo?: { name?: string | null } | null;
        client?: { name?: string | null } | null;
      };
      return {
        ...item,
        dateFrom: row.dateFrom ? new Date(String(row.dateFrom)) : null,
        dateTo: row.dateTo ? new Date(String(row.dateTo)) : null,
        countryFromName: row.countryFrom?.name ?? '',
        countryToName: row.countryTo?.name ?? '',
        clientName: row.client?.name ?? '',
      };
    }) as unknown as InstructionTypeTableData[];
  }, [rawItems]);

  return {
    instructionTypeColumnsMetaData: instructionTypeColumnsMetaData as any,
    transformedData,
    loading,
  };
};
