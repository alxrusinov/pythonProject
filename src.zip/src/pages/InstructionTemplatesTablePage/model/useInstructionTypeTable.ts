import { useRef, useState } from 'react';
import { generatePath, useNavigate } from 'react-router-dom';

import {
  DataTableRowEvent,
  DataTableSelectionSingleChangeEvent,
  DataTableValueArray,
  IContextMenuRef,
} from 'shared_ui/components';
import {
  DataTableContextMenuSelectionChangeEvent,
  DataTableRowClickEvent,
} from 'shared_ui/primereact';

import { useInstructionTypeSelected } from 'widgets/ActionPanel/store/InstructionTypeSelected';

import {
  InstructionContextMenuItem,
  InstructionContextMenuItemIds,
} from 'features/InstructionContextMenu';

import { useClearSelectedRows } from 'shared/hooks/useClearSelectedRows';
import { useInstructionTypeCopy } from 'shared/hooks/useInstructionTypeCopy';
import { paths } from 'shared/routes/paths';
import { InstructionTypeModels } from 'shared/types/common';
import { buildPath } from 'shared/utils/buildPath';

const toRequestDateTimestamp = (date: Date) => date.getTime();

export type UseInstructionTypeTableOptions = {
  /** Текущая дата фильтра со списка — подставляется в URL при открытии типа (requestDate) */
  requestDate?: Date;
};

export const useInstructionTypeTable = (
  stateKey?: string,
  options?: UseInstructionTypeTableOptions,
) => {
  const navigate = useNavigate();
  const copyInstructionType = useInstructionTypeCopy();
  const requestDate = options?.requestDate;

  const { selectedInstructionType, onSelectInstructionType } =
    useInstructionTypeSelected();

  const [visibleHistoryOperationsModal, setVisibleHistoryOperationsModal] =
    useState(false);

  const cm = useRef<IContextMenuRef | null>(null);

  const onContextMenuSelectionChange = (
    e: DataTableContextMenuSelectionChangeEvent<DataTableValueArray>,
  ) => {
    let nextValue = e.value as InstructionTypeModels | null;

    if (nextValue && nextValue.id === selectedInstructionType?.id) {
      nextValue = null;
    }

    onSelectInstructionType(nextValue);
  };

  const clearSelectedInstructionTypes = useClearSelectedRows({
    stateKey,
    cb: () => onSelectInstructionType(null),
  });

  const onSelectionChange = (
    e: DataTableSelectionSingleChangeEvent<DataTableValueArray>,
  ) => {
    onSelectInstructionType(e.value as InstructionTypeModels);
  };

  const requestDateQuery =
    requestDate != null
      ? `?requestDate=${toRequestDateTimestamp(requestDate)}`
      : '';

  const onRowDoubleClick = (e: DataTableRowClickEvent) => {
    const row = e?.data as InstructionTypeModels;
    if (row?.id) {
      navigate(
        buildPath(
          generatePath(paths.editInstructionTemplate, {
            masterId: row.id,
          }),
        ) + requestDateQuery,
      );
      clearSelectedInstructionTypes();
    }
  };

  const onContextMenu = (e: DataTableRowEvent) => {
    cm?.current?.show(e.originalEvent);
  };

  const onInstryctionTypeContextMenuCommand = (
    item: InstructionContextMenuItem,
  ) => {
    switch (item.id) {
      case InstructionContextMenuItemIds.Card:
      case InstructionContextMenuItemIds.Edit:
        if (selectedInstructionType) {
          navigate(
            buildPath(
              generatePath(paths.editInstructionTemplate, {
                masterId: selectedInstructionType.id,
              }),
            ) + requestDateQuery,
          );
        }

        clearSelectedInstructionTypes();
        break;
      case InstructionContextMenuItemIds.Copy:
        if (selectedInstructionType?.id) {
          copyInstructionType(selectedInstructionType.id, requestDate);
          clearSelectedInstructionTypes();
        }
        break;

      case InstructionContextMenuItemIds.Create:
        clearSelectedInstructionTypes();
        navigate(buildPath(generatePath(paths.createInstructionTemplate)));
        break;
      default:
        return null;
    }
  };

  const operationsHistoryClose = () => {
    setVisibleHistoryOperationsModal(false);
    clearSelectedInstructionTypes();
  };

  return {
    cm,
    onContextMenuSelectionChange,
    onSelectionChange,
    onRowDoubleClick,
    onContextMenu,
    visibleHistoryOperationsModal,
    onInstryctionTypeContextMenuCommand,
    operationsHistoryClose,
  };
};
