import { useCallback, useState } from 'react';

import { FilterMatchMode, FilterOperator } from 'shared_ui/api';
import { DataTableStateEvent } from 'shared_ui/primereact';

import { FilterMeta } from 'widgets/CustomTable';

import type { InstructionTypeTableData } from './useInstructionTypePage';

const STORAGE_KEY = 'instruction-templates-table-filters';
const DATE_FILTER_FIELDS = ['dateFrom', 'dateTo'] as const;

const defaultFilters: FilterMeta<InstructionTypeTableData> = {
  global: { value: null, matchMode: FilterMatchMode.CONTAINS },
  name: { value: null, matchMode: FilterMatchMode.IN },
  dateFrom: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
  dateTo: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
  countryFromName: { value: null, matchMode: FilterMatchMode.IN },
  countryToName: { value: null, matchMode: FilterMatchMode.IN },
  clientName: { value: null, matchMode: FilterMatchMode.IN },
};

const reviveDateValue = (value: unknown): unknown => {
  if (value == null || value === '') return null;
  if (value instanceof Date) return value;
  if (typeof value === 'number' || typeof value === 'string') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  return value;
};

const reviveDateFilters = (
  filters: FilterMeta<InstructionTypeTableData>,
): FilterMeta<InstructionTypeTableData> => {
  const next = { ...filters };

  DATE_FILTER_FIELDS.forEach(field => {
    const entry = next[field];
    if (!entry || typeof entry !== 'object') return;

    const constraints = (
      entry as {
        constraints?: Array<{
          value?: unknown;
          matchMode?: FilterMatchMode;
        }>;
      }
    ).constraints;
    if (!constraints?.length) return;

    next[field] = {
      ...(entry as object),
      constraints: constraints.map(c => ({
        ...c,
        value: reviveDateValue(c.value),
      })),
    } as FilterMeta<InstructionTypeTableData>[typeof field];
  });

  return next;
};

function loadFilters(): FilterMeta<InstructionTypeTableData> {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as FilterMeta<InstructionTypeTableData>;
      return reviveDateFilters(parsed);
    }
  } catch {
    /* ignore */
  }
  return defaultFilters;
}

function saveFilters(filters: FilterMeta<InstructionTypeTableData>) {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(filters));
  } catch {
    /* ignore */
  }
}

export const useInstructionTypePageFilters = () => {
  const [filters, setFilters] =
    useState<FilterMeta<InstructionTypeTableData>>(loadFilters);

  const clearFilters = () => {
    const clean = { ...defaultFilters };
    setFilters(clean);
    saveFilters(clean);
  };

  const onGlobalFilterChange = useCallback((value: string) => {
    setFilters(prev => {
      const next = {
        ...prev,
        global: { value, matchMode: FilterMatchMode.CONTAINS },
      };
      saveFilters(next);
      return next;
    });
  }, []);

  const onFilterChange = useCallback((e: DataTableStateEvent) => {
    setFilters(e.filters);
    saveFilters(e.filters as FilterMeta<InstructionTypeTableData>);
  }, []);

  const globalFilterValue =
    (filters.global as { value: string | null })?.value ?? '';

  return {
    filters,
    globalFilterValue,
    clearFilters,
    onGlobalFilterChange,
    onFilterChange,
  };
};
