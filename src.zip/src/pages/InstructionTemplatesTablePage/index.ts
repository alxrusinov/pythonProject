export { InstructionTemplatesTablePageLazy as InstructionTemplatesTablePage } from './ui/InstructionTemplatesTablePageLazy';
