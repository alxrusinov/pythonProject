import { IrcInstructionType } from 'graphql/generated/generated';

import {
  baseField,
  componentCellRenderDateTimeWithTime,
  datetimeColumnFilterParams,
  InstructionMetaDataType,
  multiColumnFilterParams,
} from 'widgets/CustomTable';

import {
  ClientFilterLookup,
  CountryFilterLookup,
} from 'shared/components/filterLookups';

/** Тип строки таблицы с плоскими полями для фильтра (как в журнале инструкций) */
type InstructionTypeRow = IrcInstructionType & {
  id: string;
  countryFromName?: string;
  countryToName?: string;
  clientName?: string;
};

// Модель справочник типов инструкций
export const instructionTempalteColumnsMetaConfig: InstructionMetaDataType<InstructionTypeRow> =
  {
    dataService: 'IrcInstructionTypes',
    fields: [
      {
        ...baseField,
        name: 'name',
        displayName: 'Тип инструкции',
        filter: {
          dataType: 'string',
          lookup: {
            fieldName: 'name',
            dataType: 'string',
          },
        },
        table: {
          ...baseField.table,
          ...multiColumnFilterParams,
        },
      },
      {
        ...baseField,
        name: 'dateFrom',
        displayName: 'Действует с',
        filter: {
          dataType: 'dateTime',
        },
        table: {
          filter: true,
          sortable: true,
          ...datetimeColumnFilterParams,
          body: componentCellRenderDateTimeWithTime,
        },
      },
      {
        ...baseField,
        name: 'dateTo',
        displayName: 'Действует по',
        filter: {
          dataType: 'dateTime',
        },
        table: {
          filter: true,
          sortable: true,
          ...datetimeColumnFilterParams,
          body: componentCellRenderDateTimeWithTime,
        },
      },
      {
        ...baseField,
        name: 'countryFromName',
        displayName: 'Страна отправления',
        filter: {
          dataType: 'string',
          conditionMode: 'lookup-eq',
          lookup: {
            fieldName: 'countryFrom',
            dataType: 'number',
            nested: {
              fieldName: 'id',
            },
            component: CountryFilterLookup,
          },
        },
        table: {
          ...baseField.table,
          ...multiColumnFilterParams,
        },
      },
      {
        ...baseField,
        name: 'countryToName',
        displayName: 'Страна назначения',
        filter: {
          dataType: 'string',
          conditionMode: 'lookup-eq',
          lookup: {
            fieldName: 'countryTo',
            dataType: 'number',
            nested: {
              fieldName: 'id',
            },
            component: CountryFilterLookup,
          },
        },
        table: {
          ...baseField.table,
          ...multiColumnFilterParams,
        },
      },
      {
        ...baseField,
        name: 'clientName',
        displayName: 'Клиент',
        filter: {
          dataType: 'string',
          conditionMode: 'lookup-eq',
          lookup: {
            fieldName: 'client',
            dataType: 'number',
            nested: {
              fieldName: 'id',
            },
            component: ClientFilterLookup,
          },
        },
        table: {
          ...baseField.table,
          ...multiColumnFilterParams,
        },
      },
    ],
  };
