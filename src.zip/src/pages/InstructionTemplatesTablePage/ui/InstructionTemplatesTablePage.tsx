import { useContext, useState } from 'react';

import { Box, DataService } from 'shared_ui/components';

import { useInstructionTypeTable } from 'pages/InstructionTemplatesTablePage/model/useInstructionTypeTable';

import { useInstructionTypeSelected } from 'widgets/ActionPanel/store/InstructionTypeSelected';
import { InstructionTableTemplate } from 'widgets/InstructionTableTemplate';

import { InstructionContextMenuItemIds } from 'features/InstructionContextMenu';

import { FiltersPlaceholder, TableFilterProvider } from 'shared/components';

import { instructionTempalteColumnsMetaConfig } from '../lib/instructionTemplatesColumnsMetaConfig';
import {
  type InstructionTypeTableData,
  useInstructionTypePage,
} from '../model/useInstructionTypePage';
import { useInstructionTypePageFilters } from '../model/useInstructionTypePageFilters';
import { useInstructionTypeRequestDateFilter } from '../model/useInstructionTypeRequestDateFilter';
import { InstructionTemplatesTableHeader } from './InstructionTemplatesTableHeader';

const DATA_KEY = 'id';

interface IProps {
  onOpenFilters: VoidFunction;
}

const InstructionTypePageComponent = ({ onOpenFilters }: IProps) => {
  const { filters, globalFilterValue, onFilterChange, onGlobalFilterChange } =
    useInstructionTypePageFilters();
  const { filtersWhereGraphQLStatement } = useContext(
    DataService.DataServiceContext,
  );
  const hasFilters =
    filtersWhereGraphQLStatement &&
    Object.keys(filtersWhereGraphQLStatement).length > 0;

  const { requestDate, onRequestDateFilterChange } =
    useInstructionTypeRequestDateFilter();

  const { transformedData, instructionTypeColumnsMetaData, loading } =
    useInstructionTypePage({ requestDate });

  const { selectedInstructionType, onSelectInstructionType } =
    useInstructionTypeSelected();

  const {
    onContextMenuSelectionChange,
    onSelectionChange,
    onRowDoubleClick,
    onContextMenu,
    onInstryctionTypeContextMenuCommand,
  } = useInstructionTypeTable(selectedInstructionType?.id ?? undefined, {
    requestDate: requestDate ?? undefined,
  });

  const handleEdit = () => {
    if (selectedInstructionType) {
      onInstryctionTypeContextMenuCommand({
        id: InstructionContextMenuItemIds.Edit,
      });
    }
  };
  const handleCopy = () => {
    if (selectedInstructionType) {
      onInstryctionTypeContextMenuCommand({
        id: InstructionContextMenuItemIds.Copy,
      });
    }
  };
  const handleCreate = () => {
    onInstryctionTypeContextMenuCommand({
      id: InstructionContextMenuItemIds.Create,
    });
  };

  if (!hasFilters) {
    return <FiltersPlaceholder onOpenFilters={onOpenFilters} />;
  }

  return (
    <div className="flex flex-column gap-2 flex-1 min-h-0 h-full">
      <Box className="p-2" rounded>
        <InstructionTemplatesTableHeader
          onSearch={onGlobalFilterChange}
          searchValue={globalFilterValue}
          value={transformedData}
          tableMetaData={instructionTypeColumnsMetaData}
          requestDate={requestDate}
          onRequestDateChange={onRequestDateFilterChange}
          onCreate={handleCreate}
          onCopy={handleCopy}
          onEdit={handleEdit}
          disabled={{
            edit: !selectedInstructionType,
            copy: !selectedInstructionType,
          }}
        />
      </Box>

      <InstructionTableTemplate<InstructionTypeTableData>
        dataKey={DATA_KEY}
        value={transformedData}
        tableMetaData={instructionTypeColumnsMetaData}
        filters={filters}
        onFilter={onFilterChange}
        loading={loading}
        onSelect={onSelectInstructionType}
        selectedItem={selectedInstructionType}
        onContextMenuSelectionChange={onContextMenuSelectionChange}
        onContextMenu={onContextMenu}
        onSelectionChange={onSelectionChange}
        onRowDoubleClick={onRowDoubleClick}
        stateKey="instruction-templates-table"
      />
    </div>
  );
};

export const InstructionTemplatesTablePage = () => {
  const [activeTab, setActiveTab] = useState<number | undefined>();
  const openFilters = () => {
    setActiveTab(undefined);
    queueMicrotask(() => setActiveTab(0));
  };

  return (
    <TableFilterProvider
      scope="instructionTempaltesScope"
      config={
        instructionTempalteColumnsMetaConfig as Parameters<
          typeof TableFilterProvider
        >[0]['config']
      }
      active={activeTab}
    >
      <InstructionTypePageComponent onOpenFilters={openFilters} />
    </TableFilterProvider>
  );
};
