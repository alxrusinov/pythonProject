import { lazy } from 'react';

export const InstructionTemplatesTablePageLazy = lazy(() =>
  import('./InstructionTemplatesTablePage').then(module => ({
    default: module.InstructionTemplatesTablePage,
  })),
);
