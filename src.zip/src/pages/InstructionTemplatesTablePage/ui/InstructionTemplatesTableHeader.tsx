import { ITableColumn } from 'shared_ui/components';

import { ActionPanel } from 'widgets/ActionPanel';
import { TableProps } from 'widgets/CustomTable';
import { RequestDateFilter } from 'widgets/RequestDateFilter';

import { TableHeaderTemplate } from 'shared/components';

interface IProps {
  onSearch?: (value: string) => void;
  searchValue?: string;
  value: TableProps['value'];
  tableMetaData: ITableColumn[];
  requestDate: Date | undefined;
  onRequestDateChange: (date: Date | undefined) => void;
  onCreate: VoidFunction;
  onCopy: VoidFunction;
  onEdit: VoidFunction;
  disabled: { edit: boolean; copy: boolean };
}

export const InstructionTemplatesTableHeader = ({
  onSearch,
  searchValue,
  requestDate,
  onRequestDateChange,
  onCreate,
  onCopy,
  onEdit,
  disabled,
}: IProps) => {
  return (
    <TableHeaderTemplate onSearch={onSearch} searchValue={searchValue}>
      <RequestDateFilter value={requestDate} onChange={onRequestDateChange} />

      <ActionPanel
        onCreate={onCreate}
        onCopy={onCopy}
        onEdit={onEdit}
        disabled={disabled}
      />
    </TableHeaderTemplate>
  );
};
