import { lazy } from 'react';

export const InstructionTablePageLazy = lazy(() =>
  import('./InstructionTablePage').then(module => ({
    default: module.InstructionTablePage,
  })),
);
