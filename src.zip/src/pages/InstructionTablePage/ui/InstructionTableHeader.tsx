import { ITableColumn } from 'shared_ui/components';

import { ActionPanel } from 'widgets/ActionPanel';
import { TableProps } from 'widgets/CustomTable';

import { TableHeaderTemplate } from 'shared/components';

interface IProps {
  onSearch?: (value: string) => void;
  searchValue?: string;
  onClearLocalFilters?: () => void;
  value: TableProps['value'];
  tableMetaData: ITableColumn[];
  onCreate: VoidFunction;
  onCopy: VoidFunction;
  onEdit: VoidFunction;
  disabled: { edit: boolean; copy: boolean };
}

export const InstructionTableHeader = ({
  onSearch,
  searchValue,
  onClearLocalFilters,
  onCreate,
  onCopy,
  onEdit,
  disabled,
}: IProps) => {
  return (
    <TableHeaderTemplate
      onSearch={onSearch}
      searchValue={searchValue}
      onClearLocalFilters={onClearLocalFilters}
    >
      <ActionPanel
        onCreate={onCreate}
        onCopy={onCopy}
        onEdit={onEdit}
        disabled={disabled}
      />
    </TableHeaderTemplate>
  );
};
