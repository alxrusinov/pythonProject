import { useContext, useState } from 'react';

import { Box, DataService } from 'shared_ui/components';

import { useInstructionSelected } from 'widgets/ActionPanel/store/InstructionSelected';
import { InstructionTableTemplate } from 'widgets/InstructionTableTemplate';

import { InstructionContextMenuItemIds } from 'features/InstructionContextMenu';

import { FiltersPlaceholder, TableFilterProvider } from 'shared/components';

import { instructionColumnsMetaConfig } from '../lib/instructionColumnsMetaConfig';
import { TransformedRow } from '../model/columnSelectors';
import { useInstructionPage } from '../model/useInstructionPage';
import { useInstructionPageFilters } from '../model/useInstructionPageFilters';
import { useInstructionTable } from '../model/useInstructionTable';
import { InstructionTableHeader } from './InstructionTableHeader';

const DATA_KEY = 'id';

interface IProps {
  onOpenFilters: VoidFunction;
}

const InstructionPageComponent = ({ onOpenFilters }: IProps) => {
  const { filters, globalFilterValue, clearLocalFilters, onFilterChange, onGlobalFilterChange } =
    useInstructionPageFilters();
  const { filtersWhereGraphQLStatement } = useContext(
    DataService.DataServiceContext,
  );
  const hasFilters =
    filtersWhereGraphQLStatement &&
    Object.keys(filtersWhereGraphQLStatement).length > 0;

  const { selectedInstruction, onSelectInstruction } = useInstructionSelected();

  const {
    onContextMenuSelectionChange,
    onSelectionChange,
    onRowDoubleClick,
    onContextMenu,
    onInstructionsContextMenuCommand,
  } = useInstructionTable(
    selectedInstruction?.id ? selectedInstruction.id : '',
  );

  const handleEdit = () => {
    if (selectedInstruction) {
      onInstructionsContextMenuCommand({
        id: InstructionContextMenuItemIds.Edit,
      });
    }
  };
  const handleCopy = () => {
    if (selectedInstruction) {
      onInstructionsContextMenuCommand({
        id: InstructionContextMenuItemIds.Copy,
      });
    }
  };
  const handleCreate = () => {
    onInstructionsContextMenuCommand({
      id: InstructionContextMenuItemIds.Create,
    });
  };

  const { transformedData, instructionColumnsMetaData, loading } =
    useInstructionPage();

  if (!hasFilters) {
    return <FiltersPlaceholder onOpenFilters={onOpenFilters} />;
  }

  return (
    <div className="flex flex-column gap-2 flex-1 min-h-0 h-full">
      <Box className="p-2" rounded>
        <InstructionTableHeader
          onSearch={onGlobalFilterChange}
          searchValue={globalFilterValue}
          onClearLocalFilters={clearLocalFilters}
          value={transformedData}
          tableMetaData={instructionColumnsMetaData}
          onCreate={handleCreate}
          onCopy={handleCopy}
          onEdit={handleEdit}
          disabled={{ edit: !selectedInstruction, copy: !selectedInstruction }}
        />
      </Box>
      <InstructionTableTemplate<TransformedRow>
        dataKey={DATA_KEY}
        value={transformedData}
        tableMetaData={instructionColumnsMetaData}
        filters={filters}
        onFilter={onFilterChange}
        loading={loading}
        onSelect={onSelectInstruction}
        selectedItem={selectedInstruction}
        onContextMenuSelectionChange={onContextMenuSelectionChange}
        onContextMenu={onContextMenu}
        onSelectionChange={onSelectionChange}
        onRowDoubleClick={onRowDoubleClick}
        stateKey="instruction-table"
      />
    </div>
  );
};

export const InstructionTablePage = () => {
  const [activeTab, setActiveTab] = useState<number | undefined>();
  const openFilters = () => {
    setActiveTab(undefined);
    queueMicrotask(() => setActiveTab(0));
  };

  return (
    <TableFilterProvider
      scope="instructionScope"
      config={
        instructionColumnsMetaConfig as unknown as Parameters<
          typeof TableFilterProvider
        >[0]['config']
      }
      active={activeTab}
    >
      <InstructionPageComponent onOpenFilters={openFilters} />
    </TableFilterProvider>
  );
};
