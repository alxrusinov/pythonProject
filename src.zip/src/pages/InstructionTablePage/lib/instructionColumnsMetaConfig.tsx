import { IrcInstruction } from 'graphql/generated/generated';

import { CellRenderBoolean, Tag } from 'shared_ui/components';

import {
  baseField,
  booleanColumnFilterParams,
  componentCellRenderDateTime,
  componentCellRenderDateTimeWithTime,
  datetimeColumnFilterParams,
  multiColumnFilterParams,
  textColumnFilterParams,
} from 'widgets/CustomTable';
import { INSTRUCTION_STATUSES } from 'widgets/InstructionForm/lib/constants';

import {
  ClientFilterLookup,
  InstructionStatusFilterLookup,
  InstructionTypeFilterLookup,
  RailwayFilterLookup,
  RecipFilterLookup,
  StationFilterLookup,
  UserInfoFilterLookup,
} from 'shared/components/filterLookups';
import { ColumnConfig } from 'shared/types/ColumnConfig';
import { NoDataMark } from 'shared/ui/NoDataMark';

import { ColumnKey, TransformedRow } from '../model/columnSelectors';

const manualNameColumnStyle = {
  style: { maxWidth: '240px', width: '240px' },
  headerStyle: { maxWidth: '240px', width: '240px' },
  bodyStyle: {
    maxWidth: '240px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
} as const;

const renderUserNameCell =
  (
    nameField: 'createUserName' | 'lastUserName',
    tooltipField: 'createUserFullName' | 'lastUserFullName',
  ) =>
  (rowData: TransformedRow) => {
    const name = rowData[nameField];
    if (!name) return <NoDataMark />;

    const tooltip = rowData[tooltipField];
    return <span title={tooltip ?? undefined}>{name}</span>;
  };

const getColorByStatusName = (statusName: string) => {
  switch (statusName) {
    case INSTRUCTION_STATUSES.created:
      return 'gray';
    case INSTRUCTION_STATUSES.canceled:
      return 'red';
    case INSTRUCTION_STATUSES.sended:
      return 'green';
    default:
      return 'gray';
  }
};

// Модель справочник инструкций
export const instructionColumnsMetaConfig: ColumnConfig<ColumnKey> = {
  dataService: 'IrcInstruction',
  fields: [
    {
      ...baseField,
      name: 'id',
      displayName: 'ИД Инструкции',
      table: {
        filter: false,
        sortable: true,
      },
    },
    {
      ...baseField,
      name: 'statusName',
      displayName: 'Статус инструкции',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'status',
          dataType: 'number',
          nested: {
            fieldName: 'id',
          },
          component: InstructionStatusFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
        body: (rowData: TransformedRow) => {
          if (!rowData.statusName) {
            return '-';
          }
          return (
            <Tag
              label={rowData.statusName}
              color={getColorByStatusName(rowData.statusName)}
            />
          );
        },
      },
    },
    {
      ...baseField,
      name: 'typeName',
      displayName: 'Тип инструкции',
      filter: {
        dataType: 'string',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'instructionType',
          dataType: 'string',
          nested: {
            fieldName: 'id',
          },
          component: InstructionTypeFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'number',
      displayName: 'Номер инструкции',
      filter: {
        dataType: 'string',
        lookup: {
          fieldName: 'number',
          dataType: 'string',
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'date',
      displayName: 'Дата инструкции',
      filter: {
        dataType: 'datetime',
      },
      table: {
        ...baseField.table,
        ...datetimeColumnFilterParams,
        body: componentCellRenderDateTime(),
      },
    },
    {
      ...baseField,
      name: 'stationFromName',
      displayName: 'Станция погрузки',
      filter: {
        dataType: 'string',
      },
      table: {
        ...baseField.table,
        ...textColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'senderStationName',
      displayName: 'Станция выгрузки',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'senderStation',
          dataType: 'number',
          nested: {
            fieldName: 'id',
          },
          component: StationFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'senderRailwayName',
      displayName: 'Дорога выгрузки',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'senderStation',
          dataType: 'number',
          nested: {
            fieldName: 'railway',
            nested: {
              fieldName: 'id',
            },
          },
          component: RailwayFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'receiverStationName',
      displayName: 'Назначенная станция',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'receiverStation',
          dataType: 'number',
          nested: {
            fieldName: 'id',
          },
          component: StationFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'receiverRailwayName',
      displayName: 'Дорога назначенной станции',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'receiverStation',
          dataType: 'number',
          nested: {
            fieldName: 'railway',
            nested: {
              fieldName: 'id',
            },
          },
          component: RailwayFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'clientName',
      displayName: 'Получатель инструкции',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'client',
          dataType: 'number',
          nested: {
            fieldName: 'id',
          },
          component: ClientFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'manualClientName',
      displayName: 'Получатель инструкции (вручную)',

      filter: {
        dataType: 'string',
      },

      table: {
        ...baseField.table,
        ...textColumnFilterParams,
        ...manualNameColumnStyle,
      },
    },
    {
      ...baseField,
      name: 'senderRecipName',
      displayName: 'Грузоотправитель',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'senderRecip',
          dataType: 'number',
          nested: {
            fieldName: 'id',
          },
          component: RecipFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'recieverRecipName',
      displayName: 'Грузополучатель',
      filter: {
        dataType: 'number',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'recieverRecip',
          dataType: 'number',
          nested: {
            fieldName: 'id',
          },
          component: RecipFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'recieverManualRecipName',
      displayName: 'Грузополучатель (вручную)',
      filter: {
        dataType: 'string',
      },
      table: {
        ...baseField.table,
        ...textColumnFilterParams,
        ...manualNameColumnStyle,
      },
    },

    {
      ...baseField,
      name: 'parentNumber',
      displayName: 'Номер родит. инструкции',
      filter: {
        dataType: 'string',
        lookup: {
          fieldName: 'parent',
          dataType: 'string',
          nested: {
            fieldName: 'number',
          },
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'parentDate',
      displayName: 'Дата родит. инструкции',
      filter: {
        dataType: 'datetime',
        lookup: {
          fieldName: 'parent',
          dataType: 'datetime',
          nested: {
            fieldName: 'date',
          },
        },
      },
      table: {
        ...baseField.table,
        ...datetimeColumnFilterParams,
        body: componentCellRenderDateTime(),
      },
    },

    {
      ...baseField,
      name: 'cars',
      displayName: 'Вагоны',
      filter: {
        lookup: {
          condition: 'in',
          fieldName: 'cars',
          dataType: 'string',
          nested: {
            condition: 'some',
            fieldName: 'number',
          },
        },
      },

      table: {
        ...baseField.table,
        ...textColumnFilterParams,
        body: (rowData: IrcInstruction) => {
          if (!rowData.cars) {
            return '-';
          }

          const firstCar =
            rowData.cars && rowData.cars?.length > 0 ? rowData.cars[0] : null;

          return `${firstCar}`;
        },
      },
    },

    {
      ...baseField,
      name: 'carsCount',
      displayName: 'Количество вагонов',
      filter: {
        dataType: 'number',
      },
      table: {
        ...baseField.table,
        ...textColumnFilterParams,
      },
    },
    {
      ...baseField,
      name: 'createDate',
      displayName: 'Дата создания инструкции',
      filter: {
        dataType: 'datetime',
      },
      table: {
        ...baseField.table,
        ...datetimeColumnFilterParams,
        body: componentCellRenderDateTimeWithTime,
      },
    },
    {
      ...baseField,
      name: 'lastDate',
      displayName: 'Дата изменения инструкции',
      filter: {
        dataType: 'datetime',
      },
      table: {
        ...baseField.table,
        ...datetimeColumnFilterParams,
        body: componentCellRenderDateTimeWithTime,
      },
    },

    {
      ...baseField,
      name: 'createUserName',
      displayName: 'Создал',
      filter: {
        dataType: 'string',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'createUser',
          dataType: 'string',
          nested: {
            fieldName: 'id',
          },
          component: UserInfoFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
        body: renderUserNameCell('createUserName', 'createUserFullName'),
      },
    },

    {
      ...baseField,
      name: 'lastUserName',
      displayName: 'Изменил',
      filter: {
        dataType: 'string',
        conditionMode: 'lookup-eq',
        lookup: {
          fieldName: 'lastUser',
          dataType: 'string',
          nested: {
            fieldName: 'id',
          },
          component: UserInfoFilterLookup,
        },
      },
      table: {
        ...baseField.table,
        ...multiColumnFilterParams,
        body: renderUserNameCell('lastUserName', 'lastUserFullName'),
      },
    },
    {
      ...baseField,
      name: 'sendNotFullCompOper',
      displayName: 'Неполный комплект документов',
      filter: {
        dataType: 'boolean',
      },
      table: {
        ...baseField.table,
        ...booleanColumnFilterParams,
        body: (rowData: IrcInstruction) => {
          return (
            <CellRenderBoolean
              className="flex w-full justify-content-center"
              value={!!rowData.sendNotFullCompOper}
            />
          );
        },
      },
    },
    {
      ...baseField,
      name: 'sendFullCompOper',
      displayName: 'Полный комплект документов',
      filter: {
        dataType: 'boolean',
      },
      table: {
        ...baseField.table,
        ...booleanColumnFilterParams,
        body: (rowData: IrcInstruction) => {
          return (
            <CellRenderBoolean
              className="flex w-full justify-content-center"
              value={!!rowData.sendFullCompOper}
            />
          );
        },
      },
    },
  ],
};
