export { InstructionTablePageLazy as InstructionTablePage } from './ui/InstructionTablePageLazy';
