import { useCallback, useState } from 'react';

import { FilterMatchMode, FilterOperator } from 'shared_ui/api';
import { DataTableStateEvent } from 'shared_ui/primereact';

import { FilterMeta } from 'widgets/CustomTable';

import { TransformedRow } from './columnSelectors';

const STORAGE_KEY = 'instruction-table-filters';
const DATE_FILTER_FIELDS = ['date', 'parentDate', 'createDate', 'lastDate'];

const defaultFilters: FilterMeta<TransformedRow> = {
  global: { value: null, matchMode: FilterMatchMode.CONTAINS },
  statusName: { value: null, matchMode: FilterMatchMode.IN },
  typeName: { value: null, matchMode: FilterMatchMode.IN },
  number: { value: null, matchMode: FilterMatchMode.IN },
  stationFromName: { value: null, matchMode: FilterMatchMode.CONTAINS },
  date: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
  senderStationName: { value: null, matchMode: FilterMatchMode.IN },
  senderRailwayName: { value: null, matchMode: FilterMatchMode.IN },
  receiverStationName: { value: null, matchMode: FilterMatchMode.IN },
  receiverRailwayName: { value: null, matchMode: FilterMatchMode.IN },
  clientName: { value: null, matchMode: FilterMatchMode.IN },
  manualClientName: { value: null, matchMode: FilterMatchMode.CONTAINS },
  senderRecipName: { value: null, matchMode: FilterMatchMode.IN },
  recieverRecipName: { value: null, matchMode: FilterMatchMode.IN },
  recieverManualRecipName: { value: null, matchMode: FilterMatchMode.CONTAINS },
  parentNumber: { value: null, matchMode: FilterMatchMode.IN },
  parentDate: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
  createDate: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
  lastDate: {
    operator: FilterOperator.AND,
    constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
  },
  createUserName: { value: null, matchMode: FilterMatchMode.IN },
  lastUserName: { value: null, matchMode: FilterMatchMode.IN },
  cars: { value: null, matchMode: FilterMatchMode.CONTAINS },
  carsCount: { value: null, matchMode: FilterMatchMode.IN },
  sendNotFullCompOper: { value: null, matchMode: FilterMatchMode.EQUALS },
  sendFullCompOper: { value: null, matchMode: FilterMatchMode.EQUALS },
};

const reviveDateValue = (value: unknown): unknown => {
  if (value == null || value === '') return null;
  if (value instanceof Date) return value;
  if (typeof value === 'number') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  if (typeof value === 'string') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  return value;
};

const reviveDateFilters = (
  filters: FilterMeta<TransformedRow>,
): FilterMeta<TransformedRow> => {
  const next = { ...filters };

  DATE_FILTER_FIELDS.forEach(field => {
    const filterEntry = next[field as keyof TransformedRow] as
      | {
          operator?: FilterOperator;
          constraints?: Array<{ value: unknown; matchMode: FilterMatchMode }>;
        }
      | undefined;

    if (!filterEntry?.constraints?.length) return;

    next[field as keyof TransformedRow] = {
      ...filterEntry,
      constraints: filterEntry.constraints.map(constraint => ({
        ...constraint,
        value: reviveDateValue(constraint.value),
      })),
    } as FilterMeta<TransformedRow>[keyof TransformedRow];
  });

  return next;
};

const loadFilters = (): FilterMeta<TransformedRow> => {
  const raw = sessionStorage.getItem(STORAGE_KEY);
  if (raw) {
    const parsed = JSON.parse(raw) as FilterMeta<TransformedRow>;
    return reviveDateFilters({
      ...defaultFilters,
      ...parsed,
    });
  }

  return defaultFilters;
};

const saveFilters = (filters: FilterMeta<TransformedRow>) => {
  sessionStorage.setItem(STORAGE_KEY, JSON.stringify(filters));
};

export const useInstructionPageFilters = () => {
  const [filters, setFilters] =
    useState<FilterMeta<TransformedRow>>(loadFilters);

  const clearLocalFilters = useCallback(() => {
    setFilters(prev => {
      const next = { ...defaultFilters, global: prev.global };
      saveFilters(next);
      return next;
    });
  }, []);

  const onGlobalFilterChange = useCallback((value: string) => {
    setFilters(prev => {
      const next = {
        ...prev,
        global: { value, matchMode: FilterMatchMode.CONTAINS },
      };
      saveFilters(next);
      return next;
    });
  }, []);

  const onFilterChange = useCallback((e: DataTableStateEvent) => {
    setFilters(e.filters);
    saveFilters(e.filters as FilterMeta<TransformedRow>);
  }, []);

  const globalFilterValue =
    (filters.global as { value: string | null })?.value ?? '';

  return {
    filters,
    globalFilterValue,
    clearLocalFilters,
    onGlobalFilterChange,
    onFilterChange,
  };
};
