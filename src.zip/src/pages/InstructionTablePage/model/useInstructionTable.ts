import { useRef, useState } from 'react';
import { generatePath, useNavigate } from 'react-router-dom';

import {
  DataTableRowEvent,
  DataTableSelectionSingleChangeEvent,
  DataTableValueArray,
  IContextMenuRef,
} from 'shared_ui/components';
import {
  DataTableContextMenuSelectionChangeEvent,
  DataTableRowClickEvent,
} from 'shared_ui/primereact';

import { useInstructionSelected } from 'widgets/ActionPanel/store/InstructionSelected';

import {
  InstructionContextMenuItem,
  InstructionContextMenuItemIds,
} from 'features/InstructionContextMenu';

import { useClearSelectedRows } from 'shared/hooks/useClearSelectedRows';
import { useInstructionCopy } from 'shared/hooks/useInstructionCopy';
import { paths } from 'shared/routes/paths';
import { InstructionModels } from 'shared/types/common';
import { buildPath } from 'shared/utils/buildPath';

const toCalcDateTimestamp = (date: InstructionModels['date']): number =>
  date
    ? typeof date === 'number'
      ? date
      : new Date(date).getTime()
    : Date.now();

export const useInstructionTable = (stateKey?: string) => {
  const navigate = useNavigate();
  const copyInstruction = useInstructionCopy();

  const { selectedInstruction, onSelectInstruction } = useInstructionSelected();

  const [visibleHistoryOperationsModal, setVisibleHistoryOperationsModal] =
    useState(false);

  const cm = useRef<IContextMenuRef | null>(null);

  const onContextMenuSelectionChange = (
    e: DataTableContextMenuSelectionChangeEvent<DataTableValueArray>,
  ) => {
    let nextValue = e.value as InstructionModels | null;

    if (nextValue && nextValue.id === selectedInstruction?.id) {
      nextValue = null;
    }

    onSelectInstruction(nextValue);
  };

  const clearSelectedInstructions = useClearSelectedRows({
    stateKey,
    cb: () => onSelectInstruction(null),
  });

  const onSelectionChange = (
    e: DataTableSelectionSingleChangeEvent<DataTableValueArray>,
  ) => {
    onSelectInstruction(e.value as InstructionModels);
  };

  const onRowDoubleClick = (e: DataTableRowClickEvent) => {
    const row = e?.data as InstructionModels;

    if (row?.id) {
      navigate(
        buildPath(
          generatePath(paths.editInstruction, {
            masterId: row.id,
          }),
        ) + `?calcDate=${toCalcDateTimestamp(row.date)}`,
      );
      clearSelectedInstructions();
    }
  };

  const onContextMenu = (e: DataTableRowEvent) => {
    cm?.current?.show(e.originalEvent);
  };

  const onInstructionsContextMenuCommand = (
    item: InstructionContextMenuItem,
  ) => {
    switch (item.id) {
      case InstructionContextMenuItemIds.Card:
      case InstructionContextMenuItemIds.Edit:
        if (selectedInstruction) {
          navigate(
            buildPath(
              generatePath(paths.editInstruction, {
                masterId: selectedInstruction.id,
              }),
            ) + `?calcDate=${toCalcDateTimestamp(selectedInstruction.date)}`,
          );
        }

        clearSelectedInstructions();
        break;
      case InstructionContextMenuItemIds.Copy:
        if (selectedInstruction?.id) {
          copyInstruction(selectedInstruction.id);
          clearSelectedInstructions();
        }
        break;
      case InstructionContextMenuItemIds.Create:
        clearSelectedInstructions();
        navigate(buildPath(generatePath(paths.createInstruction)));
        break;
      default:
        return null;
    }
  };

  const operationsHistoryClose = () => {
    setVisibleHistoryOperationsModal(false);
    clearSelectedInstructions();
  };

  return {
    cm,
    onContextMenuSelectionChange,
    onSelectionChange,
    onRowDoubleClick,
    onContextMenu,
    visibleHistoryOperationsModal,
    onInstructionsContextMenuCommand,
    operationsHistoryClose,
  };
};
