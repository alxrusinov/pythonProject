// Упрощенный тип для данных из запроса, содержащий только используемые поля
import { IrcInstruction } from 'graphql/generated/generated';

export type InstructionRowData = {
  id?: IrcInstruction['id'] | null;
  status?: { name?: string | null } | null;
  instructionType?: { id?: string | null; name?: string | null } | null;
  number?: string | null;
  stationFromName?: string | null;
  date?: Date | null;
  senderStation?: {
    name?: string | null;
    railway?: { shortName?: string | null };
  } | null;
  receiverStation?: {
    name?: string | null;
    railway?: { shortName?: string | null };
  } | null;
  client?: { name?: string | null; shortName?: string | null } | null;
  manualClientName?: string | null;
  senderRecip?: { shortName?: string | null } | null;
  recieverRecip?: { shortName?: string | null } | null;
  recieverManualRecipName?: string | null;
  parent?: {
    number?: string | null;
    date?: string | null;
  } | null;
  cars?: Array<{ number?: string | null }> | null;
  sendNotFullCompOper?: boolean | null;
  sendFullCompOper?: boolean | null;
  createDate?: string | null;
  lastDate?: string | null;
  createUser?: {
    id?: string | null;
    shortName?: string | null;
    fullName?: string | null;
  } | null;
  lastUser?: {
    id?: string | null;
    shortName?: string | null;
    fullName?: string | null;
  } | null;
};

const formatUserShortName = (
  user:
    | {
        shortName?: string | null;
      }
    | null
    | undefined,
): string | null => {
  const shortName = user?.shortName?.trim();
  return shortName || null;
};

const formatUserFullName = (
  user:
    | {
        fullName?: string | null;
      }
    | null
    | undefined,
): string | null => {
  const fullName = user?.fullName?.trim();
  return fullName || null;
};

export const columnSelectors = {
  id: (data: InstructionRowData) => data.id,
  statusName: (data: InstructionRowData) => data.status?.name,
  typeName: (data: InstructionRowData) => data.instructionType?.name,
  number: (data: InstructionRowData) => data.number,
  stationFromName: (data: InstructionRowData) => data.stationFromName,
  date: (data: InstructionRowData) => (data.date ? new Date(data.date) : null),
  senderStationName: (data: InstructionRowData) => data.senderStation?.name,
  senderRailwayName: (data: InstructionRowData) =>
    data.senderStation?.railway?.shortName,
  receiverStationName: (data: InstructionRowData) => data.receiverStation?.name,
  receiverRailwayName: (data: InstructionRowData) =>
    data.receiverStation?.railway?.shortName,
  clientName: (data: InstructionRowData) => data.client?.shortName,
  manualClientName: (data: InstructionRowData) => data.manualClientName,
  senderRecipName: (data: InstructionRowData) => data.senderRecip?.shortName,
  recieverRecipName: (data: InstructionRowData) =>
    data.recieverRecip?.shortName,
  recieverManualRecipName: (data: InstructionRowData) =>
    data.recieverManualRecipName,
  parentNumber: (data: InstructionRowData) => data.parent?.number,
  parentDate: (data: InstructionRowData) =>
    data.parent?.date ? new Date(data.parent.date) : null,
  cars: (data: InstructionRowData) =>
    data.cars ? data.cars.map(car => Number(car?.number)) : [],
  carsCount: (data: InstructionRowData) => data.cars?.length ?? 0,
  sendNotFullCompOper: (data: InstructionRowData) => data.sendNotFullCompOper,
  sendFullCompOper: (data: InstructionRowData) => data.sendFullCompOper,
  createDate: (data: InstructionRowData) =>
    data.createDate ? new Date(data.createDate) : null,
  lastDate: (data: InstructionRowData) =>
    data.lastDate ? new Date(data.lastDate) : null,
  createUserId: (data: InstructionRowData) => data.createUser?.id ?? null,
  lastUserId: (data: InstructionRowData) => data.lastUser?.id ?? null,
  createUserName: (data: InstructionRowData) =>
    formatUserShortName(data.createUser),
  createUserFullName: (data: InstructionRowData) =>
    formatUserFullName(data.createUser),
  lastUserName: (data: InstructionRowData) =>
    formatUserShortName(data.lastUser),
  lastUserFullName: (data: InstructionRowData) =>
    formatUserFullName(data.lastUser),
} as const;

export type ColumnKey = keyof typeof columnSelectors;

export type TransformedRow = {
  [K in ColumnKey]: ReturnType<(typeof columnSelectors)[K]>;
};

export const mapToRow = (c: InstructionRowData): TransformedRow => {
  const entries = Object.entries(columnSelectors).map(([k, sel]) => [
    k,
    (sel as (x: InstructionRowData) => unknown)(c),
  ]);
  return Object.fromEntries(entries) as TransformedRow;
};
