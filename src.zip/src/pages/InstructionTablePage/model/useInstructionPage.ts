import {
  IrcInstructionFilterInput,
  useGetInstructionsLazyQuery,
} from 'graphql/generated/generated';
import { useContext, useEffect, useMemo } from 'react';

import { useApolloLazyQueryPage } from 'core_client/apollo';

import { DataService } from 'shared_ui/components';
import type { IFilter } from 'shared_ui/components/DataServiceFilter/contexts/DataServiceFilterContext';

import {
  InstructionRowData,
  mapToRow,
  TransformedRow,
} from '../model/columnSelectors';

const omitCarsCountFromWhere = (input: unknown): unknown => {
  if (input == null || typeof input !== 'object') {
    return input;
  }
  if (Array.isArray(input)) {
    return input.map(omitCarsCountFromWhere);
  }
  const obj = input as Record<string, unknown>;
  const next: Record<string, unknown> = { ...obj };
  delete next.carsCount;
  for (const k of Object.keys(next)) {
    next[k] = omitCarsCountFromWhere(next[k]);
  }
  return next;
};

const BOOLEAN_FILTER_FIELDS = new Set([
  'sendNotFullCompOper',
  'sendFullCompOper',
]);
const BOOLEAN_OPERATIONS = new Set(['eq', 'neq', 'in', 'nin', 'iin', 'inin']);

const toBooleanValue = (value: unknown): unknown => {
  if (typeof value === 'boolean') return value;
  if (value === 1 || value === '1') return true;
  if (value === 0 || value === '0') return false;
  return value;
};

const normalizeBooleanFilterValues = (
  input: unknown,
  parentField?: string,
): unknown => {
  if (input == null || typeof input !== 'object') {
    return input;
  }
  if (Array.isArray(input)) {
    return input.map(item => normalizeBooleanFilterValues(item, parentField));
  }

  const obj = input as Record<string, unknown>;
  const next: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(obj)) {
    if (
      BOOLEAN_FILTER_FIELDS.has(parentField ?? '') &&
      BOOLEAN_OPERATIONS.has(key)
    ) {
      if (Array.isArray(value)) {
        next[key] = value.map(toBooleanValue);
      } else {
        next[key] = toBooleanValue(value);
      }
      continue;
    }

    const nextParent = BOOLEAN_FILTER_FIELDS.has(key) ? key : parentField;
    next[key] = normalizeBooleanFilterValues(value, nextParent);
  }

  return next;
};

const matchesCarsCountFilter = (count: number, f: IFilter): boolean => {
  const raw = f.value;
  const c = f.condition;

  if (c === 'in' || c === 'iin') {
    const arr = Array.isArray(raw) ? raw : raw != null ? [raw] : [];
    const nums = arr.map(x => Number(x)).filter(x => !Number.isNaN(x));
    return nums.includes(count);
  }
  if (c === 'nin' || c === 'inin') {
    const arr = Array.isArray(raw) ? raw : raw != null ? [raw] : [];
    const nums = arr.map(x => Number(x)).filter(x => !Number.isNaN(x));
    return !nums.includes(count);
  }

  const v = Number(raw);
  if (Number.isNaN(v)) {
    return true;
  }

  switch (c) {
    case 'eq':
      return count === v;
    case 'neq':
      return count !== v;
    case 'gt':
      return count > v;
    case 'gte':
      return count >= v;
    case 'lt':
      return count < v;
    case 'lte':
      return count <= v;
    case 'ngt':
      return !(count > v);
    case 'ngte':
      return !(count >= v);
    case 'nlt':
      return !(count < v);
    case 'nlte':
      return !(count <= v);
    default:
      return true;
  }
};

const matchesCarsFilter = (
  cars: Array<number | null | undefined>,
  f: IFilter,
) => {
  const condition = String(f.condition ?? '').toLowerCase();
  const source = cars
    .map(v => (v == null ? '' : String(v)))
    .join(' ')
    .toLowerCase();
  const filterValue = String(f.value ?? '')
    .trim()
    .toLowerCase();

  if (!filterValue) return true;

  if (
    condition === 'ncontains' ||
    condition === 'incontains' ||
    condition === 'nin' ||
    condition === 'inin'
  ) {
    return !source.includes(filterValue);
  }
  if (
    condition === 'contains' ||
    condition === 'icontains' ||
    condition === 'in' ||
    condition === 'iin'
  ) {
    return source.includes(filterValue);
  }

  // Для остальных условий не вмешиваемся.
  return true;
};

const normalizeCarsFilterValue = (value: unknown): string => {
  if (Array.isArray(value)) {
    return value
      .map(v => (v == null ? '' : String(v).trim()))
      .filter(Boolean)
      .join(' ');
  }
  return value == null ? '' : String(value).trim();
};

const remapCarsWhereCondition = (
  input: unknown,
  carsCondition?: string,
  carsValue?: unknown,
): unknown => {
  if (input == null || typeof input !== 'object' || !carsCondition) {
    return input;
  }
  if (Array.isArray(input)) {
    return input.map(item =>
      remapCarsWhereCondition(item, carsCondition, carsValue),
    );
  }

  const obj = input as Record<string, unknown>;
  const next: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(obj)) {
    if (key === 'cars' && value && typeof value === 'object') {
      const carsObj = value as Record<string, unknown>;
      const someObj = carsObj.some as Record<string, unknown> | undefined;
      const numberObj =
        someObj && typeof someObj.number === 'object'
          ? (someObj.number as Record<string, unknown>)
          : undefined;

      if (numberObj) {
        const normalizedValue = normalizeCarsFilterValue(carsValue);
        if (
          carsCondition === 'ncontains' ||
          carsCondition === 'incontains' ||
          carsCondition === 'nin' ||
          carsCondition === 'inin'
        ) {
          next[key] = {
            ...carsObj,
            some: {
              ...someObj,
              number: normalizedValue ? { nin: normalizedValue } : numberObj,
            },
          };
          continue;
        }

        if (
          carsCondition === 'contains' ||
          carsCondition === 'icontains' ||
          carsCondition === 'in' ||
          carsCondition === 'iin'
        ) {
          next[key] = {
            ...carsObj,
            some: {
              ...someObj,
              number: normalizedValue ? { in: normalizedValue } : numberObj,
            },
          };
          continue;
        }
      }
    }

    next[key] = remapCarsWhereCondition(value, carsCondition, carsValue);
  }

  return next;
};

export const useInstructionPage = () => {
  const { tableColumns, filtersWhereGraphQLStatement, filters } = useContext(
    DataService.DataServiceContext,
  );

  const extractData = (data: any) => data?.ircInstructions;
  const [getInstructions] = useGetInstructionsLazyQuery();
  const { items, loading, load } = useApolloLazyQueryPage({
    pageSize: 100,
    total: 1000,
    extractData,
    lazyQuery: getInstructions,
  });

  useEffect(() => {
    if (
      !filtersWhereGraphQLStatement ||
      Object.keys(filtersWhereGraphQLStatement).length === 0
    ) {
      return;
    }
    const where = normalizeBooleanFilterValues(
      omitCarsCountFromWhere(filtersWhereGraphQLStatement),
    ) as IrcInstructionFilterInput;
    const carsFilter = (filters ?? []).find(x => x.fieldName === 'cars');
    const whereWithCarsCondition = remapCarsWhereCondition(
      where,
      String(carsFilter?.condition ?? '').toLowerCase(),
      carsFilter?.value,
    ) as IrcInstructionFilterInput;
    load({
      variables: {
        where: whereWithCarsCondition,
      },
      fetchPolicy: 'no-cache',
    } as any);
  }, [filtersWhereGraphQLStatement, filters]);

  const transformedData = useMemo<TransformedRow[]>(() => {
    const rows = (items ?? []).map(item =>
      mapToRow(item as InstructionRowData),
    );
    const carsCountFilters = (filters ?? []).filter(
      x => x.fieldName === 'carsCount',
    );
    const carsFilters = (filters ?? []).filter(x => x.fieldName === 'cars');

    return rows.filter(row => {
      const carsCountOk =
        !carsCountFilters.length ||
        carsCountFilters.every(f => matchesCarsCountFilter(row.carsCount, f));

      const carsOk =
        !carsFilters.length ||
        carsFilters.every(f => matchesCarsFilter(row.cars, f));

      return carsCountOk && carsOk;
    });
  }, [items, filters]);

  return {
    instructionColumnsMetaData: tableColumns as any,
    transformedData,
    loading,
  };
};
