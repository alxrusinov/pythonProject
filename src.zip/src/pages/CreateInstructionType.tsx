import { InstructionTypeForm } from 'widgets/InstructionTypeForm';

import { InstructionTypeFormLayout } from 'shared/ui/InstructionTypeFormLayout';

export const CreateInstructionType = () => {
  return (
    <InstructionTypeFormLayout>
      <InstructionTypeForm />
    </InstructionTypeFormLayout>
  );
};
