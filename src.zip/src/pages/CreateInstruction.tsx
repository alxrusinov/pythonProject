import { InstructionForm } from 'widgets/InstructionForm';

import { InstructionFormLayout } from 'shared/ui/InstructionFormLayout';

export const CreateInstruction = () => {
  return (
    <InstructionFormLayout>
      <InstructionForm />
    </InstructionFormLayout>
  );
};
