import { InstructionTypeForm } from 'widgets/InstructionTypeForm';

import { InstructionTypeFormLayout } from 'shared/ui/InstructionTypeFormLayout';

export const EditInstructionType = () => {
  return (
    <InstructionTypeFormLayout>
      <InstructionTypeForm />
    </InstructionTypeFormLayout>
  );
};
