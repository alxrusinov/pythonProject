import { OrgEmailForm } from 'widgets/OrgEmailForm';

export const EditOrgEmail = () => {
  return <OrgEmailForm mode="edit" />;
};
