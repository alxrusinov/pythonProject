import { StatusEnum } from 'graphql/generated/generated';

export const statusMap: Record<StatusEnum, string> = {
  [StatusEnum.Acknowledged]: 'Принят',
  [StatusEnum.Completed]: 'Выполнен',
  [StatusEnum.Failed]: 'Ошибка',
  [StatusEnum.InProgress]: 'На расчете',
  [StatusEnum.Preparation]: 'В подготовке',
  [StatusEnum.Stopped]: 'Приостановлен',
  [StatusEnum.RegistrationFailed]: 'Регистрация провалена',
};
