export const NO_DATA_MARK = '-';
