const isSamePort = (host: string) => {
  if (!host.includes('://')) return false;
  try {
    const url = new URL(host);
    return url.port === window.location.port;
  } catch {
    return false;
  }
};

export const buildPath = (path: string) => {
  const host = process.env.REACT_APP_HOST || '';
  const appName = process.env.REACT_APP_NAME || '';

  const prefix = !isSamePort(host) && appName ? `/${appName}` : '';

  return `${prefix}/${path}`;
};
