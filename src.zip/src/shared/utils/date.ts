/** Текущая дата и время в ISO формате (для requestDate в запросах) */
export const getStableRequestDate = (): string => {
  return new Date().toISOString();
};

/** Timestamp для query-параметра calcDate при открытии версии инструкции. */
export const toCalcDateTimestamp = (
  value: string | number | Date | null | undefined,
): number => {
  if (value == null) return Date.now();
  if (typeof value === 'number') return value;
  const timestamp = new Date(value).getTime();
  return Number.isNaN(timestamp) ? Date.now() : timestamp;
};

export const parseDateSafe = (
  value: string | Date | null | undefined,
): Date | null => {
  if (value == null || value === '') return null;
  if (value instanceof Date) {
    if (typeof value.getTime !== 'function') return null;
    const timestamp = value.getTime();
    return Number.isNaN(timestamp) ? null : value;
  }
  if (typeof value !== 'string') return null;
  const d = new Date(value);
  if (!Number.isNaN(d.getTime())) return d;
  const parts = value.trim().split(/[./-]/);
  if (parts.length >= 3) {
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    let year = parseInt(parts[2], 10);
    if (year < 100) year += year >= 50 ? 1900 : 2000;
    const parsed = new Date(year, month, day);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }
  return null;
};
