/**
 * Расшифровки кодов ошибок операций с инструкциями (IrcInstructionOperationErrorCode).
 */
export const IRC_INSTRUCTION_OPERATION_ERROR_MESSAGES: Record<string, string> = {
  EMAIL_RECIPIENTS_NOT_FOUND:
    'Для выбранного получателя отсутствуют email-адреса. Укажите email-адреса для получателя в справочнике email-адресов и попробуйте снова.',
  EMAIL_TEXT_NOT_FOUND: 'Текст электронного письма инструкции не найден',
  ERROR_CREATE_FILE_FROM_TEMPLATE:
    'Ошибка создания файла инструкции из шаблона',
  ERROR_SEND_BY_EMAIL:
    'У Вас нет прав на отправку инструкции. Обратитесь к системному администратору.',
  FILE_FORMAT_NOT_FOUND: 'Формат файла инструкции не найден',
  FILE_FORMAT_NOT_SUPPORTED: 'Формат файла инструкции не поддерживается',
  FILE_SOURCE_TYPE_NOT_SUPPORTED:
    'Тип источника файла инструкции не поддерживается',
  NOT_FOUND: 'Инструкция не найдена',
  OPERATION_ERROR: 'Ошибка выполнения операции',
  OPERATION_FOR_PARENT_NOT_AVAILABLE:
    'Операция из родительской инструкции недоступна',
  OPERATION_FROM_PARENT_NOT_AVAILABLE:
    'Операция из родительской инструкции недоступна',
  OPERATION_NOT_AVAILABLE: 'Операция инструкции недоступна',
  OPERATION_NOT_SUPPORTED: 'Операция инструкции не поддерживается',
  PARENT_NOT_FOUND: 'Родительская инструкция не найдена',
  TEMPLATE_NOT_FOUND: 'Шаблон инструкции не найден',
  TYPE_FILE_NOT_FOUND: 'Файл типа инструкции не найден',
  TYPE_NOT_FOUND: 'Тип инструкции не найден',
  USER_FILE_NOT_FOUND: 'Файл пользователя инструкции не найден',
};

/**
 * Расшифровки кодов ошибок операций с типом инструкции (IrcInstructionTypeOperationErrorCode).
 */
const IRC_INSTRUCTION_TYPE_OPERATION_ERROR_MESSAGES: Record<string, string> = {
  OPERATION_ERROR: 'Ошибка выполнения операции',
  TYPE_DATE_FROM_LESS_SYSTEM_DATE:
    'Дата начала действия типа инструкции меньше системной даты',
  TYPE_DATE_TO_LESS_DATE_FROM:
    'Дата окончания действия типа инструкции меньше даты начала',
  TYPE_DATE_TO_LESS_SYSTEM_DATE:
    'Дата окончания действия типа инструкции меньше системной даты',
  TYPE_FILE_DATE_FROM_LESS_SYSTEM_DATE:
    'Дата начала действия файла типа инструкции меньше системной даты',
  TYPE_FILE_DATE_TO_LESS_DATE_FROM:
    'Дата окончания действия файла типа инструкции меньше даты начала',
  TYPE_FILE_DATE_TO_LESS_SYSTEM_DATE:
    'Дата окончания действия файла типа инструкции меньше системной даты',
  TYPE_FILE_DUPLICATE: 'Дубликат файла типа инструкции',
  TYPE_FILE_NAME_ALREADY_EXISTS:
    'Название файла типа инструкции уже существует',
  TYPE_FILE_NAME_INVALID: 'Название файла типа инструкции недействителено',
  TYPE_FILE_NOT_FOUND: 'Файл типа инструкции не найден',
  TYPE_NAME_ALREADY_EXISTS_ON_DATE:
    'Название типа инструкции уже существует на дату',
  TYPE_NAME_INVALID: 'Название типа инструкции недействителено',
  TYPE_NOT_FOUND: 'Тип инструкции не найден',
};

/**
 * Расшифровки кодов ошибок операций с адресами электронной почты (IrcOrgEmailsErrorCodes).
 */
const IRC_ORG_EMAILS_ERROR_MESSAGES: Record<string, string> = {
  EMAIL_INVALID: 'Адрес электронной почты недействителен',
  OPERATION_ERROR: 'Ошибка выполнения операции',
};

export type OperationErrorContext = 'instruction' | 'instructionType';

export type OperationErrorPayload =
  | {
      code?: string | null;
      message?: string | null;
    }
  | null
  | undefined;

/**
 * Нормализует строку кода ошибки к виду UPPER_SNAKE_CASE для поиска в enum-картах.
 */
const normalizeErrorCode = (value: string): string => {
  return String(value).trim().toUpperCase().replace(/\s+/g, '_');
};

/**
 * Возвращает расшифровку ошибки по коду для контекста инструкции
 * (IrcInstructionOperationErrorCode + IrcOrgEmailsErrorCodes)
 * или типа инструкции (IrcInstructionTypeOperationErrorCode + IrcOrgEmailsErrorCodes).
 * Если код не найден в enum — возвращается сырое сообщение или код.
 */
export const decodeOperationError = (
  error: OperationErrorPayload,
  context: OperationErrorContext,
): string => {
  if (!error) return '';
  const rawMessage = error.message ?? '';
  const code = error.code ?? '';

  const instructionMap = {
    ...IRC_INSTRUCTION_OPERATION_ERROR_MESSAGES,
    ...IRC_ORG_EMAILS_ERROR_MESSAGES,
  };
  const instructionTypeMap = {
    ...IRC_INSTRUCTION_TYPE_OPERATION_ERROR_MESSAGES,
    ...IRC_ORG_EMAILS_ERROR_MESSAGES,
  };
  const map = context === 'instruction' ? instructionMap : instructionTypeMap;

  const byCode = code && map[normalizeErrorCode(code)];
  if (byCode) return byCode;

  const messageAsCode = rawMessage && map[normalizeErrorCode(rawMessage)];
  if (messageAsCode) return messageAsCode;

  return rawMessage || code || 'Неизвестная ошибка';
};
