export const matchById = <T extends { id?: number | string | null }>(
  list: T[],
  id: number | string | null | undefined,
): T | undefined =>
  id == null ? undefined : list.find(item => item.id != null && item.id == id);
