import { EntityNotificationExtension } from 'graphql/generated/generated';

const tryParseExtensionValue = (value: string | null | undefined): unknown => {
  if (value == null || value === '') return null;
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
};

export const getEntityNotificationExtensionValue = (
  extensions: ReadonlyArray<EntityNotificationExtension>,
  key: string,
): unknown => {
  const ext = extensions.find(item => item.key === key);
  if (!ext) return null;
  return tryParseExtensionValue(ext.value);
};

export const entityNotificationExtensionsToRecord = (
  extensions: ReadonlyArray<EntityNotificationExtension>,
): Record<string, unknown> => {
  const record: Record<string, unknown> = {};
  for (const ext of extensions) {
    const parsed = tryParseExtensionValue(ext.value);
    if (parsed != null) {
      record[ext.key] = parsed;
    }
  }
  return record;
};
