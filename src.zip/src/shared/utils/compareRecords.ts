interface RecordWithId {
  id?: string | number | null | undefined;
}

export const compareRecords = <T extends RecordWithId>(
  allRecords: T[],
  restoredRecord: T,
): T[] => {
  const restoredRecordIndex = allRecords.findIndex(
    item => item.id === restoredRecord.id,
  );

  if (restoredRecordIndex > -1) {
    return allRecords;
  }

  return [restoredRecord, ...allRecords];
};
