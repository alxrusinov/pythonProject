import axios, { AxiosRequestConfig } from 'axios';

const baseApiUrl = process.env.REACT_APP_API_FILE;

const axiosInstance = axios.create({
  baseURL: baseApiUrl,
});

export const api = {
  uploadFile: <T>(
    url: string,
    formData: FormData,
    config?: AxiosRequestConfig,
  ): Promise<T> =>
    axiosInstance.post(url, formData, config).then(({ data }) => data),
};
