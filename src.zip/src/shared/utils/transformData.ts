import { UUID } from 'shared_ui/utils';

type Transformed<
  T,
  TDateFields extends keyof T,
  TStringFields extends keyof T,
> = Omit<T, TDateFields | TStringFields> & {
  [K in TDateFields]: Date;
} & {
  [K in TStringFields]: string;
};

type AddIdIfMissing<T> = T extends { id: unknown } ? T : T & { id: string };

type TransformDataParams<
  T,
  TDateFields extends keyof T,
  TStringFields extends keyof T,
> = {
  data: T[] | undefined;
  fieldsToConvertDate?: TDateFields[];
  fieldsToConvertString?: TStringFields[];
};

export const transformData = <
  T,
  TDateFields extends keyof T,
  TStringFields extends keyof T,
>({
  data,
  fieldsToConvertDate,
  fieldsToConvertString,
}: TransformDataParams<T, TDateFields, TStringFields>) => {
  if (!data) return [];
  return data.map(item => {
    const newItem = {
      ...item,
    } as Omit<T, TDateFields | TStringFields> & {
      [K in TDateFields]: T[K] | Date;
    } & {
      [K in TStringFields]: T[K] | string;
    };

    fieldsToConvertDate?.forEach(field => {
      if (newItem[field]) {
        newItem[field] = new Date(
          newItem[field] as string | number | Date,
        ) as T[TDateFields];
      }
    });

    fieldsToConvertString?.forEach(field => {
      if (newItem[field] != null) {
        newItem[field] = String(newItem[field]) as T[TStringFields];
      }
    });

    if (!('id' in newItem)) {
      (
        newItem as AddIdIfMissing<Transformed<T, TDateFields, TStringFields>>
      ).id = UUID();
    }

    return newItem as AddIdIfMissing<
      Transformed<T, TDateFields, TStringFields>
    >;
  });
};
