/**
 * Заменяет точки в имени файла (до расширения) на подчёркивания,
 * чтобы сервер и браузер корректно определяли расширение.
 *
 * "Пропл. телеграмма.pdf" → "Пропл_ телеграмма.pdf"
 * "report.v2.final.pdf"   → "report_v2_final.pdf"
 */
export const sanitizeFileName = (name: string): string => {
  const lastDot = name.lastIndexOf('.');
  if (lastDot <= 0) return name;

  const stem = name.slice(0, lastDot).replace(/\./g, '_');
  const ext = name.slice(lastDot);
  return `${stem}${ext}`;
};

/** Конвертирует файл в строку base64 (без префикса data-URI). */
export const toBase64 = (convertedFile: File) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.readAsDataURL(convertedFile);
    reader.onload = () => {
      const result = reader.result;
      let fileBase64: string | undefined;
      if (typeof result === 'string') {
        fileBase64 = result.split(',').pop();
      }
      resolve(fileBase64);
    };
    reader.onerror = error => {
      console.error('Ошибка при чтении файла:', error);
      reject(error);
    };
  });
};
