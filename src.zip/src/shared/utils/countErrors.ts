export const countErrors = (obj: unknown) => {
  if (!obj || typeof obj !== 'object') return 0;

  let count = 0;
  const stack: unknown[] = [obj];

  while (stack.length > 0) {
    const current = stack.pop();

    if (!current || typeof current !== 'object') continue;

    if ('message' in current || 'type' in current) {
      count += 1;
      continue;
    }

    if (Array.isArray(current)) {
      for (const item of current) {
        if (item && typeof item === 'object') {
          stack.push(item);
        }
      }
    } else {
      for (const value of Object.values(current)) {
        if (value && typeof value === 'object') {
          stack.push(value);
        }
      }
    }
  }

  return count;
};
