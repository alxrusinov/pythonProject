/** Данные адреса из разных фрагментов: где-то `name`, где-то `address` */
export type ImpOrgAddressLike = {
  id?: string | number | null;
  name?: string | null;
  address?: string | null;
  codeTgnl?: number | null;
  /** ОКПО организации (с паспорта), для подписи в селекте адреса */
  orgPassport?: { okpo?: string | null } | null;
};

/** Текст в селекте адреса: адрес и явные подписи ОКПО / ТГНЛ */
export const formatImpOrgAddressSelectLabel = (
  name?: string | null,
  codeTgnl?: number | null,
  orgOkpo?: string | null,
): string => {
  const address = (name ?? '').trim();
  const okpo = (orgOkpo ?? '').trim();
  const tgnl =
    codeTgnl != null && Number.isFinite(Number(codeTgnl))
      ? String(codeTgnl)
      : '';

  const codeParts: string[] = [];
  if (okpo) codeParts.push(`ОКПО: ${okpo}`);
  if (tgnl) codeParts.push(`ТГНЛ: ${tgnl}`);
  const codesJoined = codeParts.join(', ');

  if (address && codesJoined) return `${address} · ${codesJoined}`;
  if (address) return address;
  if (codesJoined) return codesJoined;
  return '';
};

/** Строка подписи по объекту адреса (учитывает и `name`, и `address`) */
export const getImpOrgAddressSelectLine = (
  row: ImpOrgAddressLike | null | undefined,
): string =>
  formatImpOrgAddressSelectLabel(
    row?.name ?? row?.address ?? null,
    row?.codeTgnl ?? null,
    row?.orgPassport?.okpo ?? null,
  );

export type ImpOrgAddressForSelect<
  T extends ImpOrgAddressLike = ImpOrgAddressLike,
> = T & { addressSelectLabel: string };

/** PrimeReact Dropdown требует строковый `optionLabel`, иначе в скрытый `<option>` попадает объект */
export const enrichImpOrgAddressForSelect = <T extends ImpOrgAddressLike>(
  row: T,
): ImpOrgAddressForSelect<T> => ({
  ...row,
  addressSelectLabel: getImpOrgAddressSelectLine(row),
});

export const enrichImpOrgAddressesForSelect = <T extends ImpOrgAddressLike>(
  list: T[],
): ImpOrgAddressForSelect<T>[] => list.map(enrichImpOrgAddressForSelect);
