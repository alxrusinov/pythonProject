import type { ITableColumn } from 'shared_ui/components';

type ConverterColumn = {
  field: string;
  title: string;
  type?: 'string' | 'boolean' | 'int' | 'float';
};
type ConverterRow = Record<
  string,
  string | number | boolean | Date | null | undefined
>;

export const toColumns = (tableMetaData: ITableColumn[]): ConverterColumn[] => {
  return (tableMetaData ?? [])
    .filter(c => typeof (c as any)?.field === 'string')
    .map(c => ({
      field: String((c as any).field),
      title: String((c as any).header ?? (c as any).field ?? ''),
    }));
};

export const toRows = (
  columns: Array<{ field: string }>,
  value: Array<Record<string, unknown>> | undefined,
): ConverterRow[] => {
  const src = (value ?? []) as Array<Record<string, unknown>>;
  return src.map(row => {
    const out: ConverterRow = {};
    for (const c of columns) {
      const v = row?.[c.field];
      out[c.field] =
        v instanceof Date ||
        typeof v === 'string' ||
        typeof v === 'number' ||
        typeof v === 'boolean'
          ? v
          : v == null
            ? null
            : String(v);
    }
    return out;
  });
};
