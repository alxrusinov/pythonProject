import { Button, Card } from 'shared_ui/components';

interface IProps {
  onOpenFilters: VoidFunction;
}

export const FiltersPlaceholder = ({ onOpenFilters }: IProps) => {
  return (
    <Card className="flex flex-column align-items-center justify-content-center gap-3 h-full w-full">
      <div className="flex flex-column align-items-center justify-content-center gap-3 w-full">
        <span className="text-lg text-color-secondary">Фильтр не выбран</span>
      </div>
      <Button label="Добавить фильтр" onClick={onOpenFilters} />
    </Card>
  );
};
