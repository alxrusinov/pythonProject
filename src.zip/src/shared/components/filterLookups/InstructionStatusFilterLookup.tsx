import { useInstructionStatusesForLookupLazyQuery } from 'graphql/generated/generated';
import { FC } from 'react';

import { FilterLookupComponentProps } from './types';

import { LookupTemplate } from '../LookupTemplate';

export const InstructionStatusFilterLookup: FC<FilterLookupComponentProps> = ({
  onChange,
  defaultValue,
  displayValue,
  disabled,
  className,
}) => {
  return (
    <LookupTemplate
      useLazyQueryHook={useInstructionStatusesForLookupLazyQuery as any}
      onChange={onChange}
      defaultValue={defaultValue}
      displayValue={displayValue}
      disabled={disabled}
      className={className}
      searchField="name"
      itemsPath="ircStatuses.items"
      searchMatch="contains"
    />
  );
};
