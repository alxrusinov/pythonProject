import { useImpOrgPassportsLazyQuery } from 'graphql/generated/generated';
import { FC } from 'react';

import { FilterLookupComponentProps } from './types';

import { getStableRequestDate } from 'shared/utils/date';

import { LookupTemplate } from '../LookupTemplate';

export const ClientFilterLookup: FC<FilterLookupComponentProps> = ({
  onChange,
  defaultValue,
  displayValue,
  disabled,
  className,
}) => {
  return (
    <LookupTemplate
      useLazyQueryHook={useImpOrgPassportsLazyQuery as any}
      onChange={onChange}
      defaultValue={defaultValue}
      displayValue={displayValue}
      disabled={disabled}
      className={className}
      searchField="name"
      itemsPath="impOrgPassports.items"
      constVars={{ requestDate: getStableRequestDate() }}
      staticFilters={[{ lastRec: { eq: true } }]}
      searchMatch="contains"
    />
  );
};
