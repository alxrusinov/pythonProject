import { ComponentProps } from 'react';

import { SelectAsync } from 'shared_ui/components';
import { IFilter } from 'shared_ui/components/DataServiceFilter/contexts/DataServiceFilterContext';

export interface FilterLookupComponentProps
  extends Omit<ComponentProps<typeof SelectAsync>, 'onChange' | 'defaultValue'> {
  defaultValue?: string | number;
  displayValue?: string;
  onChange(value: IFilter['value'], displayTitle: string): void;
}
