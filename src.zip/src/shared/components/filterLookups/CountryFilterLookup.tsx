import { useNsiCountriesLazyQuery } from 'graphql/generated/generated';
import { FC } from 'react';

import { FilterLookupComponentProps } from './types';

import { getStableRequestDate } from 'shared/utils/date';

import { LookupTemplate } from '../LookupTemplate';

export const CountryFilterLookup: FC<FilterLookupComponentProps> = ({
  onChange,
  defaultValue,
  displayValue,
  disabled,
  className,
}) => {
  return (
    <LookupTemplate
      useLazyQueryHook={useNsiCountriesLazyQuery as any}
      onChange={onChange}
      defaultValue={defaultValue}
      displayValue={displayValue}
      disabled={disabled}
      className={className}
      searchField="name"
      itemsPath="nsiCountries.items"
      constVars={{ requestDate: getStableRequestDate() }}
      searchMatch="contains"
    />
  );
};
