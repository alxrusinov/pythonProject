import { useUserInfosLazyQuery } from 'graphql/generated/generated';
import { FC } from 'react';

import { FilterLookupComponentProps } from './types';

import { LookupTemplate } from '../LookupTemplate';

export const UserInfoFilterLookup: FC<FilterLookupComponentProps> = ({
  onChange,
  defaultValue,
  displayValue,
  disabled,
  className,
}) => (
  <LookupTemplate<string>
    useLazyQueryHook={useUserInfosLazyQuery as any}
    onChange={onChange}
    defaultValue={defaultValue}
    displayValue={displayValue}
    disabled={disabled}
    className={className}
    searchField="fullName"
    itemsPath="userInfos.items"
    searchMatch="contains"
  />
);
