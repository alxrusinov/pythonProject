import { useGetNsiRailwaysLazyQuery } from 'graphql/generated/generated';
import { FC } from 'react';

import { IFilterLookupComponent } from 'shared_ui/components/DataServiceFilter/contexts/DataServiceFilterContext';

import { getStableRequestDate } from 'shared/utils/date';

import { LookupTemplate } from '../LookupTemplate';

export const RailwayFilterLookup: FC<IFilterLookupComponent> = ({
  onChange,
  defaultValue,
  displayValue,
  disabled,
  className,
}) => {
  return (
    <LookupTemplate
      useLazyQueryHook={useGetNsiRailwaysLazyQuery as any}
      onChange={onChange}
      defaultValue={defaultValue}
      displayValue={displayValue}
      disabled={disabled}
      className={className}
      searchField="shortName"
      extraField="name"
      itemsPath="nsiRailways.items"
      constVars={{ requestDate: getStableRequestDate() }}
      searchMatch="contains"
      skipEmptyQuery
    />
  );
};
