import { ReactNode } from 'react';

import { Card, ColumnFilterSearchClear } from 'shared_ui/components';

import styles from './TableHeaderTemplate.module.scss';

interface IProps {
  showSearch?: boolean;
  searchValue?: string;
  onSearch?: (value: string) => void;
  onClearLocalFilters?: () => void;
  children?: ReactNode;
}

export const TableHeaderTemplate = ({
  children,
  onSearch,
  searchValue,
  onClearLocalFilters,
  showSearch = true,
}: IProps) => {
  return (
    <Card className="flex justify-content-between p-2">
      <div className={styles.search}>
        {showSearch && (
          <ColumnFilterSearchClear
            variant="search"
            onChange={onSearch}
            value={searchValue}
          />
        )}
        {onClearLocalFilters && (
          <ColumnFilterSearchClear
            variant="clear"
            clearFilters={onClearLocalFilters}
          />
        )}
      </div>
      <div className="flex gap-2 align-items-center">{children}</div>
    </Card>
  );
};
