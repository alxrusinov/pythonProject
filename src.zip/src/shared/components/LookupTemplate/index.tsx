import { Icons, SelectAsync } from 'shared_ui/components';

import styles from './LookupSimple.select.module.scss';
import type { LookupTemplateProps, QueryVars } from './types';
import { useLookupTemplate } from './useLookupTemplate';

export type { ISuggestion } from './types';

export const LookupTemplate = <
  TCode extends string | number = number,
  TOut = number,
  TVars extends QueryVars = QueryVars,
  TData = unknown,
>(
  props: LookupTemplateProps<TVars, TData, TCode, TOut>,
) => {
  const {
    value,
    suggestions,
    completeMethod,
    disabled,
    handleChange,
    showDropdown,
    handleShow,
    handleHide,
  } = useLookupTemplate<TCode, TOut, TVars, TData>(props);

  const placeholder = props.placeholder ?? 'Выберите значение';

  const cls = [styles.select, styles.medium, props.className]
    .filter(Boolean)
    .join(' ');

  return (
    <SelectAsync
      onShow={handleShow}
      onHide={handleHide}
      field="name"
      value={value}
      suggestions={suggestions}
      completeMethod={completeMethod}
      disabled={disabled}
      placeholder={placeholder}
      className={cls}
      onChange={handleChange}
      size="medium"
      dropdown
      dropdownIcon={
        showDropdown ? <Icons.Arrow.Up.Filled /> : <Icons.Arrow.Down.Filled />
      }
    />
  );
};
