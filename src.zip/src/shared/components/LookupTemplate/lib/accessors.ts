export const getByPath = <T = unknown>(
  obj: unknown,
  path?: string,
): T | undefined => {
  if (!path || typeof obj !== 'object' || obj == null) return undefined;
  return path.split('.').reduce<unknown>((acc, key) => {
    if (typeof acc === 'object' && acc != null && key in (acc as object)) {
      return (acc as Record<string, unknown>)[key];
    }
    return undefined;
  }, obj) as T | undefined;
};

export const readStr = (
  o: Record<string, unknown>,
  key: string,
): string | undefined => {
  const v = o[key];
  if (typeof v === 'string') return v;
  if (typeof v === 'number') return String(v);
  return undefined;
};
export const readCode = <TCode extends string | number>(
  o: Record<string, unknown>,
  key: string,
): TCode | undefined => {
  const v = o[key];
  if (typeof v === 'string' || typeof v === 'number') return v as TCode;
  return undefined;
};
