export interface ISuggestion<TCode extends string | number = number> {
  name: string;
  code: TCode;
}

export type StaticFilter = Record<string, unknown>;

export type QueryVars = {
  where?: Record<string, unknown>;
  take?: number;
  [key: string]: unknown;
};

export type UseLazyQueryHook<TVars extends QueryVars, TData> = () => [
  (opts: { variables: TVars }) => Promise<{ data: TData }>,
  {
    data?: TData;
    loading?: boolean;
    refetch: (vars: TVars) => Promise<{ data: TData }>;
  },
];

export interface LookupTemplateProps<
  TVars extends QueryVars = QueryVars,
  TData = unknown,
  TCode extends string | number = number,
  TOut = number,
> {
  useLazyQueryHook: UseLazyQueryHook<TVars, TData>;

  staticFilters?: StaticFilter[];
  constVars?: Partial<TVars>;
  defaultValue?: string | number | TCode | null;
  /** Отображаемое название выбранного значения (для предзаполнения при редактировании фильтра) */
  displayValue?: string;
  searchField?: string;
  codeField?: string;
  itemsPath?: string;
  debounceDelay?: number;
  disabled?: boolean;
  className?: string;
  placeholder?: string;
  onChange: (code: TOut[] | string | TCode, title: string) => void;
  afterSelectRefetch?: (code: TCode) => Promise<TOut[]>;
  extraField?: string;
  /** По умолчанию префикс (istartsWith). `contains` — подстрока без привязки к началу (icontains). */
  searchMatch?: 'startsWith' | 'contains';
  /** Не запрашивать подсказки, пока пользователь ничего не ввёл (справочник открывается «поиском»). */
  skipEmptyQuery?: boolean;
  /** Минимальная длина строки поиска перед запросом (по умолчанию 3). */
  minSearchLength?: number;
}
