import { useCallback, useEffect, useRef, useState } from 'react';

import { LOOKUP_MIN_SEARCH_LENGTH } from 'shared/lib/lookupSearch';
import { getStableRequestDate } from 'shared/utils/date';

import { getByPath, readCode, readStr } from './lib/accessors';
import type {
  ISuggestion,
  LookupTemplateProps,
  QueryVars,
  StaticFilter,
} from './types';

const EMPTY_FILTERS: StaticFilter[] = [];

export const useLookupTemplate = <
  TCode extends string | number = number,
  TOut = number,
  TVars extends QueryVars = QueryVars,
  TData = unknown,
>(
  props: LookupTemplateProps<TVars, TData, TCode, TOut>,
) => {
  const {
    useLazyQueryHook,
    staticFilters: staticFiltersProp,
    constVars,
    defaultValue = null,
    displayValue,
    searchField = 'name',
    codeField = 'id',
    itemsPath,
    debounceDelay = 500,
    disabled,
    onChange,
    afterSelectRefetch,
    extraField,
    searchMatch = 'startsWith',
    skipEmptyQuery = false,
    minSearchLength = LOOKUP_MIN_SEARCH_LENGTH,
  } = props;

  const searchOp = searchMatch === 'contains' ? 'icontains' : 'istartsWith';
  const [callQuery] = useLazyQueryHook();
  const callQueryRef = useRef(callQuery);

  const staticFiltersRef = useRef(staticFiltersProp ?? EMPTY_FILTERS);
  const constVarsRef = useRef(constVars);
  const selectedRef = useRef<ISuggestion<TCode> | undefined>(undefined);

  useEffect(() => {
    callQueryRef.current = callQuery;
  }, [callQuery]);

  useEffect(() => {
    staticFiltersRef.current = staticFiltersProp ?? EMPTY_FILTERS;
  }, [staticFiltersProp]);

  useEffect(() => {
    constVarsRef.current = constVars;
  }, [constVars]);

  const [suggestions, setSuggestions] = useState<ISuggestion<TCode>[]>([]);
  const [selected, setSelected] = useState<ISuggestion<TCode> | undefined>(
    undefined,
  );
  const [inputText, setInputText] = useState(displayValue ?? '');

  const lastInputRef = useRef(displayValue ?? '');
  const isUserEditingRef = useRef(false);
  const resolvedDefaultRef = useRef<TCode | null>(null);
  const searchRequestIdRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    selectedRef.current = selected;
  }, [selected]);

  const buildSearchVariables = useCallback(
    (raw?: string): TVars => {
      const staticFilters = staticFiltersRef.current;
      const constVarsValue = constVarsRef.current;
      const q = (raw ?? '').trim();

      let base: QueryVars;

      if (q && q.length >= minSearchLength) {
        const searchCondition =
          extraField != null
            ? {
                or: [
                  { [searchField]: { [searchOp]: q } },
                  { [extraField]: { [searchOp]: q } },
                ],
              }
            : {
                [searchField]: { [searchOp]: q },
              };

        base = {
          where: {
            and: [...staticFilters, searchCondition],
          },
          take: 15,
        };
      } else if (skipEmptyQuery) {
        base = { take: 0 };
      } else {
        base =
          staticFilters.length > 0
            ? { where: { and: [...staticFilters] }, take: 15 }
            : { take: 15 };
      }

      const merged = {
        ...(constVarsValue as object),
        ...(base as object),
      } as Record<string, unknown>;

      if (constVarsValue != null && 'requestDate' in constVarsValue) {
        merged.requestDate = getStableRequestDate();
      }

      return merged as TVars;
    },
    [searchField, extraField, searchOp, skipEmptyQuery, minSearchLength],
  );

  const mapDataToSuggestions = useCallback(
    (raw: TData | undefined): ISuggestion<TCode>[] => {
      if (!raw) return [];

      let list: unknown;

      if (itemsPath) {
        list = getByPath<unknown>(raw, itemsPath);
      } else if (typeof raw === 'object') {
        const firstKey = Object.keys(raw as object)[0];
        if (firstKey) list = getByPath<unknown>(raw, `${firstKey}.items`);
      }

      if (!Array.isArray(list)) return [];

      const result: ISuggestion<TCode>[] = [];

      for (const it of list as unknown[]) {
        if (typeof it !== 'object' || it == null) continue;
        const obj = it as Record<string, unknown>;

        const code = readCode<TCode>(obj, codeField);
        if (code === undefined) continue;

        const baseName = readStr(obj, searchField) ?? String(code);
        const extra = extraField ? readStr(obj, extraField) : undefined;
        const name = extra ? `${baseName} ${extra}` : baseName;

        result.push({ name, code });
      }

      return result;
    },
    [itemsPath, searchField, codeField, extraField],
  );

  const clearSearchTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const scheduleSearch = useCallback(
    (raw: string) => {
      clearSearchTimer();

      timerRef.current = setTimeout(() => {
        const currentRaw = lastInputRef.current;
        const q = currentRaw.trim();
        const requestId = ++searchRequestIdRef.current;

        if (skipEmptyQuery && !q) {
          setSuggestions([]);
          return;
        }
        if (q && q.length < minSearchLength) {
          setSuggestions([]);
          return;
        }

        const vars = buildSearchVariables(currentRaw);
        void callQueryRef.current({ variables: vars }).then(res => {
          if (requestId !== searchRequestIdRef.current) return;
          if (lastInputRef.current !== currentRaw) return;
          setSuggestions(mapDataToSuggestions(res.data));
        });
      }, debounceDelay);
    },
    [
      buildSearchVariables,
      clearSearchTimer,
      debounceDelay,
      mapDataToSuggestions,
      minSearchLength,
      skipEmptyQuery,
    ],
  );

  const applySearchInput = useCallback(
    (raw: string) => {
      isUserEditingRef.current = true;
      setInputText(raw);
      lastInputRef.current = raw;

      if (raw.trim() !== (selectedRef.current?.name ?? '').trim()) {
        setSelected(undefined);
      }

      scheduleSearch(raw);
    },
    [scheduleSearch],
  );

  useEffect(() => {
    return () => {
      clearSearchTimer();
    };
  }, [clearSearchTimer]);

  useEffect(() => {
    if (skipEmptyQuery) {
      setSuggestions([]);
      return;
    }

    let cancelled = false;

    void callQueryRef
      .current({
        variables: buildSearchVariables(''),
      })
      .then(res => {
        if (!cancelled && !isUserEditingRef.current) {
          setSuggestions(mapDataToSuggestions(res.data));
        }
      });

    return () => {
      cancelled = true;
    };
  }, [buildSearchVariables, mapDataToSuggestions, skipEmptyQuery]);

  useEffect(() => {
    if (isUserEditingRef.current) return;

    isUserEditingRef.current = false;
    resolvedDefaultRef.current = null;
  }, [defaultValue]);

  useEffect(() => {
    if (isUserEditingRef.current) return;
    if (displayValue == null || displayValue === '') return;

    setInputText(displayValue);
    lastInputRef.current = displayValue;
  }, [displayValue]);

  useEffect(() => {
    if (defaultValue == null || Array.isArray(defaultValue)) return;
    if (isUserEditingRef.current) return;

    const codeVal =
      typeof defaultValue === 'string' && /^\d+$/.test(defaultValue)
        ? (Number(defaultValue) as TCode)
        : (defaultValue as TCode);

    if (resolvedDefaultRef.current === codeVal) return;

    let cancelled = false;

    void callQueryRef
      .current({
        variables: {
          where: { [codeField]: { eq: codeVal } },
          take: 10,
        } as unknown as TVars,
      })
      .then(res => {
        if (cancelled || isUserEditingRef.current) return;

        const arr = mapDataToSuggestions(res.data);
        const sel = arr.find(x => x.code === codeVal);
        if (!sel) return;

        resolvedDefaultRef.current = codeVal;
        setSuggestions(arr);
        setSelected(sel);
        const name = String(sel.name ?? '');
        setInputText(name);
        lastInputRef.current = name;
        if (!afterSelectRefetch) onChange(sel.code, sel.name);
      });

    return () => {
      cancelled = true;
    };
  }, [
    defaultValue,
    codeField,
    mapDataToSuggestions,
    onChange,
    afterSelectRefetch,
  ]);

  const completeMethod = useCallback(
    (e: { query: string }) => {
      applySearchInput(e.query ?? '');
    },
    [applySearchInput],
  );

  const handleSelect = useCallback(
    async (sel: ISuggestion<TCode>) => {
      isUserEditingRef.current = false;
      clearSearchTimer();
      resolvedDefaultRef.current = sel.code;
      setSelected(sel);

      const name = String(sel.name ?? '');
      setInputText(name);
      lastInputRef.current = name;

      if (afterSelectRefetch) {
        const ids = await afterSelectRefetch(sel.code);
        onChange(ids, sel.name);
      } else {
        onChange(sel.code, sel.name);
      }

      const res = await callQueryRef.current({
        variables: {
          where: { [codeField]: { eq: sel.code } },
          take: 1,
        } as unknown as TVars,
      });

      setSuggestions(mapDataToSuggestions(res.data));
    },
    [
      afterSelectRefetch,
      clearSearchTimer,
      codeField,
      mapDataToSuggestions,
      onChange,
    ],
  );

  const handleChange = useCallback(
    (e: { value: unknown }) => {
      const v = e.value;

      if (v && typeof v === 'object' && 'code' in v) {
        void handleSelect(v as ISuggestion<TCode>);
        return;
      }

      applySearchInput(typeof v === 'string' ? v : '');
    },
    [applySearchInput, handleSelect],
  );

  const handleShow = () => setShowDropdown(true);
  const handleHide = () => setShowDropdown(false);

  return {
    value: inputText,
    suggestions,
    completeMethod,
    disabled,
    handleChange,
    showDropdown,
    handleShow,
    handleHide,
  };
};
