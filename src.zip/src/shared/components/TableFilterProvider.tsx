import { ComponentProps, ReactNode } from 'react';

import {
  DataService,
  ErrorBoundary,
  Icons,
  SettingPanel,
} from 'shared_ui/components';
import { IDataServiceInitialConfig } from 'shared_ui/components/DataService';
import { ITemplate } from 'shared_ui/components/DataService/contexts/TemplatesContext';
import { IFilterTemplateValue } from 'shared_ui/components/DataServiceFilter/contexts/FilterTemplatesContext';

interface IProps {
  config: IDataServiceInitialConfig;
  children: ReactNode;
  active?: number;
  filtersTemplate?: ITemplate<IFilterTemplateValue>;
  scope: string;
}

const settingPanelModel: ComponentProps<typeof SettingPanel>['model'] = [
  {
    icon: <Icons.Filter.Md />,
    title: 'Фильтр',
    subTitle: 'Выбор условий расчета',
    component: (
      <ErrorBoundary>
        <DataService.Filter.FilterSidebar />
      </ErrorBoundary>
    ),
  },
  {
    icon: <Icons.Settings.Slider.Md />,
    title: 'Атрибуты',
    subTitle: 'Выбор атрибутов для таблицы',
    component: (
      <ErrorBoundary>
        <DataService.Attributes.AttributesSidebar />
      </ErrorBoundary>
    ),
  },
];

export const TableFilterProvider = ({
  config,
  children,
  active,
  filtersTemplate,
  scope,
}: IProps) => {
  return (
    <DataService.DataServiceProvider
      scope={scope}
      config={config}
      filtersTemplate={filtersTemplate}
    >
      <div className="flex gap-2 flex-row align-items-stretch flex-1 min-h-0 h-full">
        <div className="flex flex-grow-1 flex-column w-full min-h-0 overflow-hidden">
          {children}
        </div>
        <SettingPanel model={settingPanelModel} active={active} />
      </div>
    </DataService.DataServiceProvider>
  );
};
