import { TInitialState } from 'core_client/state';

export type TAppState = {
  permissions: {
    data: string[];
    sessionId: string;
  };
};

export const initialState: TInitialState<TAppState> = {
  permissions: {
    value: {
      data: [],
      sessionId: '',
    },
    persists: true,
  },
};
