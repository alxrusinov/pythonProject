/** Минимальная длина строки поиска перед запросом справочника */
export const LOOKUP_MIN_SEARCH_LENGTH = 3;

export const normalizeLookupSearch = (
  value: string | null | undefined,
): string => (value ?? '').trim();

export const canFetchLookup = (value: string | null | undefined): boolean =>
  normalizeLookupSearch(value).length >= LOOKUP_MIN_SEARCH_LENGTH;
