import { useCallback } from 'react';

type UseClearSelectedRowsParams = {
  stateKey?: string;
  cb?: () => void;
};

export const useClearSelectedRows = ({
  stateKey,
  cb,
}: UseClearSelectedRowsParams) => {
  return useCallback(() => {
    cb?.();

    if (!stateKey) return;

    const raw = sessionStorage.getItem(stateKey);

    if (!raw) return;

    try {
      const data = JSON.parse(raw);
      data.selection = [];
      sessionStorage.setItem(stateKey, JSON.stringify(data));
    } catch {
      sessionStorage.removeItem(stateKey);
    }
  }, [stateKey, cb]);
};
