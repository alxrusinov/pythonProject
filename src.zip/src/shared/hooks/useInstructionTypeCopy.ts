import { useNavigate } from 'react-router-dom';

import { paths } from '../routes/paths';
import { buildPath } from '../utils/buildPath';

const toRequestDateTimestamp = (date?: Date): number =>
  date ? date.getTime() : Date.now();

/**
 * Копирование типа инструкции — поведение аналогично useInstructionCopy:
 * открываем форму создания типа с параметрами copyFrom + requestDate.
 */
export const useInstructionTypeCopy = () => {
  const navigate = useNavigate();

  return (instructionTypeId: string, requestDate?: Date) => {
    const ts = toRequestDateTimestamp(requestDate);
    const search = new URLSearchParams({
      copyFrom: instructionTypeId,
      requestDate: String(ts),
    });
    navigate(
      `${buildPath(paths.createInstructionTemplate)}?${search.toString()}`,
    );
  };
};
