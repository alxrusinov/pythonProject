import { useNavigate } from 'react-router-dom';

import { paths } from '../routes/paths';
import { buildPath } from '../utils/buildPath';

export const useInstructionCopy = () => {
  const navigate = useNavigate();

  return (instructionId: string) => {
    const calcDate = Date.now();
    const search = new URLSearchParams({
      copyFrom: instructionId,
      calcDate: String(calcDate),
    });
    navigate(`${buildPath(paths.createInstruction)}?${search.toString()}`);
  };
};
