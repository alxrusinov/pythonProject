import {
  IrcInstruction,
  IrcInstructionType,
  IrcOrgEmail,
} from 'graphql/generated/generated';

export type InstructionTypeModels = Pick<IrcInstructionType, 'id'>;

export type InstructionModels = Pick<IrcInstruction, 'id' | 'date'>;

export type OrgEmailModels = Pick<IrcOrgEmail, 'id'>;

export type TabMenuElements = {
  label: string;
  value: string;
  indicator?: string;
};
