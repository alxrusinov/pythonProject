import { ComponentProps } from 'react';

import { DataService } from 'shared_ui/components';

type ProviderProps = ComponentProps<typeof DataService.DataServiceProvider>;
type BaseConfig = ProviderProps['config'];

export type ColumnConfig<K extends PropertyKey> = Omit<BaseConfig, 'fields'> & {
  fields: Array<Omit<BaseConfig['fields'][number], 'name'> & { name: K }>;
};

export type TypedGroup<K extends PropertyKey> =
  | { fieldName: K; title?: string }
  | { title: string; groups: TypedGroup<K>[] };
