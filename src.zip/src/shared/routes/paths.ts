export const paths = {
  carInstructionTemplates: 'instruction-templates',
  carInstructions: 'instructions',
  orgEmails: 'org-emails',
  createInstructionTemplate: 'create-instruction-template',
  createInstruction: 'create-instruction',
  createOrgEmail: 'create-org-email',
  editInstructionTemplate: 'edit-instruction-template/:masterId',
  editInstruction: 'edit-instruction/:masterId',
  editOrgEmail: 'edit-org-email/:masterId',
  deleteOrgEmail: 'delete-org-email/:masterId',
};
