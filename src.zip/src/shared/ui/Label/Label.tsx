import { FC, ReactNode } from 'react';

import styles from './Label.module.scss';

type LabelProps = {
  children: ReactNode;
  className?: string;
};

const Label: FC<LabelProps> = ({ children }) => {
  return <div className={styles.label}>{children}</div>;
};

export { Label };
export type { LabelProps };
