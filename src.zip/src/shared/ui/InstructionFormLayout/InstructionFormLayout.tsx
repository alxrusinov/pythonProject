import { ReactNode } from 'react';

interface InstructionFormLayoutProps {
  children: ReactNode;
}

export const InstructionFormLayout = ({
  children,
}: InstructionFormLayoutProps) => (
  <div
    className="flex flex-column gap-2 flex-grow-1 mx-auto"
    style={{ width: '100%' }}
  >
    {children}
  </div>
);
