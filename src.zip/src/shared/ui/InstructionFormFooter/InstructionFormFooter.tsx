import { useMemo } from 'react';
import { useParams } from 'react-router-dom';

import { Box, Button } from 'shared_ui/components';

import { INSTRUCTION_STATUSES } from 'widgets/InstructionForm/lib/constants';

interface InstructionFormFooterProps {
  onSave?: VoidFunction;
  onCancel?: (masterId: string) => void;
  onSend?: (masterId: string) => void;
  onBack?: VoidFunction;
  onCorrect?: VoidFunction;
  status: string;
  /** Форма изменена (есть несохранённые изменения) */
  isDirty?: boolean;
}

export const InstructionFormFooter = ({
  onSave,
  onCancel,
  onBack,
  onSend,
  status,
  onCorrect,
  isDirty = false,
}: InstructionFormFooterProps) => {
  const { masterId } = useParams();

  const isCreateMode = !masterId;
  const saveButtonLabel = isCreateMode ? 'Создать' : 'Сохранить';
  const isSaveDisabled = isCreateMode ? false : !isDirty;
  const isSendDisabled = !masterId || isDirty;

  const getButtonsByStatus = useMemo(() => {
    switch (status) {
      case INSTRUCTION_STATUSES.created:
        return (
          <>
            {masterId && (
              <Button
                disabled={
                  isSendDisabled || status === INSTRUCTION_STATUSES.canceled
                }
                className="w-full md:w-12rem"
                size="medium"
                onClick={() => onSend && onSend(masterId)}
              >
                Отправить
              </Button>
            )}
            <Button
              className="w-full md:w-12rem"
              size="medium"
              onClick={onSave}
              disabled={
                isSaveDisabled || status !== INSTRUCTION_STATUSES.created
              }
            >
              {saveButtonLabel}
            </Button>
          </>
        );
      case INSTRUCTION_STATUSES.canceled:
        return null;
      case INSTRUCTION_STATUSES.sended:
        if (!masterId) return null;
        return (
          <>
            <Button
              className="md:w-8rem"
              size="medium"
              variant="danger"
              onClick={() => onCancel && onCancel(masterId)}
            >
              Отмена
            </Button>
            <Button className="md:w-10rem" size="medium" onClick={onCorrect}>
              Корректировать
            </Button>
            <Button
              className="md:w-8rem"
              size="medium"
              disabled={isSendDisabled}
              onClick={() => onSend && onSend(masterId)}
            >
              Отправить
            </Button>
          </>
        );
      default:
        return (
          <Button
            className="md:w-8rem"
            size="medium"
            onClick={onSave}
            disabled={isSaveDisabled}
          >
            {saveButtonLabel}
          </Button>
        );
    }
  }, [
    status,
    onSave,
    onCancel,
    onSend,
    onCorrect,
    masterId,
    saveButtonLabel,
    isSaveDisabled,
    isSendDisabled,
  ]);
  return (
    <Box
      className="flex flex-column justify-content-between md:flex-row gap-2 md:gap-2"
      size="small"
    >
      <Button
        className="w-full md:w-8rem"
        size="medium"
        variant="secondary"
        onClick={onBack}
      >
        Назад
      </Button>
      <Box className="flex gap-3 p-0">{getButtonsByStatus}</Box>
    </Box>
  );
};
