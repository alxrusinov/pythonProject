import { NO_DATA_MARK } from 'shared/constants/common';

export const NoDataMark = () => (
  <div className="flex w-full justify-content-center">{NO_DATA_MARK}</div>
);
