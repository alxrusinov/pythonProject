import { ReactNode } from 'react';

interface AppLayoutProps {
  children: ReactNode;
}

export const AppLayout = ({ children }: AppLayoutProps) => (
  <div
    className="flex flex-column gap-2 mx-auto flex-1 min-h-0 h-full overflow-hidden"
    style={{ width: 'clamp(480px, 100%, 3840px)' }}
  >
    <div className="flex flex-column flex-1 min-h-0 h-full overflow-hidden">
      {children}
    </div>
  </div>
);
