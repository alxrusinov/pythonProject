import { ReactNode } from 'react';

import { NavigationBar, Tag } from 'shared_ui/components';

interface InstructionTypeFormHeaderProps {
  onBack?: VoidFunction;
  instructionTypeName?: string | null;
  status?: string;
  children?: ReactNode;
}

export const InstructionTypeFormHeader = ({
  onBack,
  instructionTypeName = '',
  status,
  children,
}: InstructionTypeFormHeaderProps) => {
  return (
    <NavigationBar
      backButtonOnClick={onBack}
      title={`Тип инструкции: ${instructionTypeName}`}
      content={
        status && (
          <div className="py-2">
            <Tag label={status} />
          </div>
        )
      }
    >
      {children}
    </NavigationBar>
  );
};
