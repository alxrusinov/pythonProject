import { useParams } from 'react-router-dom';

import { Box, Button } from 'shared_ui/components';

interface InstructionTypeFormFooterProps {
  onSave?: VoidFunction;
  onDelete?: (masterId: string) => void;
  onCancel?: VoidFunction;
  hasButtons?: boolean;
  saveDisabled?: boolean;
  /** Текст кнопки сохранения: «Создать» или «Сохранить» */
  saveButtonLabel?: string;
}

export const InstructionTypeFormFooter = ({
  onSave,
  onCancel,
  onDelete,
  hasButtons = true,
  saveDisabled = false,
  saveButtonLabel = 'Сохранить',
}: InstructionTypeFormFooterProps) => {
  const { masterId } = useParams();

  return (
    <Box className="flex flex-column justify-content-between md:flex-row">
      <Button
        className="md:w-8rem"
        size="medium"
        variant="secondary"
        onClick={onCancel}
      >
        Назад
      </Button>
      <Box className="flex gap-3 p-0">
        {masterId && onDelete && (
          <Button
            className="md:w-8rem"
            size="medium"
            variant="danger"
            onClick={() => onDelete(masterId)}
          >
            Удалить
          </Button>
        )}
        {hasButtons && (
          <Box className="flex gap-3 p-0">
            <Button
              className="md:w-8rem"
              size="medium"
              onClick={onSave}
              disabled={saveDisabled}
            >
              {saveButtonLabel}
            </Button>
          </Box>
        )}
      </Box>
    </Box>
  );
};
