export { AutoResizeTextArea } from './AutoResizeTextArea';
