import {
  ChangeEvent,
  ComponentProps,
  forwardRef,
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
} from 'react';

import { TextArea } from 'shared_ui/components';

type TextAreaProps = ComponentProps<typeof TextArea>;

const adjustTextareaHeight = (element: HTMLTextAreaElement) => {
  element.style.height = 'auto';
  element.style.height = `${element.scrollHeight}px`;
};

export const AutoResizeTextArea = forwardRef<
  HTMLTextAreaElement,
  TextAreaProps
>(({ autoResize = true, onChange, value, ...rest }, ref) => {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const setRefs = useCallback(
    (node: HTMLTextAreaElement | null) => {
      textareaRef.current = node;
      if (typeof ref === 'function') {
        ref(node);
      } else if (ref) {
        ref.current = node;
      }
    },
    [ref],
  );

  const resize = useCallback(() => {
    const element = textareaRef.current;
    if (!element || !autoResize || element.offsetParent === null) return;
    adjustTextareaHeight(element);
  }, [autoResize]);

  useLayoutEffect(() => {
    resize();
  }, [resize, value]);

  useEffect(() => {
    if (!autoResize) return;
    const element = textareaRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(() => resize());
    observer.observe(element);

    return () => observer.disconnect();
  }, [autoResize, resize]);

  const handleChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    if (autoResize) adjustTextareaHeight(event.target);
    onChange?.(event);
  };

  return (
    <TextArea
      ref={setRefs}
      autoResize={autoResize}
      value={value}
      onChange={handleChange}
      {...rest}
    />
  );
});
