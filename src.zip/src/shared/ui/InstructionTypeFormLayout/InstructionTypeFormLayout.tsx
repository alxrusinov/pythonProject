import { ReactNode } from 'react';

interface InstructionTypeFormLayoutProps {
  children: ReactNode;
}

export const InstructionTypeFormLayout = ({
  children,
}: InstructionTypeFormLayoutProps) => (
  <div
    className="flex flex-column gap-2 flex-grow-1 mx-auto"
    style={{ width: '100%' }}
  >
    {children}
  </div>
);
