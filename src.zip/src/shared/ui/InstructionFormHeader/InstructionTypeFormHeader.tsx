import { ReactNode } from 'react';

import { NavigationBar, Tag } from 'shared_ui/components';

import { INSTRUCTION_STATUSES } from 'widgets/InstructionForm/lib/constants';

interface InstructionFormHeaderProps {
  onBack?: VoidFunction;
  instructionName?: ReactNode;
  status?: string;
  children?: ReactNode;
}

export const InstructionFormHeader = ({
  onBack,
  instructionName = '',
  status,
  children,
}: InstructionFormHeaderProps) => {
  const getColorByStatusName = (statusName: string) => {
    switch (statusName) {
      case INSTRUCTION_STATUSES.created:
        return 'gray';
      case INSTRUCTION_STATUSES.canceled:
        return 'red';
      case INSTRUCTION_STATUSES.sended:
        return 'green';
      default:
        return 'gray';
    }
  };

  return (
    <NavigationBar
      backButtonOnClick={onBack}
      title={<>Инструкция {instructionName}</>}
      content={
        status && (
          <div className="py-2">
            <Tag label={status} color={getColorByStatusName(status)} />
          </div>
        )
      }
    >
      {children}
    </NavigationBar>
  );
};
