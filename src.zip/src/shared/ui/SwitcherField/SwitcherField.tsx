import {
  FieldValues,
  useController,
  UseControllerProps,
} from 'react-hook-form';

import { Switch } from 'shared_ui/components';
import { InputSwitchChangeEvent } from 'shared_ui/primereact';

import { Label } from '../Label/Label';

export interface SwitcherFieldProps<T extends FieldValues>
  extends UseControllerProps<T> {
  label: string;
}

export const SwitcherField = <T extends FieldValues>({
  name,
  label,
  disabled,
  control,
  ...rest
}: SwitcherFieldProps<T>) => {
  const { field } = useController({
    control,
    name,
    disabled,
    ...rest,
  });

  const onChange = (e: InputSwitchChangeEvent) => {
    field.onChange(e.value);
  };

  return (
    <div className="flex gap-2 align-items-center ">
      <Label className="mb-0">{label}</Label>
      <Switch
        disabled={field.disabled}
        size="medium"
        onChange={onChange}
        checked={field.value}
      />
    </div>
  );
};
