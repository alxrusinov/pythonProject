import { FC, ReactNode } from 'react';

import { Divider } from 'shared_ui/components';
import { Dialog, DialogProps } from 'shared_ui/primereact';

import { Header } from './components/Header';
import { ModalContextxWrapper } from './components/ModalContextx';
import styles from './Modal.module.scss';

type Props = Omit<DialogProps, 'onHide'> & {
  title: string;
  subtitle?: string;
  visible: boolean;
  onClose(): void;
  children?: ReactNode;
};

const Modal: FC<Props> = ({
  className,
  onClose,
  children,
  visible = false,
  appendTo = 'self',
  maskStyle = { position: 'absolute' },
  title,
  subtitle,
  ...rest
}) => {
  return (
    <Dialog
      {...rest}
      appendTo={appendTo}
      maskStyle={maskStyle}
      closable={false}
      visible={visible}
      onHide={onClose}
      className={className}
      maskClassName={styles.modal}
      header={<Header onClose={onClose} title={title} subtitle={subtitle} />}
    >
      <ModalContextxWrapper onClose={onClose}>
        <Divider />
        {children}
      </ModalContextxWrapper>
    </Dialog>
  );
};

export { Modal };
