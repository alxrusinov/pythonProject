import { FC, ReactNode } from 'react';

import { ModalContext } from '../context/ModalContext';

type Props = {
  onClose: () => void;
  children: ReactNode;
};

const ModalContextxWrapper: FC<Props> = ({ children, onClose }) => {
  return (
    <ModalContext.Provider value={{ onClose }}>
      {children}
    </ModalContext.Provider>
  );
};

export { ModalContextxWrapper };
