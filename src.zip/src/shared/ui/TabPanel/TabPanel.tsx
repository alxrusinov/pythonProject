import { ReactNode } from 'react';

import styles from './TabPanel.module.scss';

interface TabPanelProps<Step extends string> {
  step: Step;
  activeStep: Step;
  children?: ReactNode;
}

export const TabPanel = <Step extends string>({
  step,
  activeStep,
  children,
}: TabPanelProps<Step>) => {
  return (
    <div
      style={{ display: step === activeStep ? 'flex' : 'none' }}
      className={`${styles.container} flex-grow-1 max-w-full`}
    >
      {children}
    </div>
  );
};
