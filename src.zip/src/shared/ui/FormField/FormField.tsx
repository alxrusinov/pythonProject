import { ReactNode } from 'react';

import { Label } from 'shared_ui/components';

interface FormFieldProps {
  label?: string;
  children?: ReactNode;
  errorMessage?: string;
  notice?: string;
  alignItems?: 'center' | 'start';
  compact?: boolean;
}

export const FormField = ({
  label,
  children,
  errorMessage,
  notice,
  alignItems = 'center',
  compact = false,
}: FormFieldProps) => (
  <div>
    <div
      className={`field grid md:w-full mb-0 ${
        alignItems === 'start' ? 'align-items-start' : 'align-items-center'
      }`}
    >
      {label && (
        <Label
          className={`col-12 sm:mb-2 md:mb-0 ${
            compact ? 'md:col-2' : 'md:col-5'
          }`}
          label={label}
        />
      )}

      <div className={`col-12 ${compact ? 'md:col-10' : 'md:col-7'}`}>
        {children}
      </div>
    </div>

    {notice && (
      <div className="field grid md:w-full mb-0">
        <small
          className={`hidden md:block col-12 ${compact ? 'md:col-2' : 'md:col-5'}`}
        >
          &nbsp;
        </small>
        <small className={`col-12 ${compact ? 'md:col-10' : 'md:col-7'}`}>
          {notice}
        </small>
      </div>
    )}

    <div className="field grid md:w-full mb-0">
      <small
        className={`hidden md:block col-12 p-error ${
          compact ? 'md:col-2' : 'md:col-5'
        }`}
      >
        &nbsp;
      </small>
      <small className={`col-12 p-error ${compact ? 'md:col-10' : 'md:col-7'}`}>
        {errorMessage}
      </small>
    </div>
  </div>
);
