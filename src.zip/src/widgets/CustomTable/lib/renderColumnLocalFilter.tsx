import type { CSSProperties } from 'react';
import { ReactNode } from 'react';

import {
  ColumnFilterBoolean,
  ColumnFilterDate,
  ColumnFilterElementTemplateOptions,
  ColumnFilterMulti,
  ColumnFilterNumber,
  ColumnFilterText,
} from 'shared_ui/components';
import { SelectItemOptionsType } from 'shared_ui/primereact';

import { CellDataType, ColumnLocalFilterType } from './types';

type OperatorMeta = {
  operator?: unknown;
  constraints?: Array<{ value?: unknown; matchMode?: unknown }>;
};

/** В меню-фильтрах PrimeReact options.value может быть meta { operator, constraints } */
function normalizeFilterElementOptions(
  options: ColumnFilterElementTemplateOptions,
): ColumnFilterElementTemplateOptions {
  const v = options.value;
  const isOperatorMeta =
    v != null &&
    typeof v === 'object' &&
    !Array.isArray(v) &&
    !(v instanceof Date) &&
    'constraints' in v;

  if (!isOperatorMeta) return options;

  const meta = v as OperatorMeta;
  const idx = options.index ?? 0;
  const constraint = meta.constraints?.[idx];
  const value =
    constraint &&
    typeof constraint === 'object' &&
    constraint !== null &&
    'value' in constraint
      ? (constraint as { value: unknown }).value
      : null;

  // Важно: filterCallback не трогаем — пусть DataTable сам обновляет constraints по index.
  return { ...options, value };
}

const FILTER_CONTENT_STYLE: CSSProperties = {
  minHeight: 40,
  width: '100%',
  minWidth: 220,
};

type FilterElementProps = {
  options: ColumnFilterElementTemplateOptions;
  columnData?: SelectItemOptionsType;
};

type RenderFilterElementParams = FilterElementProps & {
  filterType?: ColumnLocalFilterType;
  /** Сырые данные колонки (для multi — нормализуем в { label, value }) */
  rawColumnData?: CellDataType[];
};

/** Приводит сырые значения ячеек к формату SelectItem для MultiSelect (label + value) */
function normalizeToSelectItems(
  raw: CellDataType[] | undefined,
): SelectItemOptionsType {
  if (!raw?.length) return [];
  return raw
    .filter((item): item is NonNullable<typeof item> => item != null)
    .map(item => {
      const value = item;
      let label: string;
      if (typeof value === 'object' && value !== null && 'name' in value) {
        label = String((value as { name?: unknown }).name ?? '');
      } else if (value instanceof Date) {
        label = value.toISOString();
      } else {
        label = String(value);
      }
      return { label: label || '—', value };
    })
    .sort((a, b) => a.label.localeCompare(b.label, 'ru', { numeric: true }));
}

const renderFilterElementMap: Record<
  ColumnLocalFilterType,
  ({ options, columnData }: FilterElementProps) => ReactNode
> = {
  boolean: ({ options }) => (
    <ColumnFilterBoolean options={options} columnDataType="boolean" />
  ),
  datetime: ({ options }) => <ColumnFilterDate options={options} />,
  number: ({ options }) => <ColumnFilterNumber options={options} />,
  text: ({ options }) => <ColumnFilterText options={options} />,
  multi: ({ options, columnData }) => (
    <ColumnFilterMulti options={options} columnData={columnData ?? []} />
  ),
};

export const renderFilterElement = ({
  filterType,
  options,
  columnData,
  rawColumnData,
}: RenderFilterElementParams) => {
  if (!filterType || !options) return null;

  const normalizedOptions = normalizeFilterElementOptions(options);

  const isMulti = filterType === 'multi';
  const resolvedColumnData = isMulti
    ? normalizeToSelectItems(rawColumnData)
    : (columnData?.filter(item => item != null) as
        | SelectItemOptionsType
        | undefined);

  const content = renderFilterElementMap[filterType]?.({
    options: normalizedOptions,
    columnData: resolvedColumnData ?? (isMulti ? [] : undefined),
  });

  if (content == null) return null;

  return (
    <div style={FILTER_CONTENT_STYLE} data-filter-type={filterType}>
      {content}
    </div>
  );
};
