import { useEffect, useMemo, useState } from 'react';

import { CellDataType, ColumnsMetaDataType, TableProps } from './types';

type UseColumnDataType<T> = {
  value: TableProps['value'];
  tableMetaData: ColumnsMetaDataType<T>[];
};

export const useColumnData = <T>({
  value,
  tableMetaData,
}: UseColumnDataType<T>) => {
  const [tableValue, setTableValue] = useState<TableProps['value']>(
    () => value ?? [],
  );

  // Строим список опций для фильтров из переданных данных (value), а не из tableValue:
  // onValueChange может перезаписывать tableValue, из-за чего селекты в фильтрах остаются пустыми
  const columnDataMap = useMemo(() => {
    const result = new Map<string, CellDataType[]>();
    const source = value ?? [];

    if (!source.length || !tableMetaData?.length) return result;

    for (const { field } of tableMetaData) {
      result.set(field, [...new Set(source.map(row => row[field]))]);
    }

    return result;
  }, [value, tableMetaData]);

  useEffect(() => {
    setTableValue(value ?? []);
  }, [value]);

  return { setTableValue, columnDataMap };
};
