import { CellRenderBoolean, CellRenderDateTime } from 'shared_ui/components';

import { NoDataMark } from 'shared/ui/NoDataMark';

import {
  BaseConfigFieldType,
  ColumnBodyOptionsType,
  IConfigFieldFilterType,
} from './types';

export const componentCellRenderBoolean = <T extends object>(
  rowData: Record<keyof T, boolean>,
  options: ColumnBodyOptionsType<T>,
) =>
  rowData[options.field] != null ? (
    <CellRenderBoolean
      className="flex w-full justify-content-center"
      value={rowData[options.field]}
    />
  ) : (
    <NoDataMark />
  );

export const componentCellRenderDateTime = ({
  withTime = false,
}: { withTime?: boolean } = {}) => {
  const dateTimeRenderBody = <T extends object>(
    rowData: Record<keyof T, Date>,
    options: ColumnBodyOptionsType<T>,
  ) =>
    rowData[options.field] ? (
      <CellRenderDateTime date={rowData[options.field]} withTime={withTime} />
    ) : (
      <NoDataMark />
    );
  dateTimeRenderBody.displayName = componentCellRenderDateTime;
  return dateTimeRenderBody;
};

export const componentCellRenderDateTimeWithTime = <T extends object>(
  rowData: Record<keyof T, Date>,
  options: ColumnBodyOptionsType<T>,
) =>
  rowData[options.field] ? (
    <CellRenderDateTime date={rowData[options.field]} withTime />
  ) : (
    <NoDataMark />
  );

export const componentBaseCellRender = <T extends object>(
  rowData: Record<keyof T, string | number>,
  options: ColumnBodyOptionsType<T>,
) => rowData[options.field] ?? <NoDataMark />;

export const baseField: BaseConfigFieldType = {
  attribute: {
    isSelected: true,
  },
  table: {
    filter: true,
    sortable: true,
    body: componentBaseCellRender,
  },
};

export const textColumnFilterParams: IConfigFieldFilterType = {
  filterType: 'text',
  dataType: 'text',
  filterMenuStyle: { width: '240px' },
};

export const multiColumnFilterParams: IConfigFieldFilterType = {
  filterType: 'multi',
  dataType: 'numeric',
  filterMenuStyle: { width: '240px' },
  showFilterMatchModes: false,
};

export const datetimeColumnFilterParams: IConfigFieldFilterType = {
  filterType: 'datetime',
  dataType: 'date',
  filterMenuStyle: { width: '240px' },
};

export const booleanColumnFilterParams: IConfigFieldFilterType = {
  filterType: 'boolean',
  dataType: 'boolean',
};

export const numberColumnFilterParams: IConfigFieldFilterType = {
  filterType: 'number',
  dataType: 'numeric',
  filterMenuStyle: { width: '240px' },
};
