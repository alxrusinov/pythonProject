import { FilterMatchMode } from 'shared_ui/api';

/** Принимает объект фильтров таблицы (совместим с FilterMeta из CustomTable) */
type FilterMeta = Record<string, unknown>;

type FilterEntry = {
  value?: unknown;
  matchMode?: string;
  constraints?: Array<{ value?: unknown; matchMode?: string }>;
};

function getFilterValueAndMode(entry: unknown): {
  value: unknown;
  matchMode: string | undefined;
} | null {
  const e = entry as FilterEntry | undefined;
  if (!e) return null;
  if (e.constraints?.length) {
    const c = e.constraints[0];
    const val = c?.value;
    if (val == null) return null;
    if (typeof val === 'string' && val.trim() === '') return null;
    return { value: val, matchMode: c?.matchMode };
  }
  if (e.value == null) return null;
  if (typeof e.value === 'string' && e.value.trim() === '') return null;
  if (Array.isArray(e.value) && e.value.length === 0) return null;
  return { value: e.value, matchMode: e.matchMode };
}

function isFilterActive(entry: unknown): boolean {
  return getFilterValueAndMode(entry) != null;
}

export function hasAnyFilterValue(filters: FilterMeta): boolean {
  return Object.entries(filters).some(([key, entry]) => {
    if (key === 'global') return false;
    return isFilterActive(entry);
  });
}

function normalizeCell(value: unknown): string {
  if (value == null) return '';
  if (typeof value === 'boolean') return value ? '1' : '0';
  if (typeof value === 'number') return String(value);
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(normalizeCell).join(' ');
  if (typeof value === 'object' && value !== null && 'name' in value) {
    return normalizeCell((value as { name?: unknown }).name);
  }
  return String(value);
}

function matchRow(
  cellValue: unknown,
  filterValue: unknown,
  matchMode: string | undefined,
): boolean {
  const cell = normalizeCell(cellValue).toLowerCase();
  const filter =
    typeof filterValue === 'string'
      ? filterValue.trim().toLowerCase()
      : normalizeCell(filterValue).toLowerCase();

  if (!filter && matchMode !== FilterMatchMode.EQUALS) return true;

  switch (matchMode) {
    case FilterMatchMode.CONTAINS:
      return cell.includes(filter);
    case FilterMatchMode.STARTS_WITH:
      return cell.startsWith(filter);
    case FilterMatchMode.ENDS_WITH:
      return cell.endsWith(filter);
    case FilterMatchMode.EQUALS:
    case FilterMatchMode.DATE_IS:
    case 'dateIs':
      if (typeof filterValue === 'boolean') {
        return Boolean(cellValue) === filterValue;
      }
      if (typeof filterValue === 'number') {
        const n = Number(cellValue);
        return !Number.isNaN(n) && n === filterValue;
      }
      if (filterValue instanceof Date) {
        const cellDate =
          cellValue instanceof Date
            ? cellValue
            : typeof cellValue === 'string'
              ? new Date(cellValue)
              : null;
        if (!cellDate || Number.isNaN(cellDate.getTime())) return false;
        return (
          cellDate.getFullYear() === filterValue.getFullYear() &&
          cellDate.getMonth() === filterValue.getMonth() &&
          cellDate.getDate() === filterValue.getDate()
        );
      }
      return cell === filter;
    case FilterMatchMode.IN:
      const arr = Array.isArray(filterValue) ? filterValue : [filterValue];
      return arr.some(fv => {
        const f = normalizeCell(fv).toLowerCase();
        return f ? cell.includes(f) || cell === f : false;
      });
    default:
      return cell.includes(filter);
  }
}

export function applyLocalFilters<T extends Record<string, unknown>>(
  data: T[],
  filters: FilterMeta,
): T[] {
  const keys = Object.keys(filters).filter(k => k !== 'global');
  const active = keys.filter(k => isFilterActive(filters[k]));

  if (active.length === 0) return data;

  return data.filter(row => {
    return active.every(field => {
      const parsed = getFilterValueAndMode(filters[field]);
      if (!parsed) return true;
      const cellValue = row[field];
      return matchRow(cellValue, parsed.value, parsed.matchMode);
    });
  });
}
