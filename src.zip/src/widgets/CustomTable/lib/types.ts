import { ComponentProps } from 'react';

import { FilterMatchMode } from 'shared_ui/api';
import { ITableColumn } from 'shared_ui/components';
import {
  IConfigField,
  IDataServiceInitialConfig,
} from 'shared_ui/components/DataService';
import {
  ColumnBodyOptions,
  DataTable,
  DataTableFilterMetaData,
  DataTableOperatorFilterMetaData,
} from 'shared_ui/primereact';

export type ColumnLocalFilterType =
  | 'boolean'
  | 'datetime'
  | 'number'
  | 'text'
  | 'multi';

type GlobalColumnSearch = {
  global: { value: string; matchMode: FilterMatchMode };
};
export type FilterMeta<T> = Partial<
  Record<
    keyof (T & GlobalColumnSearch),
    DataTableFilterMetaData | DataTableOperatorFilterMetaData
  >
>;

export type IConfigFieldFilterType = IConfigField['table'] & {
  filterType?: ColumnLocalFilterType;
};

type IConfigFieldType<T> = IConfigField & {
  name: Extract<keyof T, string>;
  table?: IConfigFieldFilterType;
};

export type InstructionMetaDataType<T> = IDataServiceInitialConfig & {
  fields: IConfigFieldType<T>[];
};

export type BaseConfigFieldType = Omit<
  IConfigField,
  'name' | 'displayName' | 'filter'
>;

export type ColumnsMetaDataType<T> = ITableColumn & {
  field: Extract<keyof T, string>;
  filterType?: ColumnLocalFilterType;
};

export type ColumnBodyOptionsType<T> = ColumnBodyOptions & {
  field: keyof T;
};

export type CellDataType = string | number | boolean | Date;

export type TableProps = ComponentProps<typeof DataTable>;
