import { useMemo, useRef } from 'react';

import {
  Box,
  Column,
  DataTableRowEvent,
  DataTableSelectionSingleChangeEvent,
  DataTableValueArray,
  Table,
} from 'shared_ui/components';
import {
  ContextMenu as ContextMenuPrime,
  DataTableContextMenuSelectionChangeEvent,
  DataTablePageEvent,
  DataTableRowClickEvent,
} from 'shared_ui/primereact';

import {
  InstructionContextMenu,
  InstructionContextMenuItem,
} from 'features/InstructionContextMenu';

import { InstructionModels, InstructionTypeModels } from 'shared/types/common';

import { renderFilterElement } from '../lib/renderColumnLocalFilter';
import { ColumnsMetaDataType, TableProps } from '../lib/types';
import { useColumnData } from '../lib/useColumnData';

// Общий тип для всех элементов контекстного меню
interface CustomTableProps<T> {
  dataKey: TableProps['dataKey'];
  header?: TableProps['header'];
  value: TableProps['value'];
  filters?: TableProps['filters'];
  onFilter?: TableProps['onFilter'];
  tableMetaData: ColumnsMetaDataType<T>[];
  loading?: boolean;
  stateKey?: string;
  /** Серверная пагинация: передавать в запрос first/rows */
  lazy?: boolean;
  totalRecords?: number;
  first?: number;
  rows?: number;
  onPage?: (event: DataTablePageEvent) => void;
  /** Серверная сортировка при lazy: передавать sortField/sortOrder в запрос */
  sortField?: string;
  sortOrder?: 0 | 1 | -1 | null;
  onSort?: (event: {
    sortField?: string;
    sortOrder?: 0 | 1 | -1 | null;
  }) => void;
  onSelect?: (value: InstructionTypeModels | InstructionModels | null) => void;

  cm: React.RefObject<ContextMenuPrime> | null;
  onContextMenuCommand: (item: InstructionContextMenuItem) => null | undefined;
  selectedItem: unknown;
  onContextMenuSelectionChange: (
    e: DataTableContextMenuSelectionChangeEvent<DataTableValueArray>,
  ) => void;
  onContextMenu: (e: DataTableRowEvent) => void;
  onSelectionChange: (
    e: DataTableSelectionSingleChangeEvent<DataTableValueArray>,
  ) => void;
  onRowDoubleClick: (e: DataTableRowClickEvent) => void;
}

const DEFAULT_PAGE_SIZE = 100;

type FilterConstraint = { value?: unknown; matchMode?: string };
type FilterMetaEntry = {
  value?: unknown;
  matchMode?: string;
  constraints?: FilterConstraint[];
};

const isDateMatchMode = (matchMode?: string): boolean =>
  matchMode === 'dateIs' || matchMode === 'DATE_IS';

const toValidDateOrNull = (value: unknown): Date | null => {
  if (value == null || value === '') return null;
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : value;
  }
  if (typeof value === 'number' || typeof value === 'string') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  return null;
};

const normalizeDateFilters = <F extends TableProps['filters']>(
  rawFilters: F,
): F => {
  if (!rawFilters) return rawFilters;

  const normalized = { ...rawFilters } as Record<string, unknown>;
  Object.entries(normalized).forEach(([key, rawEntry]) => {
    const entry = rawEntry as FilterMetaEntry | undefined;
    if (!entry || typeof entry !== 'object') return;

    if (entry.constraints?.length) {
      const hasDateConstraint = entry.constraints.some(c =>
        isDateMatchMode(c?.matchMode),
      );
      if (!hasDateConstraint) return;

      normalized[key] = {
        ...entry,
        constraints: entry.constraints.map(c =>
          isDateMatchMode(c?.matchMode)
            ? { ...c, value: toValidDateOrNull(c?.value) }
            : c,
        ),
      };
      return;
    }

    if (isDateMatchMode(entry.matchMode)) {
      normalized[key] = {
        ...entry,
        value: toValidDateOrNull(entry.value),
      };
    }
  });

  return normalized as F;
};

const normalizeDateCellValue = (value: unknown): Date | null => {
  if (value == null || value === '') return null;
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : value;
  }
  if (typeof value === 'number' || typeof value === 'string') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  return null;
};

export const CustomTable = <T,>({
  dataKey,
  header,
  value,
  filters,
  onFilter,
  tableMetaData,
  loading,
  stateKey,
  lazy,
  totalRecords,
  first,
  rows,
  onPage,
  sortField,
  sortOrder,
  onSort,
  onSelect,
  cm,
  onContextMenuCommand,
  selectedItem,
  onContextMenuSelectionChange,
  onContextMenu,
  onSelectionChange,
  onRowDoubleClick,
}: CustomTableProps<T>) => {
  const { columnDataMap, setTableValue } = useColumnData<T>({
    value,
    tableMetaData,
  });

  const columnDataMapRef = useRef(columnDataMap);
  columnDataMapRef.current = columnDataMap;
  const normalizedFilters = normalizeDateFilters(filters);
  const dateFields = useMemo(
    () =>
      tableMetaData
        .filter(column => column.filterType === 'datetime')
        .map(column => column.field),
    [tableMetaData],
  );
  const normalizedValue = useMemo(() => {
    if (!Array.isArray(value) || dateFields.length === 0) return value;

    return value.map(row => {
      if (row == null || typeof row !== 'object') return row;
      const nextRow = { ...(row as Record<string, unknown>) };

      dateFields.forEach(field => {
        nextRow[String(field)] = normalizeDateCellValue(nextRow[String(field)]);
      });

      return nextRow;
    });
  }, [value, dateFields]);

  const isLazy = Boolean(lazy && typeof totalRecords === 'number' && onPage);

  return (
    <Box className="p-2" rounded>
      <InstructionContextMenu ref={cm} onCommand={onContextMenuCommand} />
      <Table
        dataKey={dataKey}
        tableClassName="white-space-nowrap"
        header={header}
        emptyMessage="Нет доступных записей"
        paginator
        lazy={isLazy}
        rows={isLazy ? (rows ?? DEFAULT_PAGE_SIZE) : DEFAULT_PAGE_SIZE}
        first={isLazy ? (first ?? 0) : undefined}
        totalRecords={isLazy ? totalRecords : undefined}
        onPage={isLazy ? onPage : undefined}
        sortField={isLazy ? sortField : undefined}
        sortOrder={isLazy ? sortOrder : undefined}
        onSort={isLazy ? onSort : undefined}
        scrollable
        scrollHeight="calc(100vh - 214px)"
        selection={selectedItem!}
        onContextMenuSelectionChange={onContextMenuSelectionChange}
        onContextMenu={onContextMenu}
        showGridlines
        value={normalizedValue}
        selectionMode="single"
        onSelectionChange={e => {
          onSelectionChange(e);
          if (onSelect) {
            onSelect(e.value);
          }
        }}
        onRowDoubleClick={onRowDoubleClick}
        filters={normalizedFilters}
        onFilter={e => {
          if (!onFilter) return;
          const normalizedEvent = {
            ...e,
            filters: normalizeDateFilters(e.filters),
          };
          onFilter(normalizedEvent);
        }}
        onValueChange={setTableValue}
        loading={loading}
        stateStorage={stateKey ? 'session' : undefined}
        stateKey={stateKey ?? undefined}
      >
        {tableMetaData.map(
          ({ field, header, filterType: localFilterType, ...rest }) => (
            <Column
              key={field}
              field={field}
              header={header}
              filter
              filterField={field}
              sortable
              showAddButton={false}
              showFilterOperator={false}
              filterElement={options =>
                renderFilterElement({
                  options,
                  filterType: localFilterType,
                  rawColumnData: columnDataMapRef.current.get(field),
                })
              }
              {...rest}
            />
          ),
        )}
      </Table>
    </Box>
  );
};
