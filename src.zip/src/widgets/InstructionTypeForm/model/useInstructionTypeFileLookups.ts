import {
  IrcFileNameAlgorithm,
  IrcTemplate,
  useInstructionTypeFilesFormatsQuery,
  useInstructionTypeFilesGettingWaysQuery,
  useInstructionTypeTemplatesQuery,
  useIrcFileNameAlgorithmsQuery,
} from 'graphql/generated/generated';
import { useMemo } from 'react';

const sortByName = <T extends { name?: string | null }>(items: T[]): T[] =>
  [...items].sort((a, b) =>
    (a.name ?? '').localeCompare(b.name ?? '', 'ru', { numeric: true }),
  );

export const useInstructionTypeFileLookups = (enabled: boolean) => {
  const { data: fileNameAlgorithmsData } = useIrcFileNameAlgorithmsQuery({
    skip: !enabled,
  });
  const { data: fileFormatsData } = useInstructionTypeFilesFormatsQuery({
    skip: !enabled,
  });
  const { data: fileTemplatesData } = useInstructionTypeTemplatesQuery({
    skip: !enabled,
  });
  const { data: fileSourceTypesData } = useInstructionTypeFilesGettingWaysQuery(
    {
      skip: !enabled,
    },
  );

  const fileNameAlgorithms = useMemo(
    () =>
      sortByName(
        (fileNameAlgorithmsData?.ircFileNameAlgorithms?.items ?? []).filter(
          (x): x is IrcFileNameAlgorithm => x != null,
        ),
      ),
    [fileNameAlgorithmsData],
  );

  const fileFormats = fileFormatsData?.ircFileFormats?.items ?? [];
  const fileTemplates = useMemo(
    () =>
      sortByName(
        (fileTemplatesData?.ircTemplates?.items ?? []).filter(
          (x): x is IrcTemplate => x != null,
        ),
      ),
    [fileTemplatesData],
  );
  const fileSourceTypes = fileSourceTypesData?.ircFileSourceTypes?.items ?? [];

  return {
    fileNameAlgorithms,
    fileFormats,
    fileTemplates,
    fileSourceTypes,
  };
};
