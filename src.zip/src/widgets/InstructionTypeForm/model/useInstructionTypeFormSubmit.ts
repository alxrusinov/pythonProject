import {
  InstructionTypeOperationsByIdDocument,
  IrcCreateInstructionTypeFileInput,
  IrcCreateInstructionTypeInput,
  IrcDeleteInstructionTypeFileInput,
  IrcDeleteInstructionTypeInput,
  IrcFileNameAlgorithm,
  IrcUpdateInstructionTypeInput,
  useCreateInstructionTypeMutation,
  useDeleteInstructionTypeMutation,
  useEntityNotificationsSubscription,
  useUpdateInstructionTypeMutation,
} from 'graphql/generated/generated';
import { useMemo, useRef } from 'react';
import { UseFormReturn } from 'react-hook-form';
import { generatePath, useNavigate, useParams } from 'react-router-dom';

import { useApolloClient } from '@apollo/client';

import { makeNotification } from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { paths } from 'shared/routes/paths';
import { buildPath } from 'shared/utils/buildPath';
import { decodeOperationError } from 'shared/utils/decodeOperationError';

import {
  CreateInstructionTypeFormValues,
  InstructionTypeFileFormInput,
} from '../lib/types';
import { useInstructionTypeInvalid } from './useInstructionTypeInvalid';
import { validateInstructionTypeForm } from './validateInstructionTypeForm';

type UseInstructionTypeFormSubmitProps = {
  methods: UseFormReturn<CreateInstructionTypeFormValues>;
  fileNameAlgorithms: IrcFileNameAlgorithm[];
};

// Ответы по WS могут приходить с другим entityType.
const SUBSCRIBE_ALL_ENTITY_TYPES: string[] | undefined = undefined;

export const useInstructionTypeFormSubmit = ({
  methods,
  fileNameAlgorithms,
}: UseInstructionTypeFormSubmitProps) => {
  const navigate = useNavigate();
  const apolloClient = useApolloClient();
  const { masterId } = useParams();
  const { handleSubmit, getValues, reset } = methods;
  const createInstructionTypeUUID = useMemo(() => UUID(), []);
  const updateInstructionTypeUUID = useMemo(() => UUID(), []);

  const createInFlightRef = useRef(false);
  const updateInFlightRef = useRef(false);
  const handledCreateNotificationRef = useRef(false);
  const handledUpdateNotificationRef = useRef(false);

  const subscriptionVariables = useMemo(
    () => ({
      entityTypes: SUBSCRIBE_ALL_ENTITY_TYPES,
    }),
    [],
  );

  useEntityNotificationsSubscription({
    variables: subscriptionVariables,
    shouldResubscribe: true,
    onData: ({ data }) => {
      const notification = data.data?.entityNotifications;
      if (!notification) return;

      if (
        notification.correlationId === createInstructionTypeUUID &&
        createInFlightRef.current &&
        !handledCreateNotificationRef.current
      ) {
        handledCreateNotificationRef.current = true;
        createInFlightRef.current = false;

        if (notification.error) {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: decodeOperationError(
              notification.error,
              'instructionType',
            ),
          });
          return;
        }

        if (notification.entityId) {
          makeNotification({
            variant: 'success',
            title: 'Успех!',
            message: `Тип инструкции создана успешно`,
          });

          navigate(
            buildPath(
              generatePath(paths.editInstructionTemplate, {
                masterId: notification.entityId,
              }),
            ),
          );
        }
        return;
      }

      if (
        notification.correlationId === updateInstructionTypeUUID &&
        updateInFlightRef.current &&
        !handledUpdateNotificationRef.current
      ) {
        handledUpdateNotificationRef.current = true;
        updateInFlightRef.current = false;

        if (notification.error) {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: decodeOperationError(
              notification.error,
              'instructionType',
            ),
          });
          return;
        }

        if (notification.entityId) {
          makeNotification({
            variant: 'success',
            title: 'Успех!',
            message: `Тип инструкции сохранена успешно`,
          });

          const values = getValues();
          const tab = values?.inputInstructionTypeDataTab;
          const createTypeFiles = tab?.createTypeFiles ?? [];
          const allFileIds = createTypeFiles
            .map(f => f.id)
            .filter(
              (id): id is string => typeof id === 'string' && id.length > 0,
            );
          const restoredFilesDateToById = createTypeFiles.reduce<
            Record<string, string>
          >((acc, f) => {
            if (f.id != null) {
              acc[f.id] =
                f.dateTo != null
                  ? toDateTimeString(f.dateTo)
                  : (f.dateTo as any);
            }
            return acc;
          }, {});

          reset({
            ...values,
            inputInstructionTypeDataTab: {
              ...tab,
              customRestoredFilesIds: allFileIds,
              restoredFilesDateToById,
            },
          });

          if (masterId) {
            void apolloClient.refetchQueries({
              include: [InstructionTypeOperationsByIdDocument],
            });
          }
        }
      }
    },
    onError: () => {
      if (createInFlightRef.current && !handledCreateNotificationRef.current) {
        handledCreateNotificationRef.current = true;
        createInFlightRef.current = false;
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: `Ошибка создания типа инструкции`,
        });
      }
      if (updateInFlightRef.current && !handledUpdateNotificationRef.current) {
        handledUpdateNotificationRef.current = true;
        updateInFlightRef.current = false;
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: `Ошибка сохранения типа инструкции`,
        });
      }
    },
  });

  const [createInstructionTypeMutation] = useCreateInstructionTypeMutation();
  const [updateInstructionTypeMutation] = useUpdateInstructionTypeMutation();
  const [deleteInstructionTypeMutation] = useDeleteInstructionTypeMutation();

  const { handleInvalid } = useInstructionTypeInvalid({
    getValues,
    fileNameAlgorithms,
  });

  const toDateTimeString = (v: string | Date | null | undefined): string => {
    if (v == null) return '';
    if (typeof v === 'string') return v;
    return (v as Date)?.toISOString?.() ?? '';
  };

  const toCreateFileInput = (
    file: InstructionTypeFileFormInput & { notReadOnly?: boolean },
  ): IrcCreateInstructionTypeFileInput => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { id, notReadOnly, ...rest } = file;
    const dateTo =
      rest.dateTo == null || rest.dateTo === ''
        ? new Date().toISOString()
        : toDateTimeString(rest.dateTo);

    return {
      dateFrom:
        rest.dateFrom != null ? toDateTimeString(rest.dateFrom) : undefined,
      dateTo,
      fileFormatId: rest.fileFormatId ?? 0,
      fileNameAlgoId: rest.fileNameAlgoId ?? 0,
      fileSourceTypeId: rest.fileSourceTypeId ?? 0,
      prefix: rest.prefix?.trim() ? rest.prefix.trim() : undefined,
      templateId: rest.templateId ?? undefined,
    };
  };

  const toDeleteFileInput = (
    file: InstructionTypeFileFormInput,
  ): IrcDeleteInstructionTypeFileInput => ({
    id: file.id!,
    dateTo: (file.dateTo != null ? toDateTimeString(file.dateTo) : null) as
      | string
      | null,
  });

  const onSubmit =
    (createInstructionType: boolean) =>
    async (formData: CreateInstructionTypeFormValues) => {
      const validationResult = validateInstructionTypeForm(
        formData,
        fileNameAlgorithms,
      );
      if (!validationResult.isValid) {
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: `Не заполнены обязательные поля: ${validationResult.missingFields.join(', ')}`,
        });
        return;
      }

      const tab = formData?.inputInstructionTypeDataTab;
      const customRestoredFilesIds = tab?.customRestoredFilesIds ?? [];
      const createTypeFiles = tab?.createTypeFiles ?? [];
      const respPrepId = tab?.respPrepId ?? null;

      if (!respPrepId) {
        return;
      }

      /** id на бэк — из выбранных сущностей в селектах (в т.ч. после enrich addressSelectLabel) */
      const orgIdForApi = tab.org?.id ?? tab.orgId ?? 0;
      const orgAdrIdForApi = tab.orgAdr?.id ?? tab.orgAdrId ?? 0;

      const isRestoredFile = (file: InstructionTypeFileFormInput) =>
        file.id != null && customRestoredFilesIds.includes(file.id);

      const correlationId = createInstructionType
        ? createInstructionTypeUUID
        : updateInstructionTypeUUID;

      try {
        if (createInstructionType) {
          createInFlightRef.current = true;
          handledCreateNotificationRef.current = false;
          const createFiles: IrcCreateInstructionTypeFileInput[] =
            createTypeFiles.map(toCreateFileInput);
          const input: IrcCreateInstructionTypeInput = {
            correlationId,
            clientId: tab.clientId ?? undefined,
            commentType: tab.commentType ?? undefined,
            countryFromId: tab.countryFromId ?? 0,
            countryToId: tab.countryToId ?? 0,
            createFiles,
            dateFrom:
              tab.dateFrom != null ? toDateTimeString(tab.dateFrom) : undefined,
            name: tab.name ?? '',
            respPrepId,
            orgId: orgIdForApi,
            orgAdrId: orgAdrIdForApi,
            respPrepSign: tab.respPrepSign ?? '',
            manualRespPrepPosition: tab.manualRespPrepPosition ?? undefined,
          };
          await createInstructionTypeMutation({
            variables: { input },
          });
        } else if (masterId) {
          updateInFlightRef.current = true;
          handledUpdateNotificationRef.current = false;
          const newFiles = createTypeFiles.filter(f => !isRestoredFile(f));
          const existingFiles = createTypeFiles.filter(isRestoredFile);
          const restoredDateToById =
            tab?.restoredFilesDateToById ?? ({} as Record<string, string>);
          const filesWithDateToChanged = existingFiles.filter(
            f =>
              f.id != null &&
              (restoredDateToById[f.id] ?? '') !== (f.dateTo ?? ''),
          );
          const input: IrcUpdateInstructionTypeInput = {
            correlationId,
            clientId: tab.clientId ?? undefined,
            commentType: tab.commentType ?? undefined,
            countryFromId: tab.countryFromId ?? 0,
            countryToId: tab.countryToId ?? 0,
            createFiles: newFiles.map(toCreateFileInput),
            dateFrom:
              tab.dateFrom != null ? toDateTimeString(tab.dateFrom) : undefined,
            deleteFiles: filesWithDateToChanged.map(toDeleteFileInput),
            id: masterId,
            name: tab.name ?? '',
            orgId: orgIdForApi,
            orgAdrId: orgAdrIdForApi,
            respPrepId,
            respPrepSign: tab.respPrepSign ?? '',
            manualRespPrepPosition: tab.manualRespPrepPosition ?? undefined,
          };
          await updateInstructionTypeMutation({
            variables: { input },
          });
        }
      } catch {
        createInFlightRef.current = false;
        updateInFlightRef.current = false;
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: 'Непредвиденная ошибка при выполнении запроса',
        });
      }
    };

  const saveForm = () => {
    handleSubmit(onSubmit(false), handleInvalid)();
  };

  const registerForm = () => {
    handleSubmit(onSubmit(true), handleInvalid)();
  };

  const closeInstructionTypeWithDateTo = async (dateTo: string | null) => {
    if (!masterId) return;
    const formData = methods.getValues();
    const validationResult = validateInstructionTypeForm(
      formData,
      fileNameAlgorithms,
    );
    if (!validationResult.isValid) {
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: `Не заполнены обязательные поля: ${validationResult.missingFields.join(', ')}`,
      });
      return;
    }
    const input: IrcDeleteInstructionTypeInput = {
      correlationId: updateInstructionTypeUUID,
      dateTo: dateTo ?? null,
      id: masterId,
    };
    try {
      await deleteInstructionTypeMutation({
        variables: { input },
      });
      makeNotification({
        variant: 'success',
        title: 'Успех!',
        message: 'Тип инструкции закрыт успешно',
      });
      navigate(buildPath(paths.carInstructionTemplates));
    } catch {
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Ошибка закрытия типа инструкции',
      });
      throw new Error('Close failed');
    }
  };

  return { saveForm, registerForm, closeInstructionTypeWithDateTo };
};
