import { generatePath, useNavigate } from 'react-router-dom';

import { useInstructionTypeFormTabMenuStore } from 'features/InstructionTypeFormTabMenu';

import { paths } from 'shared/routes/paths';
import { buildPath } from 'shared/utils/buildPath';

import { CREATE_INSTRUCTION_TYPE_FORM_STEPS } from '../lib/constants';

export const useBackAction = () => {
  const navigate = useNavigate();

  const setActiveTab = useInstructionTypeFormTabMenuStore(
    state => state.setActiveTab,
  );

  return () => {
    navigate(buildPath(generatePath(paths.carInstructionTemplates)), {
      replace: true,
    });
    setActiveTab(CREATE_INSTRUCTION_TYPE_FORM_STEPS[0].value);
  };
};
