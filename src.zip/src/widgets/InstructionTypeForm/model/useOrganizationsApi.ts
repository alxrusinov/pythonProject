import {
  ImpOrgPassport,
  useImpOrgPassportsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import {
  FILTER_TYPE_NAME_KONTRAGENT,
  FILTER_TYPE_NAME_TCFTO,
} from 'widgets/InstructionForm/lib/constants';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchOrganizationsProps = {
  restoredOrganization: ImpOrgPassport | null;
};

export const useOrganizationsApi = ({
  restoredOrganization,
}: useSearchOrganizationsProps) => {
  const [search, setSearch] = useState('');
  const [fetchOrganizations, { data }] = useImpOrgPassportsLazyQuery();

  const handleChangeOrganizationsSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchOrganizations({
        variables: {
          where: {
            and: [
              { lastRec: { eq: true } },
              { shortName: { icontains: q } },
              {
                or: [
                  { typeName: { icontains: FILTER_TYPE_NAME_TCFTO } },
                  { typeName: { icontains: FILTER_TYPE_NAME_KONTRAGENT } },
                ],
              },
            ],
          },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchOrganizations],
  );

  const organizations = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.impOrgPassports?.items ?? [])
      : [];

    return restoredOrganization
      ? compareRecords(items, restoredOrganization)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredOrganization, search]);

  return {
    handleChangeOrganizationsSearch,
    organizations,
  };
};
