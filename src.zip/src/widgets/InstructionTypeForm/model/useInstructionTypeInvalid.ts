import { IrcFileNameAlgorithm } from 'graphql/generated/generated';
import { FieldErrors } from 'react-hook-form';

import { makeNotification } from 'shared_ui/components';

import { CreateInstructionTypeFormValues } from '../lib/types';
import { validateInstructionTypeForm } from './validateInstructionTypeForm';

type UseInstructionTypeInvalidProps = {
  getValues: () => CreateInstructionTypeFormValues;
  fileNameAlgorithms: IrcFileNameAlgorithm[];
};

export const useInstructionTypeInvalid = ({
  getValues,
  fileNameAlgorithms,
}: UseInstructionTypeInvalidProps) => {
  const handleInvalid = (
    errors: FieldErrors<CreateInstructionTypeFormValues>,
  ) => {
    if (errors.inputInstructionTypeDataTab) {
      const validationResult = validateInstructionTypeForm(
        getValues(),
        fileNameAlgorithms,
      );
      const message =
        validationResult.missingFields.length > 0
          ? `Не заполнены обязательные поля: ${validationResult.missingFields.join(', ')}`
          : 'Не заполнены обязательные поля';
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message,
      });
    }
  };

  return { handleInvalid };
};
