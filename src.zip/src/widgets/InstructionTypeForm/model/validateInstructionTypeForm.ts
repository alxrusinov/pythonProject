import { IrcFileNameAlgorithm } from 'graphql/generated/generated';

import { CREATE_INSTRUCTION_TYPE_FORM_NAMES } from '../lib/constants';
import {
  CreateInstructionTypeFormValues,
  InstructionTypeFileFormInput,
} from '../lib/types';

/** id способа получения «Документ пользователя» — для него не проверяем Шаблон */
const FILE_SOURCE_TYPE_USER_DOCUMENT_ID = 2;

export type ValidationResult = {
  isValid: boolean;
  missingFields: string[];
};

const hasValue = (v: unknown): boolean =>
  v != null && v !== '' && (typeof v !== 'string' || v.trim() !== '');

const algoRequiresPrefix = (
  fileNameAlgoId: number | null | undefined,
  fileNameAlgorithms?: Pick<IrcFileNameAlgorithm, 'id' | 'isPrefixRequired'>[],
): boolean => {
  if (
    fileNameAlgoId == null ||
    fileNameAlgoId === 0 ||
    !fileNameAlgorithms?.length
  ) {
    return false;
  }
  const algo = fileNameAlgorithms.find(a => a.id === fileNameAlgoId);
  return Boolean(algo?.isPrefixRequired);
};

export const validateInstructionTypeForm = (
  formData: CreateInstructionTypeFormValues,
  fileNameAlgorithms?: Pick<IrcFileNameAlgorithm, 'id' | 'isPrefixRequired'>[],
): ValidationResult => {
  const tab = formData?.inputInstructionTypeDataTab;
  const missingFields: string[] = [];

  if (!hasValue(tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.NAME])) {
    missingFields.push('Тип инструкции');
  }

  if (!tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM]?.id) {
    missingFields.push('Страна отправления');
  }

  if (!tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO]?.id) {
    missingFields.push('Страна назначения');
  }

  // Клиент — необязательное поле
  // Комментарий — необязательное поле

  if (!tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION]?.id) {
    missingFields.push('Организация отправителя');
  }

  if (
    tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS]?.id ===
      null ||
    tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS]?.id ===
      undefined
  ) {
    missingFields.push('Адрес организации отправителя');
  }

  if (!tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_ID]) {
    missingFields.push('Подписант');
  }

  if (
    !hasValue(
      tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_SIGNATURE],
    )
  ) {
    missingFields.push('Факсимиле подписанта');
  }

  const files = (tab?.[CREATE_INSTRUCTION_TYPE_FORM_NAMES.CREATE_TYPE_FILES] ??
    []) as InstructionTypeFileFormInput[];

  files.forEach((file, index) => {
    const fileMissing: string[] = [];
    if (!file?.fileNameAlgoId) {
      fileMissing.push('Алгоритм');
    }
    if (algoRequiresPrefix(file?.fileNameAlgoId, fileNameAlgorithms)) {
      if (!hasValue(file?.prefix)) {
        fileMissing.push('Префикс');
      }
    }
    if (!file?.fileFormatId) {
      fileMissing.push('Формат');
    }
    if (!file?.fileSourceTypeId) {
      fileMissing.push('Способ получения');
    }
    if (
      file?.fileSourceTypeId &&
      file.fileSourceTypeId !== FILE_SOURCE_TYPE_USER_DOCUMENT_ID &&
      !file?.templateId
    ) {
      fileMissing.push('Шаблон');
    }
    if (fileMissing.length > 0) {
      const fileLabel = files.length > 1 ? `Вложение ${index + 1}` : 'Вложение';
      missingFields.push(`${fileLabel} (${fileMissing.join(', ')})`);
    }
  });

  const hasAtLeastOneFileWithTemplateSource = files.some(
    file =>
      file?.fileSourceTypeId != null &&
      file.fileSourceTypeId !== FILE_SOURCE_TYPE_USER_DOCUMENT_ID,
  );
  if (!hasAtLeastOneFileWithTemplateSource) {
    missingFields.push(
      'Необходимо хотя бы одно вложение со способом получения «Шаблон»',
    );
  }

  return {
    isValid: missingFields.length === 0,
    missingFields,
  };
};
