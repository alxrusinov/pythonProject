import {
  NsiCountry,
  useNsiCountriesLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchCountriesFromProps = {
  restoredCountryFrom: NsiCountry | null;
};

export const useNsiCountriesFromApi = ({
  restoredCountryFrom,
}: useSearchCountriesFromProps) => {
  const [search, setSearch] = useState('');
  const [fetchCountries, { data }] = useNsiCountriesLazyQuery();

  const handleChangeCountriesFromSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchCountries({
        variables: {
          where: { name: { icontains: q } },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchCountries],
  );

  const countriesFrom = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiCountries?.items ?? [])
      : [];

    return restoredCountryFrom
      ? compareRecords(items, restoredCountryFrom)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredCountryFrom, search]);

  return {
    handleChangeCountriesFromSearch,
    countriesFrom,
  };
};
