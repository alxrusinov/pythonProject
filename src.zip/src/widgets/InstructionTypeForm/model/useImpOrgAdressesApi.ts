import { useImpOrgPassportsQuery } from 'graphql/generated/generated';

import { getStableRequestDate } from 'shared/utils/date';

export const useImpOrgAdressesApi = () => {
  const { data } = useImpOrgPassportsQuery({
    variables: { requestDate: getStableRequestDate() },
  });
  const organizationsAdresses = data?.impOrgPassports?.items || [];

  return { organizationsAdresses };
};
