import { useInstructionTypeFilesFormatsQuery } from 'graphql/generated/generated';

export const useFileFormatsApi = () => {
  const { data } = useInstructionTypeFilesFormatsQuery();
  const fileFormats = data?.ircFileFormats?.items || [];

  return { fileFormats };
};
