import { useInstructionTypeTemplatesQuery } from 'graphql/generated/generated';

export const useFileTemplatesApi = () => {
  const { data } = useInstructionTypeTemplatesQuery();
  const fileTemplates = data?.ircTemplates?.items || [];

  return { fileTemplates };
};
