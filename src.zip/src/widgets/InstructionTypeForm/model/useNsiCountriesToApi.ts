import {
  NsiCountry,
  useNsiCountriesLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchCountriesToProps = {
  restoredCountryTo: NsiCountry | null;
};

export const useNsiCountriesToApi = ({
  restoredCountryTo,
}: useSearchCountriesToProps) => {
  const [search, setSearch] = useState('');
  const [fetchCountries, { data }] = useNsiCountriesLazyQuery();

  const handleChangeCountriesToSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchCountries({
        variables: {
          where: { name: { icontains: q } },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchCountries],
  );

  const countriesTo = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiCountries?.items ?? [])
      : [];

    return restoredCountryTo
      ? compareRecords(items, restoredCountryTo)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredCountryTo, search]);

  return {
    handleChangeCountriesToSearch,
    countriesTo,
  };
};
