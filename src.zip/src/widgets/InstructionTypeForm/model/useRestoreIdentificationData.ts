import { useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import { useParams, useSearchParams } from 'react-router-dom';

import { CREATE_INSTRUCTION_TYPE_FORM_NAMES } from '../lib/constants';
import {
  CreateInstructionTypeFormValues,
  InstructionTypeFileFormInput,
  InstructionTypeParams,
} from '../lib/types';
import { useRestoredInstructionTypeContext } from './RestoredInstructionTypeContext';

/** Формат файла из ответа InstructionTypeById (вложенные fileFormat, fileSourceType, templates) */
type RestoredFileFromApi = {
  id?: string | null;
  prefix?: string | null;
  dateFrom?: string | null;
  dateTo?: string | null;
  templateId?: string | null;
  fileFormatId?: number | null;
  fileSourceTypeId?: number | null;
  fileNameAlgoId?: number | null;
  fileFormat?: { id?: number | null; name?: string | null } | null;
  fileSourceType?: { id?: number | null; name?: string | null } | null;
  fileNameAlgorithm?: { id?: number | null } | null;
  template?: { id?: string | null; name?: string | null } | null;
};

export const useRestoreIdentificationData = () => {
  const { masterId } = useParams<InstructionTypeParams>();
  const [searchParams] = useSearchParams();
  const { reset } = useFormContext<CreateInstructionTypeFormValues>();

  const { loading, restoredInstructionTypeData } =
    useRestoredInstructionTypeContext();

  const copyFrom = searchParams.get('copyFrom');
  const isCopyMode = !masterId && !!copyFrom;

  const transformFiles = (
    files: RestoredFileFromApi[] | null | undefined,
  ): InstructionTypeFileFormInput[] | null => {
    if (!files || files.length === 0) return null;

    const defaultDateTo = new Date(3000, 0, 1).toISOString();

    const transformedFiles = files.map(
      (file: RestoredFileFromApi): InstructionTypeFileFormInput => {
        const base: InstructionTypeFileFormInput = {
          id: file.id ?? undefined,
          prefix: file.prefix ?? '',
          fileNameAlgoId:
            file.fileNameAlgorithm?.id ?? file.fileNameAlgoId ?? 0,
          fileFormatId: file.fileFormat?.id ?? file.fileFormatId ?? 0,
          fileSourceTypeId:
            file.fileSourceType?.id ?? file.fileSourceTypeId ?? 0,
          templateId: file.template?.id ?? file.templateId ?? undefined,
          dateFrom: file.dateFrom ?? '',
          dateTo: file.dateTo ?? '',
        };

        if (isCopyMode) {
          return {
            ...base,
            dateFrom: null,
            dateTo: defaultDateTo,
          };
        }

        return base;
      },
    );

    return transformedFiles.length > 0 ? transformedFiles : null;
  };

  const restoredFilesIds =
    !isCopyMode && restoredInstructionTypeData?.files
      ? restoredInstructionTypeData.files
          .map(file => file?.id)
          .filter((id): id is string => !!id)
      : [];

  const restoredFilesDateToById: Record<string, string> =
    !isCopyMode && restoredInstructionTypeData?.files
      ? restoredInstructionTypeData.files.reduce<Record<string, string>>(
          (acc, file) => {
            if (file?.id != null) {
              acc[file.id] = file.dateTo ?? '';
            }
            return acc;
          },
          {},
        )
      : {};

  useEffect(() => {
    // Данные для восстановления формы (при редактировании по masterId или при копировании по copyFrom)
    const hasData = !!restoredInstructionTypeData;
    if (!hasData) return;

    const createTypeFiles = transformFiles(restoredInstructionTypeData.files);

    const inputInstructionTypeDataTab: CreateInstructionTypeFormValues['inputInstructionTypeDataTab'] =
      {
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ID]:
          restoredInstructionTypeData.id ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.NAME]:
          restoredInstructionTypeData.name ?? '',
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM]:
          restoredInstructionTypeData.countryFrom ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM_ID]:
          restoredInstructionTypeData.countryFrom?.id ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO]:
          restoredInstructionTypeData.countryTo ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO_ID]:
          restoredInstructionTypeData.countryTo?.id ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_FROM]:
          restoredInstructionTypeData.dateFrom ?? '',
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_TO]:
          restoredInstructionTypeData.dateTo ?? '',
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT]:
          restoredInstructionTypeData.client ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT_ID]:
          restoredInstructionTypeData.client?.id ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS]:
          restoredInstructionTypeData.orgAddress ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS_ID]:
          restoredInstructionTypeData.orgAddress?.id ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION]:
          restoredInstructionTypeData.organization ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ID]:
          restoredInstructionTypeData.organization?.id ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_SIGNATURE]:
          restoredInstructionTypeData.respPrepSign ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_ID]:
          restoredInstructionTypeData.respPrepare?.id ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.MANUAL_RESP_PREP_POSITION]:
          restoredInstructionTypeData.manualRespPrepPosition ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COMMENT_TYPE]:
          restoredInstructionTypeData.commentType ?? null,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CREATE_TYPE_FILES]: createTypeFiles,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CUSTOM_RESTORED_FILES_IDS]:
          restoredFilesIds,
        [CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESTORED_FILES_DATE_TO_BY_ID]:
          restoredFilesDateToById,
      };

    reset({
      inputInstructionTypeDataTab,
    });
  }, [restoredInstructionTypeData, reset, isCopyMode]);

  return {
    loading,
    restoredInstructionTypeData,
  };
};
