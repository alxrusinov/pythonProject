import { useParams } from 'react-router-dom';

import { CREATE_INSTRUCTION_TYPE_FORM_NAMES } from '../lib/constants';
import { getInputInstructionTypeDataTabFieldName } from '../lib/getFormFields';
import { InstructionTypeParams } from '../lib/types';
import { useInstructionTypeFileLookups } from './useInstructionTypeFileLookups';
import { useInstructionTypeFormDefaults } from './useInstructionTypeFormDefaults';
import { useInstructionTypeFormSubmit } from './useInstructionTypeFormSubmit';
import { useInstructionTypeTabs } from './useInstructionTypeTabs';

type UseCreateInstructionTypeOptions = {
  disabled?: boolean;
};

export const useCreateInstructionType = ({
  disabled = false,
}: UseCreateInstructionTypeOptions = {}) => {
  const { masterId } = useParams<InstructionTypeParams>();

  const { methods } = useInstructionTypeFormDefaults(masterId);

  const createTypeFiles = methods.watch(
    getInputInstructionTypeDataTabFieldName(
      CREATE_INSTRUCTION_TYPE_FORM_NAMES.CREATE_TYPE_FILES,
    ),
  );
  const fileLookupsEnabled = (createTypeFiles?.length ?? 0) > 0;

  const { fileNameAlgorithms, fileFormats, fileTemplates, fileSourceTypes } =
    useInstructionTypeFileLookups(fileLookupsEnabled);

  const { tabSteps, activeTab, handleTabValidate } = useInstructionTypeTabs(
    methods,
    masterId || null,
    disabled,
  );

  const { saveForm, registerForm, closeInstructionTypeWithDateTo } =
    useInstructionTypeFormSubmit({
      methods,
      fileNameAlgorithms,
    });

  return {
    methods,
    activeTab,
    handleTabValidate,
    saveForm,
    registerForm,
    closeInstructionTypeWithDateTo,
    tabSteps,
    fileNameAlgorithms,
    fileFormats,
    fileTemplates,
    fileSourceTypes,
  };
};
