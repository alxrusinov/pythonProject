import { CalculationType } from 'graphql/generated/generated';
import { useFormContext } from 'react-hook-form';

import { DropdownChangeEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_TYPE_FORM_NAMES } from '../lib/constants';
import { getInputInstructionTypeDataTabFieldName } from '../lib/getFormFields';
import {
  CreateInstructionTypeFormValues,
  InstructionTypeFileFormInput,
} from '../lib/types';

export const useInputInstructionTypeDataTab = () => {
  const { setValue, clearErrors } =
    useFormContext<CreateInstructionTypeFormValues>();

  const handleClientChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT,
      ),
      e.value,
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT_ID,
      ),
      e.value?.id,
    );
    clearErrors('inputInstructionTypeDataTab');
  };

  const handleOrganizationChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION,
      ),
      e.value,
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ID,
      ),
      e.value?.id,
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS,
      ),
      null,
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS_ID,
      ),
      null,
    );
    clearErrors('inputInstructionTypeDataTab');
  };

  const handleOrganizationAdrChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS,
      ),
      e.value,
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS_ID,
      ),
      e.value?.id,
    );
    clearErrors('inputInstructionTypeDataTab');
  };

  const handleCountryFromChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM,
      ),
      e.value,
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM_ID,
      ),
      e.value?.id,
    );
    clearErrors('inputInstructionTypeDataTab');
  };

  const handleCountryToChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO,
      ),
      e.value,
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO_ID,
      ),
      e.value?.id,
    );
    clearErrors('inputInstructionTypeDataTab');
  };

  const handleSignatureChange = (
    file: string | null,
    onChange: (value: string | null) => void,
  ) => {
    onChange(file);
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_SIGNATURE,
      ),
      file,
    );
  };

  const handleSignatoryChange = (
    userId: string | null | undefined,
    onChange: (value: string | null) => void,
  ) => {
    const normalizedUserId = userId ?? null;
    onChange(normalizedUserId);
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_ID,
      ),
      normalizedUserId,
      { shouldDirty: true },
    );
    clearErrors('inputInstructionTypeDataTab');
  };

  const handleChangeFiles = (value: InstructionTypeFileFormInput[] | null) => {
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.CREATE_TYPE_FILES,
      ),
      value,
      { shouldDirty: true },
    );
  };

  return {
    handleCountryFromChange,
    handleCountryToChange,
    handleClientChange,
    handleOrganizationChange,
    handleOrganizationAdrChange,
    handleSignatureChange,
    handleSignatoryChange,
    handleChangeFiles,
  };
};
