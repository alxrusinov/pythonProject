import {
  ImpOrgAddress,
  ImpOrgPassport,
  Maybe,
  useGetImpOrgAddressLazyQuery,
} from 'graphql/generated/generated';
import { useEffect, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';
import { enrichImpOrgAddressesForSelect } from 'shared/utils/formatImpOrgAddressSelectLabel';

type useSearchOrganizationsAdrsProps = {
  organization: Maybe<ImpOrgPassport> | undefined;
  restoredOrganizationAdrs: ImpOrgAddress | null;
};

export const useOrganizationsAdrsApi = ({
  organization,
  restoredOrganizationAdrs,
}: useSearchOrganizationsAdrsProps) => {
  const [organizationsAdrs, setOrganizationsAdrs] = useState<ImpOrgAddress[]>(
    [],
  );
  const [fetchAddresses, { data, loading }] = useGetImpOrgAddressLazyQuery();

  useEffect(() => {
    setOrganizationsAdrs([]);

    if (organization?.id == null) return;

    fetchAddresses({
      variables: {
        where: {
          orgPassport: { id: { eq: organization.id } },
        },
        requestDate: getStableRequestDate(),
      },
    });
  }, [organization?.id, fetchAddresses]);

  const backendOrganizationsAddresses = data?.impOrgAddresses?.items || [];

  useEffect(() => {
    setOrganizationsAdrs(backendOrganizationsAddresses);
  }, [backendOrganizationsAddresses]);

  const organizationsAdrsForSelect = useMemo(
    () =>
      enrichImpOrgAddressesForSelect(
        restoredOrganizationAdrs &&
          restoredOrganizationAdrs?.orgPassport?.id === organization?.id
          ? compareRecords(organizationsAdrs, restoredOrganizationAdrs)
          : organizationsAdrs,
      ),
    [organizationsAdrs, restoredOrganizationAdrs, organization?.id],
  );

  return {
    organizationsAdrs: organizationsAdrsForSelect,
    organizationsAdrsBackendCount: backendOrganizationsAddresses.length,
    organizationsAdrsLoading: loading,
  };
};
