import { createContext, ReactNode, useContext } from 'react';

import { useGetRestoredInstructionTypeData } from './useGetRestoredInstructionTypeData';

type RestoredInstructionTypeContextValue = ReturnType<
  typeof useGetRestoredInstructionTypeData
>;

const RestoredInstructionTypeContext =
  createContext<RestoredInstructionTypeContextValue | null>(null);

export const RestoredInstructionTypeProvider = ({
  children,
}: {
  children: ReactNode;
}) => {
  const value = useGetRestoredInstructionTypeData();

  return (
    <RestoredInstructionTypeContext.Provider value={value}>
      {children}
    </RestoredInstructionTypeContext.Provider>
  );
};

export const useRestoredInstructionTypeContext = () => {
  const context = useContext(RestoredInstructionTypeContext);

  if (!context) {
    throw new Error(
      'useRestoredInstructionTypeContext must be used within RestoredInstructionTypeProvider',
    );
  }

  return context;
};
