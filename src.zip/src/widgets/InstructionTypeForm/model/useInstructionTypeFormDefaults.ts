import { DefaultValues, useForm } from 'react-hook-form';

import { CREATE_INSTRUCTION_TYPE_FORM_NAMES } from '../lib/constants';
import { CreateInstructionTypeFormValues } from '../lib/types';

export const useInstructionTypeFormDefaults = (_masterId?: string) => {
  const defaultValues: DefaultValues<CreateInstructionTypeFormValues> = {
    inputInstructionTypeDataTab: {
      [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CREATE_TYPE_FILES]: null,
      [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CUSTOM_RESTORED_FILES_IDS]: [],
      [CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESTORED_FILES_DATE_TO_BY_ID]: {},
    },
  };

  const methods = useForm<CreateInstructionTypeFormValues>({
    mode: 'all',
    defaultValues,
  });

  return { methods };
};
