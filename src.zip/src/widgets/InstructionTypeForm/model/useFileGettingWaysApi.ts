import { useInstructionTypeFilesGettingWaysQuery } from 'graphql/generated/generated';

export const useFileGettingWaysApi = () => {
  const { data } = useInstructionTypeFilesGettingWaysQuery();
  const fileSourceTypes = data?.ircFileSourceTypes?.items || [];

  return { fileSourceTypes };
};
