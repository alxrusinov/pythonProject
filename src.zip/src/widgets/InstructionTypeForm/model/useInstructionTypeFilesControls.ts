import { useEffect, useRef, useState } from 'react';

import {
  DataTableSelectionSingleChangeEvent,
  DataTableValueArray,
} from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { InstructionTypeFileFormInput, isFileType } from '../lib/types';

const FILE_KEYS = [
  'id',
  'prefix',
  'fileNameAlgoId',
  'dateFrom',
  'dateTo',
  'fileFormatId',
  'fileSourceTypeId',
  'templateId',
] as const;

const toComparable = (v: unknown): unknown =>
  v == null
    ? null
    : typeof (v as Date).toISOString === 'function'
      ? (v as Date).toISOString()
      : String(v);

const normalizeFile = (
  f: InstructionTypeFileFormInput,
): Record<string, unknown> => {
  const obj: Record<string, unknown> = {};
  for (const k of FILE_KEYS) {
    const v = f[k as keyof InstructionTypeFileFormInput];
    obj[k] = toComparable(v);
  }
  return obj;
};

const filesEqual = (
  a: InstructionTypeFileFormInput[],
  b: InstructionTypeFileFormInput[],
): boolean =>
  a.length === b.length &&
  a.every((fa, i) => {
    const na = normalizeFile(fa);
    const nb = normalizeFile(b[i]);
    return FILE_KEYS.every(k => na[k] === nb[k]);
  });

interface UseInstructionTypeFilesControlsProps {
  files: InstructionTypeFileFormInput[] | null | undefined;
  onFilesChangeForForm?: (files: InstructionTypeFileFormInput[] | null) => void;
  /** Id файлов, которые считаются сохранёнными в БД (для них notReadOnly не выставляем) */
  restoredFileIds?: string[];
  /** Значение алгоритма по умолчанию для новой строки */
  defaultFileNameAlgoId?: number;
}

export const useInstructionTypeFilesControls = ({
  files,
  onFilesChangeForForm,
  restoredFileIds,
  defaultFileNameAlgoId = 0,
}: UseInstructionTypeFilesControlsProps) => {
  const newFileIdsRef = useRef<Set<string>>(new Set());
  const restoredIdsKey = (restoredFileIds ?? []).slice().sort().join('|');
  const lastRestoredIdsKeyRef = useRef<string>(restoredIdsKey);

  const enrichWithNotReadOnly = (
    list: InstructionTypeFileFormInput[],
  ): (InstructionTypeFileFormInput & { notReadOnly?: boolean })[] =>
    list.map(f => {
      const fileId = f.id as string | null | undefined;
      const isPersistedFile = !!fileId && restoredFileIds?.includes(fileId);
      const isLocallyNewFile = !!fileId && newFileIdsRef.current.has(fileId);
      const isCopiedFileInCreateMode =
        !!fileId &&
        (restoredFileIds?.length ?? 0) === 0 &&
        !newFileIdsRef.current.has(fileId);

      return isLocallyNewFile || isCopiedFileInCreateMode || !isPersistedFile
        ? { ...f, notReadOnly: true }
        : { ...f };
    });

  const stripNotReadOnly = (
    file: InstructionTypeFileFormInput & { notReadOnly?: boolean },
  ): InstructionTypeFileFormInput => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { notReadOnly, ...rest } = file;
    return rest;
  };

  const [currentFiles, changeCurrentFiles] = useState<
    (InstructionTypeFileFormInput & { notReadOnly?: boolean })[]
  >(() => enrichWithNotReadOnly(files || []));
  const [selectedRow, setSelectedRow] =
    useState<InstructionTypeFileFormInput | null>(null);
  const lastSyncedFromFormRef = useRef<InstructionTypeFileFormInput[]>(
    files ?? [],
  );
  const lastSentToFormRef = useRef<InstructionTypeFileFormInput[] | null>(null);

  useEffect(() => {
    const next = files ?? [];
    if (
      lastSentToFormRef.current !== null &&
      filesEqual(next, lastSentToFormRef.current)
    ) {
      lastSyncedFromFormRef.current = next;
      lastSentToFormRef.current = null;
      return;
    }
    const restoredIdsChanged = lastRestoredIdsKeyRef.current !== restoredIdsKey;
    if (!restoredIdsChanged && filesEqual(next, lastSyncedFromFormRef.current))
      return;
    lastSyncedFromFormRef.current = next;
    lastSentToFormRef.current = null;
    lastRestoredIdsKeyRef.current = restoredIdsKey;
    changeCurrentFiles(enrichWithNotReadOnly(next));
    const nextIds = new Set(next.map(f => f.id).filter(Boolean) as string[]);
    newFileIdsRef.current = new Set(
      [...newFileIdsRef.current].filter(id => nextIds.has(id)),
    );
  }, [files, restoredIdsKey]);

  const onSelectionChange = (
    e: DataTableSelectionSingleChangeEvent<DataTableValueArray>,
  ) => {
    const value = e.value;
    if (value === null || isFileType(value)) {
      setSelectedRow(value);
    }
  };

  const onFilesChange = (
    rowData: InstructionTypeFileFormInput,
    newValue: string | Date | number | null,
    fieldName: string,
  ) => {
    changeCurrentFiles(oldCurrentFiles => {
      const newCurrentFiles = oldCurrentFiles.map(
        (item: InstructionTypeFileFormInput) => {
          if (item.id === rowData.id) {
            const newItem = { ...item, [fieldName]: newValue };
            return newItem;
          }

          return item;
        },
      );

      lastSentToFormRef.current = newCurrentFiles;
      onFilesChangeForForm?.(newCurrentFiles.map(stripNotReadOnly));
      return newCurrentFiles;
    });
  };

  const onAddNewFile = () => {
    changeCurrentFiles(oldCurrentFiles => {
      const newFile = createEmptyFile();
      newFileIdsRef.current.add(newFile.id as string);
      const newCurrentFiles = [...oldCurrentFiles, newFile];
      lastSentToFormRef.current = newCurrentFiles;
      onFilesChangeForForm?.(newCurrentFiles.map(stripNotReadOnly));
      return newCurrentFiles;
    });
  };

  const removeSelectedFile = (selectedFileId: string) => {
    const isNew = newFileIdsRef.current.has(selectedFileId);
    if (isNew) {
      newFileIdsRef.current.delete(selectedFileId);
      changeCurrentFiles(oldCurrentFiles => {
        const newCurrentFiles = oldCurrentFiles.filter(
          file => file.id !== selectedFileId,
        );
        lastSentToFormRef.current = newCurrentFiles;
        onFilesChangeForForm?.(newCurrentFiles.map(stripNotReadOnly));
        return newCurrentFiles;
      });
      if (selectedRow?.id === selectedFileId) {
        setSelectedRow(null);
      }
    }
    // Для сохранённого файла дату «Действует по» задают через модалку; вызывайте setFileDateTo после подтверждения
  };

  const setFileDateTo = (fileId: string, dateTo: string | null) => {
    changeCurrentFiles(oldCurrentFiles => {
      const newCurrentFiles = oldCurrentFiles.map(file =>
        file.id === fileId ? { ...file, dateTo } : file,
      );
      lastSentToFormRef.current = newCurrentFiles;
      onFilesChangeForForm?.(newCurrentFiles.map(stripNotReadOnly));
      return newCurrentFiles;
    });
    if (selectedRow?.id === fileId) {
      setSelectedRow(null);
    }
  };

  const createEmptyFile = (): InstructionTypeFileFormInput & {
    notReadOnly?: boolean;
  } => {
    return {
      id: UUID(),
      prefix: '',
      fileNameAlgoId: defaultFileNameAlgoId,
      dateFrom: null,
      dateTo: new Date(3000, 0, 1).toISOString(),
      fileFormatId: 0,
      fileSourceTypeId: 0,
      templateId: null,
      notReadOnly: true,
    };
  };

  return {
    currentFiles,
    selectedRow,
    onSelectionChange,
    onFilesChange,
    onAddNewFile,
    removeSelectedFile,
    setFileDateTo,
    isNewFile: (id: string) => newFileIdsRef.current.has(id),
  };
};
