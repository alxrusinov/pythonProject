import {
  ImpOrgPassport,
  useImpOrgPassportsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { FILTER_TYPE_NAME_KONTRAGENT } from '../lib/constants';
import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchClientsProps = {
  restoredClient: ImpOrgPassport | null;
};

export const useImpOrgPassportsApi = ({
  restoredClient,
}: useSearchClientsProps) => {
  const [search, setSearch] = useState('');
  const [fetchClients, { data }] = useImpOrgPassportsLazyQuery();

  const handleChangeClientsSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchClients({
        variables: {
          where: {
            and: [
              { lastRec: { eq: true } },
              { name: { icontains: q } },
              {
                or: [{ typeName: { icontains: FILTER_TYPE_NAME_KONTRAGENT } }],
              },
            ],
          },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchClients],
  );

  const clients = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.impOrgPassports?.items ?? [])
      : [];

    return restoredClient
      ? compareRecords(items, restoredClient)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredClient, search]);

  return {
    handleChangeClientsSearch,
    clients,
  };
};
