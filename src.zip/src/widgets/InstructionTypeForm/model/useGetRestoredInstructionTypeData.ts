import { useInstructionTypeByIdQuery } from 'graphql/generated/generated';
import { useMemo } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';

import { getStableRequestDate } from 'shared/utils/date';

import { InstructionTypeParams } from '../lib/types';

export const useGetRestoredInstructionTypeData = () => {
  const { masterId } = useParams<InstructionTypeParams>();
  const [searchParams] = useSearchParams();

  const copyFrom = searchParams.get('copyFrom');
  const instructionTypeId = masterId ?? copyFrom ?? null;
  const shouldSkip = !instructionTypeId;

  const { requestDateIso, hasRequestDateInUrl } = useMemo(() => {
    const requestDateParam = searchParams.get('requestDate');
    if (requestDateParam) {
      const ts = Number(requestDateParam);
      if (!Number.isNaN(ts)) {
        return {
          requestDateIso: new Date(ts).toISOString(),
          hasRequestDateInUrl: true,
        };
      }
    }
    return {
      requestDateIso: getStableRequestDate(),
      hasRequestDateInUrl: false,
    };
  }, [searchParams, instructionTypeId]);

  const where = useMemo(() => {
    if (!instructionTypeId) return undefined;
    if (hasRequestDateInUrl) {
      return {
        id: { eq: instructionTypeId },
      };
    }
    return {
      and: [{ id: { eq: instructionTypeId } }, { lastRec: { eq: true } }],
    };
  }, [instructionTypeId, hasRequestDateInUrl]);

  const { data, loading } = useInstructionTypeByIdQuery({
    variables: shouldSkip
      ? undefined
      : {
          where,
          requestDate: requestDateIso,
        },
    skip: shouldSkip,
    fetchPolicy: 'network-only',
    nextFetchPolicy: 'network-only',
  });

  const restoredInstructionTypeData =
    data?.ircInstructionTypes?.items?.[0] || null;

  const isExpiredInstructionType = useMemo(() => {
    const dateTo = restoredInstructionTypeData?.dateTo;
    if (!dateTo) return false;

    const dateToMs = new Date(dateTo).getTime();
    if (Number.isNaN(dateToMs)) return false;

    return dateToMs < Date.now();
  }, [restoredInstructionTypeData?.dateTo]);

  const disabled =
    restoredInstructionTypeData != null &&
    (restoredInstructionTypeData.lastRec === false || isExpiredInstructionType);

  return {
    restoredInstructionTypeData,
    loading,
    disabled,
  };
};
