import {
  UserInfosQuery,
  useUserInfosLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type UserInfoItem = NonNullable<
  NonNullable<UserInfosQuery['userInfos']>['items']
>[number];

export type SignatoryOption = NonNullable<UserInfoItem> & {
  signatoryLabel: string;
};

type UseUserInfosApiProps = {
  restoredSignatory: (UserInfoItem & { id?: string | null }) | null;
};

const buildSignatoryLabel = (user: UserInfoItem | null): string =>
  user ? user.fullName?.trim() || user.email?.trim() || '' : '';

const toSignatoryOption = (user: UserInfoItem): SignatoryOption => ({
  ...user,
  signatoryLabel: buildSignatoryLabel(user),
});

export const useUserInfosApi = ({
  restoredSignatory,
}: UseUserInfosApiProps) => {
  const [search, setSearch] = useState('');

  const [fetchUsers, { data }] = useUserInfosLazyQuery();

  const handleChangeSignatoriesSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchUsers({
        variables: {
          where: {
            fullName: { icontains: q },
          },
        },
      });
    },
    [fetchUsers],
  );

  const signatoryOptions = useMemo(() => {
    const fromApi = canFetchLookup(search)
      ? (data?.userInfos?.items ?? []).map(toSignatoryOption)
      : [];

    let list: SignatoryOption[];
    if (!restoredSignatory?.id) {
      list = fromApi;
    } else {
      const restoredId = restoredSignatory.id;
      const alreadyInList = fromApi.some(
        o => o.id != null && o.id === restoredId,
      );
      if (!alreadyInList) {
        fromApi.unshift(toSignatoryOption(restoredSignatory as UserInfoItem));
      }
      list = fromApi;
    }
    return [...list, { id: null, signatoryLabel: '' } as SignatoryOption];
  }, [data, restoredSignatory, search]);

  return {
    signatoryOptions,
    handleChangeSignatoriesSearch,
  };
};
