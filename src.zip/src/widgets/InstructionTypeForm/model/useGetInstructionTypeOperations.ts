import { useInstructionTypeOperationsByIdLazyQuery } from 'graphql/generated/generated';
import { useCallback, useEffect, useMemo } from 'react';
import { useParams } from 'react-router-dom';

import { InstructionTypeParams } from '../lib/types';

export const useGetInstructionTypeOperations = (enabled = true) => {
  const { masterId } = useParams<InstructionTypeParams>();

  const [fetchOperations, { data, loading }] =
    useInstructionTypeOperationsByIdLazyQuery();

  const loadOperations = useCallback(() => {
    if (!masterId) return;

    fetchOperations({
      variables: { id: masterId },
      fetchPolicy: 'network-only',
    });
  }, [fetchOperations, masterId]);

  useEffect(() => {
    if (enabled && masterId) {
      loadOperations();
    }
  }, [enabled, masterId, loadOperations]);

  const operations = useMemo(() => {
    const items = data?.ircInstructionTypes?.items || [];
    return [...items].sort((a, b) => {
      const dateA = a?.dateFrom ? new Date(a.dateFrom).getTime() : 0;
      const dateB = b?.dateFrom ? new Date(b.dateFrom).getTime() : 0;
      return dateA - dateB;
    });
  }, [data]);

  return {
    operations,
    loading,
    refetch: loadOperations,
  };
};
