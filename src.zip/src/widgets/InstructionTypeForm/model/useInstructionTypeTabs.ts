import { useEffect, useState } from 'react';
import { UseFormReturn } from 'react-hook-form';

import { useInstructionTypeFormTabMenuStore } from 'features/InstructionTypeFormTabMenu';

import { TabMenuElements } from 'shared/types/common';
import { countErrors } from 'shared/utils/countErrors';

import {
  CREATE_INSTRUCTION_TYPE_FORM_NAMES,
  CREATE_INSTRUCTION_TYPE_FORM_STEPS,
  EDIT_INSTRUCTION_TYPE_FORM_STEPS,
} from '../lib/constants';
import { getInputInstructionTypeDataTabFieldName } from '../lib/getFormFields';
import { CreateInstructionTypeFormValues } from '../lib/types';

export const useInstructionTypeTabs = (
  methods: UseFormReturn<CreateInstructionTypeFormValues>,
  masterId: string | null,
  disabled = false,
) => {
  const {
    trigger,
    formState: { errors },
  } = methods;

  const ACTUAL_TAB_STEPS = masterId
    ? EDIT_INSTRUCTION_TYPE_FORM_STEPS
    : CREATE_INSTRUCTION_TYPE_FORM_STEPS;

  const initialTab = ACTUAL_TAB_STEPS[0].value;

  const [tabSteps, setTabSteps] = useState(ACTUAL_TAB_STEPS);

  const setActiveTab = useInstructionTypeFormTabMenuStore(
    state => state.setActiveTab,
  );

  const inputInstructionTypeDataTabErrorsAmount = countErrors(
    errors?.inputInstructionTypeDataTab,
  );

  const activeTab =
    useInstructionTypeFormTabMenuStore(state => state.activeTab) ?? initialTab;

  useEffect(() => {
    const steps = masterId
      ? EDIT_INSTRUCTION_TYPE_FORM_STEPS
      : CREATE_INSTRUCTION_TYPE_FORM_STEPS;
    setTabSteps(steps);
    const validStepValues = steps.map(step => step.value);
    const firstTab = steps[0].value;
    if (!activeTab || !validStepValues.includes(activeTab)) {
      setActiveTab(firstTab);
    }
  }, [masterId, activeTab, setActiveTab]);

  useEffect(() => {
    return () => {
      setActiveTab(CREATE_INSTRUCTION_TYPE_FORM_STEPS[0].value);
    };
  }, [setActiveTab]);

  useEffect(() => {
    setTabSteps(prev =>
      prev.map(step => {
        if (step.value === ACTUAL_TAB_STEPS[0].value) {
          return {
            ...step,
            indicator:
              inputInstructionTypeDataTabErrorsAmount !== 0
                ? String(inputInstructionTypeDataTabErrorsAmount)
                : undefined,
          } satisfies TabMenuElements;
        }

        return step;
      }),
    );
  }, [inputInstructionTypeDataTabErrorsAmount]);

  const handleTabValidate = async () => {
    if (disabled) return;

    if (activeTab === ACTUAL_TAB_STEPS[0].value) {
      const valid = await trigger(
        getInputInstructionTypeDataTabFieldName(
          CREATE_INSTRUCTION_TYPE_FORM_NAMES.NAME,
        ),
      );
      if (!valid) return false;
    }
  };

  return { tabSteps, activeTab, handleTabValidate };
};
