import { useState } from 'react';
import { FormProvider } from 'react-hook-form';
import { useParams } from 'react-router-dom';

import { InstructionTypeFormTabMenu } from 'features/InstructionTypeFormTabMenu';

import { InstructionTypeFormFooter } from 'shared/ui/InstructionTypeFormFooter';
import { InstructionTypeFormHeader } from 'shared/ui/InstructionTypeFormHeader';
import { TabPanel } from 'shared/ui/TabPanel';

import {
  CREATE_INSTRUCTION_TYPE_FORM_NAMES,
  CREATE_INSTRUCTION_TYPE_FORM_STEPS,
  EDIT_INSTRUCTION_TYPE_FORM_STEPS,
} from '../lib/constants';
import { getInputInstructionTypeDataTabFieldName } from '../lib/getFormFields';
import { StepValue } from '../lib/types';
import {
  RestoredInstructionTypeProvider,
  useRestoredInstructionTypeContext,
} from '../model/RestoredInstructionTypeContext';
import { useBackAction } from '../model/useBackAction';
import { useCreateInstructionType } from '../model/useCreateInstructionType';
import { HistoryOperationsInstructionTypeTab } from './HistoryOperationsInstructionTypeTab';
import { InputInstructionTypeDataTab } from './InputInstructionTypeDataTab';
import { InstructionTypeClosingModal } from './InputInstructionTypeDataTab/InstructionTypeClosingModal';
import { InstructionTypePeriodModal } from './InputInstructionTypeDataTab/InstructionTypePeriodModal';

const InstructionTypeFormContent = () => {
  const { disabled, restoredInstructionTypeData } =
    useRestoredInstructionTypeContext();

  const {
    methods,
    handleTabValidate,
    activeTab,
    saveForm,
    registerForm,
    tabSteps,
    closeInstructionTypeWithDateTo,
    fileNameAlgorithms,
    fileFormats,
    fileTemplates,
    fileSourceTypes,
  } = useCreateInstructionType({ disabled });

  const [closingModalVisible, setClosingModalVisible] = useState(false);
  const [savePeriodModalVisible, setSavePeriodModalVisible] = useState(false);
  const handleBack = useBackAction();

  const instructionTypeName = restoredInstructionTypeData?.name || '';
  const { masterId } = useParams();

  const handleOpenClosingModal = () => {
    setClosingModalVisible(true);
  };

  const handleCloseConfirm = async (dateTo: string | null) => {
    try {
      await closeInstructionTypeWithDateTo(dateTo);
      setClosingModalVisible(false);
    } catch {
      setClosingModalVisible(false);
    }
  };

  const handleSaveClick = () => {
    setSavePeriodModalVisible(true);
  };

  const handleSavePeriodConfirm = (dateFrom: string | null) => {
    methods.setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_FROM,
      ),
      dateFrom,
    );
    setSavePeriodModalVisible(false);
    if (masterId) {
      saveForm();
    } else {
      registerForm();
    }
  };

  const isSaveDisabled = disabled || (!!masterId && !methods.formState.isDirty);
  const saveButtonLabel = masterId ? 'Сохранить' : 'Создать';
  const canDelete = restoredInstructionTypeData?.lastRec === true;

  return (
    <>
      <FormProvider {...methods}>
        <InstructionTypeFormHeader
          onBack={handleBack}
          instructionTypeName={instructionTypeName}
        >
          <InstructionTypeFormTabMenu
            elements={tabSteps}
            initialTab={CREATE_INSTRUCTION_TYPE_FORM_STEPS[0].value}
            onChooseCb={handleTabValidate}
          />
        </InstructionTypeFormHeader>

        <TabPanel<StepValue>
          step={CREATE_INSTRUCTION_TYPE_FORM_STEPS[0].value}
          activeStep={activeTab}
        >
          <InputInstructionTypeDataTab
            disabled={disabled}
            fileNameAlgorithms={fileNameAlgorithms}
            fileFormats={fileFormats}
            fileTemplates={fileTemplates}
            fileSourceTypes={fileSourceTypes}
          />
        </TabPanel>
        {masterId && (
          <TabPanel<StepValue>
            step={EDIT_INSTRUCTION_TYPE_FORM_STEPS[1].value}
            activeStep={activeTab}
          >
            {activeTab === EDIT_INSTRUCTION_TYPE_FORM_STEPS[1].value && (
              <HistoryOperationsInstructionTypeTab />
            )}
          </TabPanel>
        )}
      </FormProvider>

      <InstructionTypeFormFooter
        onSave={handleSaveClick}
        onCancel={handleBack}
        onDelete={canDelete ? handleOpenClosingModal : undefined}
        hasButtons={!disabled}
        saveDisabled={isSaveDisabled}
        saveButtonLabel={saveButtonLabel}
      />

      <InstructionTypePeriodModal
        visible={savePeriodModalVisible}
        onClose={() => setSavePeriodModalVisible(false)}
        dateFrom={methods.getValues(
          getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_FROM,
          ),
        )}
        onConfirm={handleSavePeriodConfirm}
      />

      <InstructionTypeClosingModal
        visible={closingModalVisible}
        onClose={() => setClosingModalVisible(false)}
        dateFrom={methods.getValues(
          getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_FROM,
          ),
        )}
        dateTo={methods.getValues(
          getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_TO,
          ),
        )}
        onConfirm={handleCloseConfirm}
      />
    </>
  );
};

export const InstructionTypeForm = () => (
  <RestoredInstructionTypeProvider>
    <InstructionTypeFormContent />
  </RestoredInstructionTypeProvider>
);
