import {
  IrcFileFormat,
  IrcFileNameAlgorithm,
  IrcFileSourceType,
  IrcTemplate,
} from 'graphql/generated/generated';
import { useEffect } from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { useParams } from 'react-router-dom';

import { Box, InputText, Select, TextArea } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';
import { formatDateWithTime } from 'shared_ui/utils';

import { useImpOrgPassportsApi } from 'widgets/InstructionTypeForm/model/useImpOrgPassportsApi';
import { useNsiCountriesFromApi } from 'widgets/InstructionTypeForm/model/useNsiCountriesFromApi';
import { useNsiCountriesToApi } from 'widgets/InstructionTypeForm/model/useNsiCountriesToApi';
import { useOrganizationsAdrsApi } from 'widgets/InstructionTypeForm/model/useOrganizationsAdrsApi';
import { useOrganizationsApi } from 'widgets/InstructionTypeForm/model/useOrganizationsApi';
import { useUserInfosApi } from 'widgets/InstructionTypeForm/model/useUserInfosApi';

import { FormField } from 'shared/ui/FormField';

import { CREATE_INSTRUCTION_TYPE_FORM_NAMES } from '../../lib/constants';
import { getInputInstructionTypeDataTabFieldName } from '../../lib/getFormFields';
import { CreateInstructionTypeFormValues } from '../../lib/types';
import { useInputInstructionTypeDataTab } from '../../model/useInputInstructionTypeDataTab';
import { useRestoreIdentificationData } from '../../model/useRestoreIdentificationData';
import { SignatorySignatureField } from './Fields/SignatorySignatureField';
import { InstrucrionTypeFilesTable } from './InstrucrionTypeFilesTable';

const DEFAULT_DATE_TO_DISPLAY = '01.01.3000';

/** Отображаемое значение «Действует с»: null/пусто → «С текущей даты» */
const formatDateFromDisplay = (dateFrom: string | null | undefined): string => {
  if (dateFrom == null || dateFrom === '') return 'С текущей даты';
  return formatDateWithTime(dateFrom) || 'С текущей даты';
};

/** Отображаемое значение «Действует по» */
const formatDateToDisplay = (
  dateTo: string | null | undefined,
  isNewType: boolean,
): string => {
  if (isNewType && (dateTo == null || dateTo === ''))
    return DEFAULT_DATE_TO_DISPLAY;
  if (dateTo == null || dateTo === '') return 'Не указано';
  return formatDateWithTime(dateTo) || 'Не указано';
};

type InputInstructionTypeDataTabProps = {
  /** Блокировка всех полей (например, при lastRec=false — версия только для просмотра) */
  disabled?: boolean;
  fileNameAlgorithms: IrcFileNameAlgorithm[];
  fileFormats: IrcFileFormat[];
  fileTemplates: IrcTemplate[];
  fileSourceTypes: IrcFileSourceType[];
};

export const InputInstructionTypeDataTab = ({
  disabled: fieldsDisabled = false,
  fileNameAlgorithms,
  fileFormats,
  fileTemplates,
  fileSourceTypes,
}: InputInstructionTypeDataTabProps) => {
  const { control, formState, register, getValues, watch, setValue } =
    useFormContext<CreateInstructionTypeFormValues>();
  const { masterId } = useParams<{ masterId?: string }>();
  const isNewType = !masterId;

  const { restoredInstructionTypeData } = useRestoreIdentificationData();

  const restoredFileIds = watch(
    getInputInstructionTypeDataTabFieldName(
      CREATE_INSTRUCTION_TYPE_FORM_NAMES.CUSTOM_RESTORED_FILES_IDS,
    ),
  );

  const {
    handleCountryFromChange,
    handleCountryToChange,
    handleClientChange,
    handleOrganizationChange,
    handleOrganizationAdrChange,
    handleSignatoryChange,
    handleChangeFiles,
    handleSignatureChange,
  } = useInputInstructionTypeDataTab();

  const { signatoryOptions, handleChangeSignatoriesSearch } = useUserInfosApi({
    restoredSignatory: restoredInstructionTypeData?.respPrepare ?? null,
  });

  const { clients, handleChangeClientsSearch } = useImpOrgPassportsApi({
    restoredClient: restoredInstructionTypeData?.client || null,
  });
  const { countriesTo, handleChangeCountriesToSearch } = useNsiCountriesToApi({
    restoredCountryTo: restoredInstructionTypeData?.countryTo || null,
  });
  const { countriesFrom, handleChangeCountriesFromSearch } =
    useNsiCountriesFromApi({
      restoredCountryFrom: restoredInstructionTypeData?.countryFrom || null,
    });
  const { organizations, handleChangeOrganizationsSearch } =
    useOrganizationsApi({
      restoredOrganization: restoredInstructionTypeData?.organization || null,
    });
  const selectedOrganization = watch(
    getInputInstructionTypeDataTabFieldName(
      CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION,
    ),
  );
  const selectedOrganizationAddress = watch(
    getInputInstructionTypeDataTabFieldName(
      CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS,
    ),
  );

  const {
    organizationsAdrs,
    organizationsAdrsBackendCount,
    organizationsAdrsLoading,
  } = useOrganizationsAdrsApi({
    organization: selectedOrganization,
    restoredOrganizationAdrs: restoredInstructionTypeData?.orgAddress || null,
  });

  useEffect(() => {
    if (
      !selectedOrganization ||
      selectedOrganizationAddress ||
      organizationsAdrsLoading ||
      organizationsAdrsBackendCount !== 1
    )
      return;

    const [singleAddress] = organizationsAdrs;
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS,
      ),
      singleAddress,
      { shouldDirty: false },
    );
    setValue(
      getInputInstructionTypeDataTabFieldName(
        CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS_ID,
      ),
      singleAddress?.id ?? null,
      { shouldDirty: false },
    );
  }, [
    selectedOrganization,
    selectedOrganizationAddress,
    organizationsAdrs,
    organizationsAdrsBackendCount,
    organizationsAdrsLoading,
    setValue,
  ]);

  return (
    <Box className="flex flex-column gap-2 flex-grow-1 max-w-full overflow-auto">
      <FormField
        label="Тип инструкции"
        errorMessage={
          formState.errors?.inputInstructionTypeDataTab?.[
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.NAME
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.NAME,
          )}
          control={control}
          rules={{ required: 'Название типа инструкции обязательно' }}
          render={() => (
            <InputText
              placeholder="Название типа инструкции"
              disabled={fieldsDisabled}
              {...register(
                getInputInstructionTypeDataTabFieldName(
                  CREATE_INSTRUCTION_TYPE_FORM_NAMES.NAME,
                ),
              )}
            />
          )}
        />
      </FormField>

      <FormField
        label="Страна отправления"
        errorMessage={
          formState.errors?.inputInstructionTypeDataTab?.[
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM,
          )}
          control={control}
          rules={{ required: 'Страна отправления обязательна' }}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Выберите страну отправления"
              value={field.value}
              options={countriesFrom}
              onChange={(e: DropdownChangeEvent) =>
                handleCountryFromChange(e, field.onChange)
              }
              onFilter={(e: DropdownFilterEvent) => {
                handleChangeCountriesFromSearch(e.filter);
              }}
              appendTo="self"
              optionLabel="name"
              dataKey="id"
              filter
              showClear
              disabled={fieldsDisabled}
            />
          )}
        />
      </FormField>
      <FormField
        label="Страна назначения"
        errorMessage={
          formState.errors?.inputInstructionTypeDataTab?.[
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO,
          )}
          control={control}
          rules={{ required: 'Страна назначения обязательна' }}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Выберите страну назначения"
              value={field.value}
              options={countriesTo}
              onChange={(e: DropdownChangeEvent) =>
                handleCountryToChange(e, field.onChange)
              }
              onFilter={(e: DropdownFilterEvent) => {
                handleChangeCountriesToSearch(e.filter);
              }}
              optionLabel="name"
              dataKey="id"
              filter
              showClear
              disabled={fieldsDisabled}
            />
          )}
        />
      </FormField>
      <FormField
        label="Клиент"
        errorMessage={
          formState.errors?.inputInstructionTypeDataTab?.[
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT,
          )}
          control={control}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Выберите клиента"
              value={field.value}
              options={clients}
              onChange={(e: DropdownChangeEvent) =>
                handleClientChange(e, field.onChange)
              }
              onFilter={(e: DropdownFilterEvent) => {
                handleChangeClientsSearch(e.filter);
              }}
              optionLabel="name"
              dataKey="id"
              filter
              showClear
              disabled={fieldsDisabled}
            />
          )}
        />
      </FormField>
      <FormField label="Действует с">
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_FROM,
          )}
          control={control}
          render={({ field }) => (
            <div
              className="p-inputtext p-component p-inputfield w-full"
              style={{
                minHeight: 40,
                display: 'flex',
                alignItems: 'center',
                opacity: 1,
                cursor: 'default',
              }}
              aria-readonly
            >
              {formatDateFromDisplay(field.value)}
            </div>
          )}
        />
      </FormField>
      <FormField label="Действует по">
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_TO,
          )}
          control={control}
          render={({ field }) => (
            <div
              className="p-inputtext p-component p-inputfield w-full"
              style={{
                minHeight: 40,
                display: 'flex',
                alignItems: 'center',
                opacity: 1,
                cursor: 'default',
              }}
              aria-readonly
            >
              {formatDateToDisplay(field.value, isNewType)}
            </div>
          )}
        />
      </FormField>
      <FormField
        label="Организация отправителя"
        errorMessage={
          formState.errors?.inputInstructionTypeDataTab?.[
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION
          ]?.message as string
        }
      >
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION,
          )}
          control={control}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Выберите организацию"
              value={field.value}
              options={organizations}
              onChange={(e: DropdownChangeEvent) =>
                handleOrganizationChange(e, field.onChange)
              }
              onFilter={(e: DropdownFilterEvent) => {
                handleChangeOrganizationsSearch(e.filter);
              }}
              optionLabel="name"
              dataKey="id"
              filter
              showClear
              disabled={fieldsDisabled}
            />
          )}
        />
      </FormField>
      <FormField
        label="Адрес организации отправителя"
        errorMessage={
          formState.errors?.inputInstructionTypeDataTab?.[
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS
          ]?.message as string
        }
      >
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS,
          )}
          control={control}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Выберите адрес организации"
              value={field.value}
              options={organizationsAdrs}
              onChange={(e: DropdownChangeEvent) =>
                handleOrganizationAdrChange(e, field.onChange)
              }
              disabled={
                fieldsDisabled ||
                !getValues(
                  getInputInstructionTypeDataTabFieldName(
                    CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION,
                  ),
                )
              }
              optionLabel="addressSelectLabel"
              dataKey="id"
              showClear
            />
          )}
        />
      </FormField>
      <FormField
        label="Подписант"
        errorMessage={
          formState.errors?.inputInstructionTypeDataTab?.[
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_ID
          ]?.message as string
        }
      >
        <Controller
          name={getInputInstructionTypeDataTabFieldName(
            CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_ID,
          )}
          control={control}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Выберите подписанта"
              value={
                signatoryOptions.find(
                  user => user.id != null && user.id === field.value,
                ) ?? null
              }
              options={signatoryOptions}
              onChange={(e: DropdownChangeEvent) =>
                handleSignatoryChange(e.value?.id ?? null, field.onChange)
              }
              onFilter={(e: DropdownFilterEvent) => {
                handleChangeSignatoriesSearch(e.filter ?? '');
              }}
              optionLabel="signatoryLabel"
              dataKey="id"
              filter
              showClear
              disabled={fieldsDisabled}
            />
          )}
        />
      </FormField>

      <FormField label="Должность подписанта">
        <InputText
          placeholder="Должность подписанта"
          disabled={fieldsDisabled}
          {...register(
            getInputInstructionTypeDataTabFieldName(
              CREATE_INSTRUCTION_TYPE_FORM_NAMES.MANUAL_RESP_PREP_POSITION,
            ),
          )}
        />
      </FormField>

      <SignatorySignatureField
        disabled={fieldsDisabled}
        onSignatureChange={handleSignatureChange}
      />
      <FormField label="Комментарий">
        <TextArea
          placeholder="Комментарий"
          disabled={fieldsDisabled}
          {...register(
            getInputInstructionTypeDataTabFieldName(
              CREATE_INSTRUCTION_TYPE_FORM_NAMES.COMMENT_TYPE,
            ),
          )}
          autoResize
        />
      </FormField>
      <Controller
        name={getInputInstructionTypeDataTabFieldName(
          CREATE_INSTRUCTION_TYPE_FORM_NAMES.CREATE_TYPE_FILES,
        )}
        control={control}
        render={({ field }) => (
          <InstrucrionTypeFilesTable
            files={field.value || null}
            fileNameAlgorithms={fileNameAlgorithms}
            templates={fileTemplates}
            fileSourceTypes={fileSourceTypes}
            fileFormats={fileFormats}
            restoredFileIds={restoredFileIds ?? []}
            onFilesChangeForForm={handleChangeFiles}
            handleAddFile={() => {}}
            handleChangeFile={() => {}}
            handleDeleteFile={() => {}}
            disabled={fieldsDisabled}
          />
        )}
      />
    </Box>
  );
};
