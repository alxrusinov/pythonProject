import { FC, useEffect, useState } from 'react';

import { Button, DatePicker } from 'shared_ui/components';
import { CalendarChangeEvent } from 'shared_ui/primereact';

import { FormField } from 'shared/ui/FormField';
import { Modal } from 'shared/ui/Modal';

import { parseDate, toISOString } from '../../lib/dateUtils';

export type InstructionTypeFileClosingModalProps = {
  visible: boolean;
  onClose: () => void;
  /** Текущее значение «Действует по» файла */
  dateTo: string | null | undefined;
  /** При подтверждении: null = «По текущую дату» */
  onConfirm: (dateTo: string | null) => void;
};

export const InstructionTypeFileClosingModal: FC<
  InstructionTypeFileClosingModalProps
> = ({ visible, onClose, dateTo: initialDateTo, onConfirm }) => {
  const [useCurrentDate, _] = useState(true);
  const [localDateTo, setLocalDateTo] = useState<Date | null>(null);

  useEffect(() => {
    if (!visible) return;
    setLocalDateTo(parseDate(initialDateTo));
  }, [visible, initialDateTo]);

  useEffect(() => {
    if (!visible) return;
    if (useCurrentDate) {
      setLocalDateTo(new Date());
    }
  }, [visible, useCurrentDate]);

  const handleConfirm = () => {
    if (useCurrentDate) {
      onConfirm(null);
    } else {
      onConfirm(toISOString(localDateTo) || null);
    }
    onClose();
  };

  const now = new Date();
  const minDate = new Date(now.getTime() + 60 * 1000);

  return (
    <Modal
      visible={visible}
      title="Дата окончания действия файла"
      onClose={onClose}
    >
      <div className="flex flex-column gap-3">
        {/* <div className="flex flex-row align-items-center gap-2">
          <Label className="mb-0" label="По умолчанию" />
          <Switch
            size="medium"
            checked={useCurrentDate}
            onChange={e => setUseCurrentDate(!!e?.value)}
          />
        </div> */}

        <FormField label="Действует по">
          {useCurrentDate ? (
            <div
              className="p-inputtext p-component p-inputfield w-full"
              style={{ minHeight: 40, display: 'flex', alignItems: 'center' }}
            >
              По текущую дату
            </div>
          ) : (
            <DatePicker
              panelClassName="md:min-w-min"
              size="large"
              selectionMode="single"
              value={localDateTo}
              onChange={(e: CalendarChangeEvent) => {
                if (e.target?.value && !Array.isArray(e.target.value)) {
                  setLocalDateTo(e.target.value as Date);
                }
              }}
              dateFormat="dd.mm.yy"
              showTime
              footerTemplate={() => null}
              minDate={minDate}
              className="w-full"
            />
          )}
        </FormField>

        <div className="flex flex-row justify-content-between gap-2 mt-2 mb-2">
          <Button size="medium" variant="danger" onClick={onClose}>
            Отменить
          </Button>
          <Button
            size="medium"
            variant="primary"
            onClick={handleConfirm}
            disabled={!useCurrentDate && !localDateTo}
          >
            Подтвердить
          </Button>
        </div>
      </div>
    </Modal>
  );
};
