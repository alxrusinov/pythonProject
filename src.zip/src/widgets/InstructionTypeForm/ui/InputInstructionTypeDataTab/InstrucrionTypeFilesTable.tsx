import { IrcFileNameAlgorithm } from 'graphql/generated/generated';
import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';

import {
  Box,
  Button,
  Column,
  DatePicker,
  InputText,
  Select,
  Tooltip,
} from 'shared_ui/components';
import { DataTable, DropdownChangeEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES } from 'widgets/InstructionTypeForm/lib/constants';
import { InstrucrionTypeFilesTableProps } from 'widgets/InstructionTypeForm/lib/types';
import { useInstructionTypeFilesControls } from 'widgets/InstructionTypeForm/model/useInstructionTypeFilesControls';
import { InstructionTypeFileClosingModal } from 'widgets/InstructionTypeForm/ui/InputInstructionTypeDataTab/InstructionTypeFileClosingModal';

import { matchById } from 'shared/utils/array';
import { parseDateSafe } from 'shared/utils/date';

type FileRow = {
  dateFrom?: string | null;
  dateTo?: string | null;
  notReadOnly?: boolean;
};

const parseRequestDateFromUrl = (value: string | null): Date | null => {
  if (!value) return null;

  const parsedByDefaultParser = parseDateSafe(value);
  if (parsedByDefaultParser) return parsedByDefaultParser;

  if (!/^\d+$/.test(value)) return null;

  const timestamp = Number(value);
  if (Number.isNaN(timestamp)) return null;

  const parsedByTimestamp = new Date(
    value.length <= 10 ? timestamp * 1000 : timestamp,
  );
  return Number.isNaN(parsedByTimestamp.getTime()) ? null : parsedByTimestamp;
};

const getFileStatus = (row: FileRow, compareDate: Date): string => {
  const compareDateTimestamp = compareDate.getTime();
  const dateTo = parseDateSafe(row.dateTo)?.getTime();
  const dateFrom = parseDateSafe(row.dateFrom)?.getTime();
  // null/пусто «Действует по» = «По текущую дату» → неактивно
  if (
    row.dateTo == null ||
    row.dateTo === '' ||
    (dateTo != null && dateTo <= compareDateTimestamp)
  )
    return 'Неактивно';
  if (dateFrom != null && dateFrom > compareDateTimestamp)
    return 'Активно в будущем';
  return 'Активно';
};

const renderAlgorithmLabel = (
  option: IrcFileNameAlgorithm,
  rowId: string | null | undefined,
  mode: 'item' | 'value',
) => {
  const algoId = option.id;
  if (algoId == null) {
    return <span>{option.name}</span>;
  }
  const tipKey = `fn-algo-${mode}-${String(rowId ?? 'new')}-${algoId}`;
  const hasTip = Boolean(
    (option.format && option.format.trim() !== '') ||
      (option.example && option.example.trim() !== ''),
  );
  return (
    <span className="flex align-items-center gap-1">
      <span>{option.name}</span>
      {hasTip && (
        <>
          <Tooltip
            target={`[data-tooltip="${tipKey}"]`}
            variant="titleAndText"
            title={option.format?.trim() || 'Описание'}
            text={
              option.example?.trim()
                ? `Пример: ${option.example.trim()}`
                : undefined
            }
          />
          <span
            data-tooltip={tipKey}
            className="cursor-pointer font-bold border-circle inline-flex align-items-center justify-content-center"
            aria-label="Подсказка по алгоритму"
            style={{
              width: 16,
              height: 16,
              border: '1px solid currentColor',
              lineHeight: 1,
              fontSize: 12,
            }}
          >
            ?
          </span>
        </>
      )}
    </span>
  );
};

export const InstrucrionTypeFilesTable = ({
  files,
  fileNameAlgorithms,
  fileSourceTypes,
  fileFormats,
  templates,
  onFilesChangeForForm,
  restoredFileIds,
  disabled: fieldsDisabled = false,
}: InstrucrionTypeFilesTableProps) => {
  const [searchParams] = useSearchParams();
  const requestDateFromUrl = parseRequestDateFromUrl(
    searchParams.get('requestDate'),
  );
  const compareDate = requestDateFromUrl ?? new Date();

  const defaultFileNameAlgoId = fileNameAlgorithms[0]?.id ?? 0;

  const {
    currentFiles,
    selectedRow,
    onSelectionChange,
    onFilesChange,
    onAddNewFile,
    removeSelectedFile,
    setFileDateTo,
    isNewFile,
  } = useInstructionTypeFilesControls({
    files,
    onFilesChangeForForm,
    restoredFileIds,
    defaultFileNameAlgoId,
  });

  const [fileClosingModalFileId, setFileClosingModalFileId] = useState<
    string | null
  >(null);
  const fileForClosingModal = currentFiles.find(
    f => f.id === fileClosingModalFileId,
  );

  return (
    <Box className="flex flex-column gap-2 flex-grow-1 max-w-full">
      <DataTable
        dataKey="id"
        value={currentFiles}
        size="small"
        tableStyle={{ minWidth: '50rem' }}
        emptyMessage="Нет вложений"
        selectionMode="single"
        selection={selectedRow}
        onSelectionChange={onSelectionChange}
        isDataSelectable={event =>
          getFileStatus(event.data as FileRow, compareDate) !== 'Неактивно'
        }
        footer={
          <Box className="flex flex-row gap-2 max-w-full">
            <Button
              variant="primary"
              size="small"
              onClick={onAddNewFile}
              disabled={fieldsDisabled}
            >
              Добавить вложение
            </Button>
            <Button
              variant="danger"
              disabled={
                fieldsDisabled ||
                !selectedRow ||
                getFileStatus(selectedRow as FileRow, compareDate) ===
                  'Неактивно'
              }
              size="small"
              onClick={() => {
                if (!selectedRow?.id) return;
                if (isNewFile(selectedRow.id)) {
                  removeSelectedFile(selectedRow.id);
                } else {
                  setFileClosingModalFileId(selectedRow.id);
                }
              }}
            >
              Удалить вложение
            </Button>
          </Box>
        }
      >
        <Column
          style={{ width: '1%' }}
          selectionMode="single"
          headerStyle={{ width: 40 }}
        />
        <Column
          header="Префикс"
          body={rowData => {
            return (
              <InputText
                placeholder="Префикс"
                value={rowData.prefix ?? ''}
                onChange={e =>
                  onFilesChange(
                    rowData,
                    e.target.value,
                    CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES.FILE_PREFIX,
                  )
                }
                disabled={fieldsDisabled || !rowData.notReadOnly}
              />
            );
          }}
          style={{ width: '14%' }}
        ></Column>
        <Column
          header="Алгоритм"
          body={rowData => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Алгоритм"
              value={matchById(fileNameAlgorithms, rowData.fileNameAlgoId)}
              options={fileNameAlgorithms}
              onChange={(e: DropdownChangeEvent) =>
                onFilesChange(
                  rowData,
                  e.target.value?.id ?? 0,
                  CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES.FILE_NAME_ALGORITHM,
                )
              }
              optionLabel="name"
              dataKey="id"
              disabled={
                fieldsDisabled ||
                !rowData.notReadOnly ||
                fileNameAlgorithms.length === 0
              }
              itemTemplate={opt =>
                opt
                  ? renderAlgorithmLabel(opt, rowData.id as string, 'item')
                  : null
              }
              valueTemplate={opt =>
                opt
                  ? renderAlgorithmLabel(opt, rowData.id as string, 'value')
                  : ''
              }
            />
          )}
          style={{ width: '18%' }}
        />
        <Column
          body={rowData => {
            return (
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                placeholder="Формат"
                value={matchById(fileFormats, rowData.fileFormatId)}
                options={fileFormats}
                onChange={(e: DropdownChangeEvent) =>
                  onFilesChange(
                    rowData,
                    e.target.value?.id,
                    CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES.FILE_FORMAT,
                  )
                }
                optionLabel="name"
                dataKey="id"
                disabled={fieldsDisabled || !rowData.notReadOnly}
              />
            );
          }}
          header="Формат"
          style={{ width: '10%' }}
        ></Column>
        <Column
          body={rowData => {
            return (
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                placeholder="Способ получения"
                value={matchById(fileSourceTypes, rowData.fileSourceTypeId)}
                options={fileSourceTypes}
                onChange={(e: DropdownChangeEvent) =>
                  onFilesChange(
                    rowData,
                    e.target.value?.id,
                    CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES.FILE_SOURCE_TYPE,
                  )
                }
                optionLabel="name"
                dataKey="id"
                disabled={fieldsDisabled || !rowData.notReadOnly}
              />
            );
          }}
          header="Способ получения"
          style={{ width: '15%' }}
        ></Column>
        <Column
          body={rowData => {
            return (
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                disabled={
                  fieldsDisabled ||
                  !rowData.notReadOnly ||
                  (rowData.fileSourceTypeId && rowData.fileSourceTypeId === 2)
                }
                placeholder="Шаблон"
                value={matchById(templates, rowData.templateId)}
                options={templates}
                onChange={(e: DropdownChangeEvent) =>
                  onFilesChange(
                    rowData,
                    e.target.value?.id,
                    CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES.TEMPLATE,
                  )
                }
                optionLabel="name"
                dataKey="id"
              />
            );
          }}
          header="Шаблон"
          style={{ width: '15%' }}
        ></Column>
        <Column
          body={rowData => {
            if (rowData.dateFrom === null) {
              return (
                <div
                  className="p-inputtext p-component p-inputfield w-full "
                  style={{
                    minHeight: 30,
                    display: 'flex',
                    alignItems: 'center',
                    backgroundColor: 'var(--color-gray-10)',
                    borderRadius: '6px',
                    padding: '4px',
                    color: 'var(--color-gray-100)',
                    opacity: 0.6,
                  }}
                >
                  С текущей даты
                </div>
              );
            } else {
              return (
                <DatePicker
                  panelClassName="md:min-w-min"
                  selectionMode="single"
                  value={parseDateSafe(rowData.dateFrom)}
                  onChange={e => {
                    const v = e.target?.value;
                    if (v && !Array.isArray(v)) {
                      onFilesChange(
                        rowData,
                        (v as Date).toISOString(),
                        CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES.DATE_FROM,
                      );
                    }
                  }}
                  dateFormat="dd.mm.yy"
                  showTime
                  size="medium"
                  minDate={new Date()}
                  footerTemplate={() => null}
                  disabled={fieldsDisabled || !rowData.notReadOnly}
                />
              );
            }
          }}
          header="Действует с"
          style={{ width: '10%' }}
        ></Column>
        <Column
          body={rowData => {
            if (rowData.dateTo == null || rowData.dateTo === '') {
              return (
                <div
                  className="p-inputtext p-component p-inputfield w-full "
                  style={{
                    minHeight: 30,
                    display: 'flex',
                    alignItems: 'center',
                    backgroundColor: 'var(--color-gray-10)',
                    borderRadius: '6px',
                    padding: '4px',
                    color: 'var(--color-gray-100)',
                    opacity: 0.6,
                  }}
                >
                  По текущую дату
                </div>
              );
            }
            return (
              <DatePicker
                panelClassName="md:min-w-min"
                selectionMode="single"
                value={parseDateSafe(rowData.dateTo)}
                onChange={e => {
                  const v = e.target?.value;
                  if (v && !Array.isArray(v)) {
                    onFilesChange(
                      rowData,
                      (v as Date).toISOString(),
                      CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES.DATE_TO,
                    );
                  }
                }}
                dateFormat="dd.mm.yy"
                showTime
                size="medium"
                minDate={new Date()}
                footerTemplate={() => null}
                disabled={true}
              />
            );
          }}
          header="Действует по"
          style={{ width: '10%' }}
        ></Column>
        <Column
          header="Статус"
          body={rowData => getFileStatus(rowData, compareDate)}
          style={{ width: '12%' }}
        />
      </DataTable>

      <InstructionTypeFileClosingModal
        visible={fileClosingModalFileId != null}
        onClose={() => setFileClosingModalFileId(null)}
        dateTo={fileForClosingModal?.dateTo}
        onConfirm={dateTo => {
          if (fileClosingModalFileId) {
            setFileDateTo(fileClosingModalFileId, dateTo);
            setFileClosingModalFileId(null);
          }
        }}
      />
    </Box>
  );
};
