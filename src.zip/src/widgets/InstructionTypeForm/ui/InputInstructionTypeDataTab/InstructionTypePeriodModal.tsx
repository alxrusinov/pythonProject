import { FC, useEffect, useState } from 'react';

import { Button, DatePicker } from 'shared_ui/components';
import { CalendarChangeEvent } from 'shared_ui/primereact';

import { FormField } from 'shared/ui/FormField';
import { Modal } from 'shared/ui/Modal';

import { parseDate, toISOString } from '../../lib/dateUtils';

export type InstructionTypePeriodModalProps = {
  visible: boolean;
  onClose: () => void;
  /** Текущее значение «Действует с» в форме (для отображения при открытии) */
  dateFrom: string | null | undefined;
  /** Вызывается при подтверждении: null = «С текущей даты» */
  onConfirm: (dateFrom: string | null) => void;
};

export const InstructionTypePeriodModal: FC<
  InstructionTypePeriodModalProps
> = ({ visible, onClose, dateFrom: initialDateFrom, onConfirm }) => {
  const [fromCurrentDate, setFromCurrentDate] = useState(true);
  const [localDateFrom, setLocalDateFrom] = useState<Date | null>(() => {
    const now = new Date();
    now.setSeconds(0, 0);
    return now;
  });

  useEffect(() => {
    if (!visible) return;
    const parsed = parseDate(initialDateFrom);
    setLocalDateFrom(parsed ?? new Date());
  }, [visible, initialDateFrom]);

  useEffect(() => {
    if (!visible) return;
    if (fromCurrentDate) {
      const now = new Date();
      now.setSeconds(0, 0);
      setLocalDateFrom(now);
    }
  }, [visible, fromCurrentDate]);

  const handleConfirm = () => {
    if (fromCurrentDate) {
      onConfirm(null);
    } else {
      const str = toISOString(localDateFrom);
      onConfirm(str || null);
    }
    onClose();
  };

  const now = new Date();
  const minDate = new Date(now.getTime() + 60 * 1000); // чуть больше текущего момента

  return (
    <Modal
      visible={visible}
      title="Дата начала действия изменения типа инструкции"
      onClose={onClose}
    >
      <div className="flex flex-column gap-3">
        {/* <div className="flex flex-row align-items-center gap-2">
          <Label className="mb-0" label="По умолчанию" />
          <Switch
            size="medium"
            checked={fromCurrentDate}
            onChange={e => setFromCurrentDate(!!e?.value)}
          />
        </div> */}

        <FormField label="Действует с">
          {fromCurrentDate ? (
            <div
              className="p-inputtext p-component p-inputfield w-full"
              style={{ minHeight: 40, display: 'flex', alignItems: 'center' }}
            >
              С текущей даты
            </div>
          ) : (
            <DatePicker
              panelClassName="md:min-w-min"
              size="large"
              selectionMode="single"
              value={localDateFrom}
              onChange={(e: CalendarChangeEvent) => {
                if (e.target?.value && !Array.isArray(e.target.value)) {
                  setLocalDateFrom(e.target.value as Date);
                }
              }}
              dateFormat="dd.mm.yy"
              showTime
              footerTemplate={() => null}
              minDate={minDate}
              className="w-full"
            />
          )}
        </FormField>

        <div className="flex flex-row justify-content-between gap-2 mt-2 mb-2">
          <Button size="medium" variant="danger" onClick={onClose}>
            Отменить
          </Button>
          <Button size="medium" variant="primary" onClick={handleConfirm}>
            Сохранить
          </Button>
        </div>
      </div>
    </Modal>
  );
};
