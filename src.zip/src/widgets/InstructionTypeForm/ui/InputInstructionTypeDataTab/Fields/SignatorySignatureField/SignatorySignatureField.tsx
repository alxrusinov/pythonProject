import { useRef } from 'react';
import { Controller, useFormContext } from 'react-hook-form';

import { Box, Button } from 'shared_ui/components';

import { CREATE_INSTRUCTION_TYPE_FORM_NAMES } from 'widgets/InstructionTypeForm/lib/constants';
import { getInputInstructionTypeDataTabFieldName } from 'widgets/InstructionTypeForm/lib/getFormFields';
import { CreateInstructionTypeFormValues } from 'widgets/InstructionTypeForm/lib/types';

import { FormField } from 'shared/ui/FormField';
import { toBase64 } from 'shared/utils/file';

type SignatorySignatureFieldProps = {
  disabled?: boolean;
  onSignatureChange: (
    file: string | null,
    onChange: (value: string | null) => void,
  ) => void;
};

export const SignatorySignatureField = ({
  disabled = false,
  onSignatureChange,
}: SignatorySignatureFieldProps) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const { control, formState } =
    useFormContext<CreateInstructionTypeFormValues>();

  const handleFileChange = async (
    fileList: FileList | null,
    onChange: (value: string | null) => void,
  ) => {
    if (!fileList?.length) return;
    const base64 = await toBase64(fileList[0]);
    onSignatureChange(base64 as string, onChange);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  return (
    <FormField
      label="Факсимиле подписанта"
      errorMessage={
        formState.errors?.inputInstructionTypeDataTab?.[
          CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_SIGNATURE
        ]?.message as string
      }
    >
      <Controller
        name={getInputInstructionTypeDataTabFieldName(
          CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_SIGNATURE,
        )}
        control={control}
        render={({ field }) => {
          const signatureValue =
            typeof field.value === 'string' && field.value.trim() !== ''
              ? field.value
              : null;
          const signatureDataUrl = signatureValue
            ? signatureValue.startsWith('data:')
              ? signatureValue
              : `data:image/png;base64,${signatureValue}`
            : null;

          if (signatureDataUrl) {
            return (
              <Box className="flex flex-column gap-2 flex-grow-0">
                <div
                  className="flex flex-align-center flex-justify-center p-2"
                  style={{
                    minHeight: 80,
                    maxWidth: 200,
                    border: '1px solid var(--p-border-color)',
                    borderRadius: 'var(--p-border-radius)',
                    backgroundColor: 'var(--p-surface-50)',
                  }}
                >
                  <img
                    src={signatureDataUrl}
                    alt="Факсимиле подписанта"
                    style={{
                      maxHeight: 80,
                      maxWidth: '100%',
                      objectFit: 'contain',
                    }}
                  />
                </div>
                <Box className="flex flex-row gap-2 align-items-center">
                  <Button
                    variant="danger"
                    size="small"
                    disabled={disabled}
                    onClick={() => onSignatureChange('', field.onChange)}
                  >
                    Удалить
                  </Button>
                  <Button
                    variant="primary"
                    size="small"
                    disabled={disabled}
                    onClick={() => inputRef.current?.click()}
                  >
                    Загрузить другой файл
                  </Button>
                  <input
                    ref={inputRef}
                    type="file"
                    accept=".png"
                    className="hidden"
                    disabled={disabled}
                    onChange={e =>
                      handleFileChange(e.target.files, field.onChange)
                    }
                    style={{
                      position: 'absolute',
                      width: 0,
                      height: 0,
                      opacity: 0,
                      overflow: 'hidden',
                    }}
                  />
                </Box>
              </Box>
            );
          }

          return (
            <input
              ref={inputRef}
              type="file"
              accept=".png"
              disabled={disabled}
              onChange={e => handleFileChange(e.target.files, field.onChange)}
            />
          );
        }}
      />
    </FormField>
  );
};
