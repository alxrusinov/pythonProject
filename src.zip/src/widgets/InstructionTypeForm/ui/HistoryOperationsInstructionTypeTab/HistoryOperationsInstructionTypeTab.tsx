import { useParams } from 'react-router-dom';

import { Box, Column } from 'shared_ui/components';
import { DataTable } from 'shared_ui/primereact';
import { formatDateWithTime } from 'shared_ui/utils';

import { useGetInstructionTypeOperations } from '../../model/useGetInstructionTypeOperations';

export const HistoryOperationsInstructionTypeTab = () => {
  const { masterId } = useParams();
  if (!masterId) {
    return null;
  }

  const { operations } = useGetInstructionTypeOperations(true);

  return (
    <Box className="flex flex-column gap-2 flex-grow-1 max-w-full overflow-auto">
      <DataTable
        dataKey="id"
        value={operations}
        size="small"
        tableStyle={{ minWidth: '50rem' }}
        emptyMessage="Нет операций"
        selectionMode="single"
      >
        <Column
          body={rowData => formatDateWithTime(rowData.dateFrom)}
          header="Дата"
          style={{ width: '20%' }}
        ></Column>
        <Column
          header="Пользователь"
          body={rowData => {
            const user = rowData.insertUser;
            if (!user?.shortName) return null;
            return (
              <span title={user.fullName ?? undefined}>{user.shortName}</span>
            );
          }}
          style={{ width: '50%' }}
        ></Column>
        <Column
          header="Описание"
          body={(rowData, { rowIndex }) => {
            if (rowIndex === 0) {
              return 'Создание';
            } else if (rowData.deleteUser) {
              return 'Удаление';
            } else {
              return 'Редактирование';
            }
          }}
          style={{ width: '30%' }}
        ></Column>
      </DataTable>
    </Box>
  );
};
