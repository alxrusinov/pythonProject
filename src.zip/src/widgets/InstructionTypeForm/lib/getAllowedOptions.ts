import { DataType, FileTypesEnum } from 'graphql/generated/generated';

import { dataTypesSelectOptions } from './constants';

const flagMap: Partial<Record<FileTypesEnum, keyof DataType>> = {
  [FileTypesEnum.ExcelFile]: 'isFileLoadable',
  [FileTypesEnum.PreviousCalc]: 'isPreviousCalcSelectable',
  [FileTypesEnum.PeriodSelection]: 'isPeriodSelectable',
};

export const getAllowedOptions = (data: DataType) =>
  dataTypesSelectOptions.filter(opt => {
    const flagKey = flagMap[opt.id];
    return flagKey ? data[flagKey] : true;
  });
