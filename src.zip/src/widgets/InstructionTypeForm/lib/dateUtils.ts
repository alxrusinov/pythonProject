export const parseDate = (value: string | null | undefined): Date | null => {
  if (value == null || value === '') return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
};

export const toISOString = (d: Date | null): string =>
  d ? d.toISOString() : '';
