import { FileTypesEnum } from 'graphql/generated/generated';

import { TabMenuElements } from 'shared/types/common';

import { DataTypesSelectOptions } from './types';

export const CREATE_INSTRUCTION_TYPE_FORM_STEPS: TabMenuElements[] = [
  {
    label: 'Основные реквизиты',
    value: 'inputInstructionTypeDataTab',
  },
];

export const EDIT_INSTRUCTION_TYPE_FORM_STEPS: TabMenuElements[] = [
  {
    label: 'Основные реквизиты',
    value: 'inputInstructionTypeDataTab',
  },
  {
    label: 'История операций',
    value: 'OperationHistory',
  },
];

export const CALCULATION_FORM_NAME = {
  MODEL_TYPE: 'modelType',
  CALC_NAME: 'calcName',
  CALC_TYPE: 'calcType',
  PLAN_PERIOD: 'planPeriod',
  PLAN_HORIZON_DAYS: 'planHorizonDays',
  PUBLICATION_DATE: 'publicationDate',
  ON_PUBLICATION_DATE: 'onPublicationDate',
  DATE_VERSION: 'dateVersion',
  ON_DATE_VERSION: 'onDateVersion',
  COMMENT: 'comment',

  INPUT_DATA_TYPES: 'inputDataTypes',
  PREVIOUS_CALCULATIONS: 'previousCalculations',
} as const;

export const CREATE_INSTRUCTION_TYPE_FORM_NAMES = {
  ID: 'id',
  NAME: 'name',
  CLIENT_ID: 'clientId',
  CLIENT: 'client',
  CORRELATION_ID: 'correlationId',
  COMMENT_TYPE: 'commentType',
  INSECT_USER_ID: 'commentType',
  DATE_FROM: 'dateFrom',
  DATE_TO: 'dateTo',
  COUNTRY_TO_ID: 'countryToId',
  COUNTRY_TO: 'countryTo',
  COUNTRY_FROM_ID: 'countryFromId',
  COUNTRY_FROM: 'countryFrom',
  CREATE_TYPE_FILES: 'createTypeFiles',
  ORGANIZATION: 'org',
  ORGANIZATION_ID: 'orgId',
  ORGANIZATION_ADRESS: 'orgAdr',
  ORGANIZATION_ADRESS_ID: 'orgAdrId',
  RESPONSIBLE_PREPARE_ID: 'respPrepId',
  RESPONSIBLE_PREPARE_SIGNATURE: 'respPrepSign',
  MANUAL_RESP_PREP_POSITION: 'manualRespPrepPosition',
  CUSTOM_RESTORED_FILES_IDS: 'customRestoredFilesIds',
  /** dateTo восстановленных файлов по id (для сравнения: в deleteFiles только если dateTo изменился) */
  RESTORED_FILES_DATE_TO_BY_ID: 'restoredFilesDateToById',
} as const;

export const CREATE_INSTRUCTION_TYPE_FILES_FORM_NAMES = {
  FILE_FORMAT: 'fileFormatId',
  FILE_PREFIX: 'prefix',
  FILE_NAME_ALGORITHM: 'fileNameAlgoId',
  FILE_SOURCE_TYPE: 'fileSourceTypeId',
  TEMPLATE: 'templateId',
  DATE_FROM: 'dateFrom',
  DATE_TO: 'dateTo',
};

export const excelFileOption: DataTypesSelectOptions = {
  id: FileTypesEnum.ExcelFile,
  label: 'Excel - файл',
};
export const previousCalcOption: DataTypesSelectOptions = {
  id: FileTypesEnum.PreviousCalc,
  label: 'Копировать с',
};
export const periodSelectionOption: DataTypesSelectOptions = {
  id: FileTypesEnum.PeriodSelection,
  label: 'На время',
};

export const dataTypesSelectOptions: DataTypesSelectOptions[] = [
  excelFileOption,
  previousCalcOption,
  periodSelectionOption,
];

export const FILE_FIELD_PREFIX = 'file_';
export const FIELD_KEY = 'key_';

/** Фильтр по typeName для списка клиентов (impOrgPassport) — как в форме инструкции */
export const FILTER_TYPE_NAME_KONTRAGENT = 'Контрагент';

/** Минимальная длина строки поиска перед запросом справочника в Select */
export { LOOKUP_MIN_SEARCH_LENGTH } from 'shared/lib/lookupSearch';
