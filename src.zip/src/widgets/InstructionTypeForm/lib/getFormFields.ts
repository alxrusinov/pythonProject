import { FIELD_KEY, FILE_FIELD_PREFIX } from './constants';

export const getIdentificationDataTabFieldName = <T extends string>(key: T) =>
  `identificationDataTab.${key}` as const;

export const getInputDataTabFieldName = <T extends string>(key: T) =>
  `inputDataTab.${key}` as const;

export const getFileFieldName = (n: number) =>
  `inputDataTab.files.${FILE_FIELD_PREFIX}${n}` as const;

export const getDynamicInputDataTypesFieldName = (key: string | number) =>
  `inputDataTab.dynamicInputDataTypes.${FIELD_KEY}${key}` as const;

export const getDynamicScalarParamsFieldName = (key: string | number) =>
  `scalarParams.${FIELD_KEY}${key}` as const;

export const getPreviousCalcSelectableFieldName = (key: string | number) =>
  `inputDataTab.previousCalcSelectable.${FIELD_KEY}${key}` as const;

export const getPeriodSelectableFieldName = (key: string | number) =>
  `inputDataTab.periodSelectable.${FIELD_KEY}${key}` as const;

export const getFieldKey = (key: string | number) =>
  `${FIELD_KEY}${key}` as const;

export const getFileFieldKey = (key: string | number) =>
  `${FILE_FIELD_PREFIX}${key}`;

export const getInputInstructionTypeDataTabFieldName = <T extends string>(
  key: T,
) => `inputInstructionTypeDataTab.${key}` as const;
