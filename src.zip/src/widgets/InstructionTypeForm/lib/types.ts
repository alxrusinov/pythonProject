import {
  FileDataValue,
  FileTypesEnum,
  IrcCreateInstructionTypeFileInput,
  IrcFileFormat,
  IrcFileNameAlgorithm,
  IrcFileSourceType,
  IrcInstructionType,
  IrcTemplate,
} from 'graphql/generated/generated';

import {
  CREATE_INSTRUCTION_TYPE_FORM_NAMES,
  CREATE_INSTRUCTION_TYPE_FORM_STEPS,
} from './constants';

/** Файл типа инструкции в форме (с опциональным id для файлов из БД) */
export type InstructionTypeFileFormInput = IrcCreateInstructionTypeFileInput & {
  id?: string | null;
};

export type StepValue =
  (typeof CREATE_INSTRUCTION_TYPE_FORM_STEPS)[number]['value'];

export type DataTypesSelectOptions = {
  id: FileTypesEnum;
  label: string;
};

export type UploadableFile =
  | {
      type: 'new';
      file: File;
    }
  | {
      type: 'uploaded';
      meta: FileDataValue;
    };

type IdentificationTabParamKey = keyof CreateInstructionTypeFormParams;
export type IdentificationTabFieldEntry = [
  IdentificationTabParamKey,
  CreateInstructionTypeFormParams[IdentificationTabParamKey],
];

export type CalcParams = {
  masterId: string;
};

// instruction types
export type CreateInstructionTypeFormValues = {
  inputInstructionTypeDataTab: CreateInstructionTypeFormParams;
};

export type InstructionTypeParams = {
  masterId: string;
};

export type CreateInstructionTypeFormParams = {
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.NAME]: IrcInstructionType['name'] | '';
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ID]: IrcInstructionType['id'] | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CORRELATION_ID]?: string | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COMMENT_TYPE]:
    | IrcInstructionType['commentType']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_TO]:
    | IrcInstructionType['dateTo']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.DATE_FROM]:
    | IrcInstructionType['dateFrom']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT_ID]: number | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CLIENT]:
    | IrcInstructionType['client']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO_ID]: number | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_TO]:
    | IrcInstructionType['countryTo']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM_ID]: number | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.COUNTRY_FROM]:
    | IrcInstructionType['countryFrom']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CREATE_TYPE_FILES]:
    | InstructionTypeFileFormInput[]
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_ID]:
    | NonNullable<IrcInstructionType['respPrepare']>['id']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION]:
    | IrcInstructionType['organization']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ID]: number | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS]:
    | IrcInstructionType['orgAddress']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.ORGANIZATION_ADRESS_ID]: number | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESPONSIBLE_PREPARE_SIGNATURE]:
    | IrcInstructionType['respPrepSign']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.MANUAL_RESP_PREP_POSITION]:
    | IrcInstructionType['manualRespPrepPosition']
    | null;
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.CUSTOM_RESTORED_FILES_IDS]: string[];
  [CREATE_INSTRUCTION_TYPE_FORM_NAMES.RESTORED_FILES_DATE_TO_BY_ID]: Record<
    string,
    string
  >;
};

export interface InstrucrionTypeFilesTableProps {
  handleDeleteFile: VoidFunction;
  handleAddFile: VoidFunction;
  handleChangeFile: VoidFunction;
  files: InstructionTypeFileFormInput[] | null | undefined;
  fileNameAlgorithms: IrcFileNameAlgorithm[];
  fileSourceTypes: IrcFileSourceType[] | [];
  fileFormats: IrcFileFormat[] | [];
  templates: IrcTemplate[] | [];
  /** Id файлов, загруженных из БД (для них редактируется только «Действует по»). Не передаётся в таблицу — notReadOnly задаётся в объекте файла в хуке. */
  restoredFileIds?: string[];
  /** Синхронизация данных файлов с формой (по аналогии с handleChangeFiles в InstructionForm) */
  onFilesChangeForForm?: (files: InstructionTypeFileFormInput[] | null) => void;
  /** Блокировка редактирования (например, при lastRec=false) */
  disabled?: boolean;
}

// Type guard для проверки типа FileType
export const isFileType = (
  value: unknown,
): value is InstructionTypeFileFormInput => {
  return (
    typeof value === 'object' &&
    value !== null &&
    'prefix' in value &&
    'fileNameAlgoId' in value &&
    'dateFrom' in value &&
    'fileFormatId' in value &&
    'fileSourceTypeId' in value
  );
};
