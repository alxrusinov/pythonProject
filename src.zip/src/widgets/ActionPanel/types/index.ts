type DisabledPanelConfig = {
  copy?: boolean;
  delete?: boolean;
  edit?: boolean;
};

export type { DisabledPanelConfig };
