import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

import { InstructionModels } from 'shared/types/common';

type State = {
  selectedInstruction: InstructionModels | null;
};

type Action = {
  onSelectInstruction: (value: InstructionModels | null) => void;
  reset: () => void;
};

type StoreType = State & Action;

const initialState: State = {
  selectedInstruction: null,
};

const useInstructionSelected = create<StoreType>()(
  devtools(set => ({
    ...initialState,
    onSelectInstruction: value => {
      set({
        selectedInstruction: value,
      });
    },
    reset: () => {
      set(initialState);
    },
  })),
);

export { useInstructionSelected };
