import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

import { OrgEmailModels } from 'shared/types/common';

type State = {
  selectedOrgEmail: OrgEmailModels | null;
};

type Action = {
  onSelectOrgEmail: (value: OrgEmailModels | null) => void;
  reset: () => void;
};

type StoreType = State & Action;

const initialState: State = {
  selectedOrgEmail: null,
};

const useOrgEmailSelected = create<StoreType>()(
  devtools(set => ({
    ...initialState,
    onSelectOrgEmail: value => {
      set({
        selectedOrgEmail: value,
      });
    },
    reset: () => {
      set(initialState);
    },
  })),
);

export { useOrgEmailSelected };
