import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

import { InstructionTypeModels } from 'shared/types/common';

type State = {
  selectedInstructionType: InstructionTypeModels | null;
};

type Action = {
  onSelectInstructionType: (value: InstructionTypeModels | null) => void;
  reset: () => void;
};

type StoreType = State & Action;

const initialState: State = {
  selectedInstructionType: null,
};

const useInstructionTypeSelected = create<StoreType>()(
  devtools(set => ({
    ...initialState,
    onSelectInstructionType: value => {
      set({
        selectedInstructionType: value,
      });
    },
    reset: () => {
      set(initialState);
    },
  })),
);

export { useInstructionTypeSelected };
