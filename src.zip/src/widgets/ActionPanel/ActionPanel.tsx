import { Button } from 'shared_ui/components';

import { DisabledPanelConfig } from './types';

interface IProps {
  onCreate?: () => void;
  onCopy?: () => void;
  onDelete?: () => void;
  onEdit?: () => void;
  disabled?: DisabledPanelConfig;
}

const ActionPanel = ({
  disabled,
  onCreate,
  onCopy,
  onDelete,
  onEdit,
}: IProps) => {
  return (
    <div className="flex justify-content-end gap-2">
      {onDelete ? (
        <Button
          size="medium"
          onClick={onDelete}
          disabled={disabled?.delete}
          variant="danger"
        >
          Удалить
        </Button>
      ) : null}
      {onEdit ? (
        <Button
          size="medium"
          onClick={onEdit}
          disabled={disabled?.edit}
          variant="primary"
        >
          Открыть
        </Button>
      ) : null}

      {onCopy ? (
        <Button
          size="medium"
          onClick={onCopy}
          disabled={disabled?.copy}
          variant="primary"
        >
          Копировать
        </Button>
      ) : null}
      {onCreate ? (
        <Button size="medium" onClick={onCreate} variant="primary">
          Создать
        </Button>
      ) : null}
    </div>
  );
};

export { ActionPanel };
