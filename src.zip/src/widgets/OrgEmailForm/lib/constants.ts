import { OrgEmailValidationErrors } from './types';

export const EMAIL_REGEXP = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

export const makeDefaultErrors = (): OrgEmailValidationErrors => ({
  organization: '',
  emails: '',
  emailRows: {},
});
