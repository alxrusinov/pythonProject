import { ImpOrgPassport } from 'graphql/generated/generated';

export type OrgEmailFormMode = 'create' | 'edit';

export type OrgEmailFormProps = {
  mode: OrgEmailFormMode;
};

export type OrgEmailValidationErrors = {
  organization?: string;
  emails?: string;
  emailRows: Record<number, string>;
};

export type OrgEmailFormState = {
  organization: ImpOrgPassport | null;
  organizationSearch: string;
  emails: string[];
  errors: OrgEmailValidationErrors;
};
