import { Box, Button } from 'shared_ui/components';

type Props = {
  loading?: boolean;
  mode: 'create' | 'edit';
  onCancel: VoidFunction;
  onSave: VoidFunction;
  onDelete: VoidFunction;
};

export const OrgEmailFormFooter = ({
  loading,
  mode,
  onCancel,
  onSave,
  onDelete,
}: Props) => {
  return (
    <Box className="flex justify-content-between mt-auto">
      <Button
        className="md:w-8rem"
        size="medium"
        variant="secondary"
        onClick={onCancel}
      >
        Назад
      </Button>

      <div className="flex gap-2">
        {mode === 'edit' ? (
          <Button
            className="md:w-8rem"
            size="medium"
            variant="danger"
            onClick={onDelete}
            loading={loading}
          >
            Удалить
          </Button>
        ) : null}

        <Button
          className="md:w-8rem"
          size="medium"
          variant="secondary"
          onClick={onSave}
          loading={loading}
        >
          Сохранить
        </Button>
      </div>
    </Box>
  );
};
