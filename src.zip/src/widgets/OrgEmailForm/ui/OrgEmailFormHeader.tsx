import { NavigationBar } from 'shared_ui/components';

import { OrgEmailFormMode } from '../lib/types';

type Props = {
  mode: OrgEmailFormMode;
  onBack: VoidFunction;
};

export const OrgEmailFormHeader = ({ mode, onBack }: Props) => {
  return (
    <NavigationBar
      backButtonOnClick={onBack}
      title={
        mode === 'create'
          ? 'Справочник email-адресов: создание'
          : 'Справочник email-адресов: редактирование'
      }
    />
  );
};
