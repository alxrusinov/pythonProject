import {
  ImpOrgPassport,
  useIrcOrgEmailsByOrgIdLazyQuery,
} from 'graphql/generated/generated';
import { useEffect, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';

import { Box, Button } from 'shared_ui/components';

import { InstructionTypeFormLayout } from 'shared/ui/InstructionTypeFormLayout';
import { Modal } from 'shared/ui/Modal';
import { getStableRequestDate } from 'shared/utils/date';

import { makeDefaultErrors } from '../lib/constants';
import { OrgEmailFormProps, OrgEmailValidationErrors } from '../lib/types';
import { useOrgEmailEditData } from '../model/useOrgEmailEditData';
import { useOrgEmailFormSubmit } from '../model/useOrgEmailFormSubmit';
import { useOrgEmailOrganizations } from '../model/useOrgEmailOrganizations';
import { EmailsField } from './fields/EmailsField';
import { OrganizationField } from './fields/OrganizationField';
import { OrgEmailFormFooter } from './OrgEmailFormFooter';
import { OrgEmailFormHeader } from './OrgEmailFormHeader';

export const OrgEmailForm = ({ mode }: OrgEmailFormProps) => {
  const navigate = useNavigate();
  const { masterId } = useParams<{ masterId?: string }>();
  const [searchParams] = useSearchParams();
  const orgIdFromUrlParam = Number(searchParams.get('orgId'));
  const orgIdFromUrl = Number.isNaN(orgIdFromUrlParam)
    ? null
    : orgIdFromUrlParam;
  const [organization, setOrganization] = useState<ImpOrgPassport | null>(null);
  const [emails, setEmails] = useState<string[]>(['']);
  const [errors, setErrors] =
    useState<OrgEmailValidationErrors>(makeDefaultErrors);
  const [loadedOrgId, setLoadedOrgId] = useState<number | null>(null);
  const [initialEmailsCount, setInitialEmailsCount] = useState(0);
  const [isDeleteModalVisible, setDeleteModalVisible] = useState(false);
  const [loadByOrgId] = useIrcOrgEmailsByOrgIdLazyQuery();

  const { organizations, handleChangeOrganizationSearch } =
    useOrgEmailOrganizations({
      restoredOrganization: organization,
    });

  const { loading: loadingEditData } = useOrgEmailEditData({
    mode,
    masterId,
    orgIdFromUrl,
    setOrganization,
    setEmails,
    setLoadedOrgId,
  });

  const { handleSave, handleDelete, saving } = useOrgEmailFormSubmit({
    mode,
    organization,
    emails,
    setErrors,
  });

  const clearOrgError = () => {
    setErrors(prev => ({ ...prev, organization: '' }));
  };

  const clearEmailsError = () => {
    setErrors(prev => ({ ...prev, emails: '' }));
  };

  useEffect(() => {
    const orgId = Number(organization?.id);

    if (!orgId) {
      setLoadedOrgId(null);
      setEmails(['']);
      setInitialEmailsCount(0);
      return;
    }

    if (loadedOrgId === orgId) return;
    setLoadedOrgId(orgId);

    const loadEmails = async () => {
      const result = await loadByOrgId({
        variables: {
          orgId,
          requestDate: getStableRequestDate(),
        },
        fetchPolicy: 'no-cache',
      });

      const nextEmails = (result.data?.ircOrgEmails?.items ?? [])
        .map(item => item?.email?.trim() ?? '')
        .filter(Boolean);

      const prepared = nextEmails.length > 0 ? nextEmails : [''];
      setEmails(prepared);
      setInitialEmailsCount(nextEmails.length);
    };

    loadEmails();
  }, [loadedOrgId, loadByOrgId, mode, organization?.id]);

  const updateEmail = (index: number, value: string) => {
    clearEmailsError();
    setEmails(prev => prev.map((item, idx) => (idx === index ? value : item)));
    setErrors(prev => {
      if (!prev.emailRows[index]) return prev;
      const nextRows = { ...prev.emailRows };
      delete nextRows[index];
      return { ...prev, emailRows: nextRows };
    });
  };

  const addEmail = () => {
    clearEmailsError();
    setEmails(prev => [...prev, '']);
  };

  const removeEmail = (index: number) => {
    clearEmailsError();
    setEmails(prev => prev.filter((_, idx) => idx !== index));
    // Keep readonly applied only to remaining original rows.
    setInitialEmailsCount(prev => (index < prev ? prev - 1 : prev));
    setErrors(prev => {
      const nextRows = Object.entries(prev.emailRows).reduce<
        Record<number, string>
      >((acc, [key, message]) => {
        const rowIndex = Number(key);
        if (rowIndex === index) return acc;
        acc[rowIndex > index ? rowIndex - 1 : rowIndex] = message;
        return acc;
      }, {});
      return { ...prev, emailRows: nextRows };
    });
  };

  const isLoading = loadingEditData;

  const handleOpenDeleteModal = () => {
    setDeleteModalVisible(true);
  };

  const handleCloseDeleteModal = () => {
    setDeleteModalVisible(false);
  };

  const handleConfirmDelete = async () => {
    setDeleteModalVisible(false);
    await handleDelete();
  };

  return (
    <InstructionTypeFormLayout>
      <div className="flex flex-column gap-2 flex-grow-1 h-full">
        <OrgEmailFormHeader mode={mode} onBack={() => navigate(-1)} />

        <Box className="p-3 flex-grow-1" rounded>
          <OrganizationField
            value={organization}
            organizations={organizations}
            error={errors.organization}
            disabled={isLoading || saving || mode === 'edit'}
            onChange={value => {
              clearOrgError();
              clearEmailsError();
              setErrors(prev => ({ ...prev, emailRows: {} }));
              setOrganization(value);
            }}
            onSearch={handleChangeOrganizationSearch}
          />

          <EmailsField
            emails={emails}
            errors={errors.emailRows}
            formError={errors.emails}
            disabled={saving}
            readOnlyCount={initialEmailsCount}
            onAdd={addEmail}
            onRemove={removeEmail}
            onChange={updateEmail}
          />
        </Box>

        <OrgEmailFormFooter
          mode={mode}
          loading={saving || isLoading}
          onCancel={() => navigate(-1)}
          onSave={handleSave}
          onDelete={handleOpenDeleteModal}
        />
      </div>
      <Modal
        visible={isDeleteModalVisible}
        title="Удаление email-адреса организации"
        onClose={handleCloseDeleteModal}
      >
        <div className="flex flex-column gap-4 p-2">
          <p className="m-0">
            Вы хотите удалить все email-адреса данной организации?
          </p>
          <div className="flex justify-content-between">
            <Button
              size="medium"
              variant="secondary"
              className="md:w-8rem"
              onClick={handleCloseDeleteModal}
              disabled={saving}
            >
              Нет
            </Button>
            <Button
              size="medium"
              variant="primary"
              className="md:w-8rem"
              onClick={handleConfirmDelete}
              loading={saving}
            >
              Да
            </Button>
          </div>
        </div>
      </Modal>
    </InstructionTypeFormLayout>
  );
};
