import { Button, InputText } from 'shared_ui/components';

import { FormField } from 'shared/ui/FormField';

type Props = {
  emails: string[];
  errors: Record<number, string>;
  formError?: string;
  disabled?: boolean;
  readOnlyCount?: number;
  onAdd: VoidFunction;
  onRemove: (index: number) => void;
  onChange: (index: number, value: string) => void;
};

export const EmailsField = ({
  emails,
  errors,
  formError,
  disabled,
  readOnlyCount = 0,
  onAdd,
  onRemove,
  onChange,
}: Props) => {
  return (
    <FormField
      label="Список email-адресов"
      errorMessage={formError}
      alignItems="start"
      compact
    >
      <div className="flex flex-column gap-2">
        {emails.map((email, index) => (
          <div className="flex gap-2 align-items-start" key={index}>
            <div style={{ width: 420, maxWidth: '100%' }}>
              <InputText
                className="w-full"
                style={{ height: 40 }}
                placeholder="Введите email"
                value={email}
                onChange={e => onChange(index, e.target.value ?? '')}
                disabled={disabled || index < readOnlyCount}
              />
              {errors[index] ? (
                <small className="p-error">{errors[index]}</small>
              ) : null}
            </div>
            <Button
              className="p-0 gap-0 flex align-items-center justify-content-center"
              size="small"
              variant="danger"
              style={{ width: 34, height: 34, minWidth: 34 }}
              onClick={() => onRemove(index)}
              disabled={disabled}
            >
              <i className="pi pi-trash" />
            </Button>
          </div>
        ))}

        <div>
          <Button
            size="small"
            variant="primary"
            onClick={onAdd}
            disabled={disabled}
          >
            Добавить email
          </Button>
        </div>
      </div>
    </FormField>
  );
};
