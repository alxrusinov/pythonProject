import { ImpOrgPassport } from 'graphql/generated/generated';

import { Select } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { FormField } from 'shared/ui/FormField';

type Props = {
  value: ImpOrgPassport | null;
  organizations: ImpOrgPassport[];
  error?: string;
  disabled?: boolean;
  onChange: (value: ImpOrgPassport | null) => void;
  onSearch: (value: string) => void;
};

export const OrganizationField = ({
  value,
  organizations,
  error,
  disabled,
  onChange,
  onSearch,
}: Props) => {
  return (
    <FormField label="Наименование организации" errorMessage={error} compact>
      <div style={{ width: 420, maxWidth: '100%' }}>
        <Select
          panelStyle={{ width: '320px' }}
          wrapOptions={true}
          style={{ height: 40 }}
          placeholder="Выберите организацию"
          value={value}
          options={organizations}
          onChange={(e: DropdownChangeEvent) =>
            onChange((e.value as ImpOrgPassport) ?? null)
          }
          onFilter={(e: DropdownFilterEvent) => onSearch(e.filter)}
          optionLabel="shortName"
          dataKey="id"
          filter
          showClear
          appendTo="self"
          disabled={disabled}
        />
      </div>
    </FormField>
  );
};
