import {
  ImpOrgPassport,
  IrcOrgEmailsForTableDocument,
  useIrcCreateOrUpdateOrgEmailsMutation,
} from 'graphql/generated/generated';
import { useNavigate } from 'react-router-dom';

import { makeNotification } from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { paths } from 'shared/routes/paths';
import { buildPath } from 'shared/utils/buildPath';

import { OrgEmailFormMode } from '../lib/types';
import { validateOrgEmailForm } from './validateOrgEmailForm';

type UseOrgEmailFormSubmitProps = {
  mode: OrgEmailFormMode;
  organization: ImpOrgPassport | null;
  emails: string[];
  setErrors: (
    errors: ReturnType<typeof validateOrgEmailForm>['errors'],
  ) => void;
};

export const useOrgEmailFormSubmit = ({
  mode,
  organization,
  emails,
  setErrors,
}: UseOrgEmailFormSubmitProps) => {
  const orgEmailsPath = buildPath(paths.orgEmails);
  const navigate = useNavigate();
  const [saveOrgEmails, { loading }] = useIrcCreateOrUpdateOrgEmailsMutation();

  const handleSave = async () => {
    const validation = validateOrgEmailForm({ organization, emails });
    setErrors(validation.errors);

    if (!validation.isValid || !organization?.id) {
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Проверьте обязательные поля формы',
      });
      return;
    }

    try {
      await saveOrgEmails({
        variables: {
          input: {
            correlationId: UUID(),
            orgId: Number(organization.id),
            emails: emails.map(v => v.trim()).filter(Boolean),
          },
        },
        refetchQueries: [{ query: IrcOrgEmailsForTableDocument }],
        awaitRefetchQueries: true,
      });

      makeNotification({
        variant: 'success',
        title: 'Успех!',
        message:
          mode === 'create' ? 'Email-адреса созданы' : 'Email-адреса сохранены',
      });

      navigate(orgEmailsPath);
    } catch {
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message:
          mode === 'create'
            ? 'Ошибка создания email-адресов'
            : 'Ошибка сохранения email-адресов',
      });
    }
  };

  const handleDelete = async () => {
    if (!organization?.id) {
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Организация не выбрана',
      });
      return;
    }

    try {
      await saveOrgEmails({
        variables: {
          input: {
            correlationId: UUID(),
            orgId: Number(organization.id),
            emails: [],
          },
        },
        refetchQueries: [{ query: IrcOrgEmailsForTableDocument }],
        awaitRefetchQueries: true,
      });

      makeNotification({
        variant: 'success',
        title: 'Успех!',
        message: 'Email-адреса удалены',
      });

      navigate(orgEmailsPath);
    } catch {
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Ошибка удаления email-адресов',
      });
    }
  };

  return {
    handleSave,
    handleDelete,
    saving: loading,
  };
};
