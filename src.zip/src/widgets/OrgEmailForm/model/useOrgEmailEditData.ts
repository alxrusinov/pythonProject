import {
  ImpOrgPassport,
  useIrcOrgEmailsByOrgIdLazyQuery,
} from 'graphql/generated/generated';
import { useEffect } from 'react';

import { getStableRequestDate } from 'shared/utils/date';

type UseOrgEmailEditDataProps = {
  mode: 'create' | 'edit';
  masterId?: string;
  orgIdFromUrl?: number | null;
  setOrganization: (value: ImpOrgPassport | null) => void;
  setEmails: (value: string[]) => void;
  setLoadedOrgId: (value: number | null) => void;
};

export const useOrgEmailEditData = ({
  mode,
  masterId,
  orgIdFromUrl,
  setOrganization,
  setEmails,
  setLoadedOrgId,
}: UseOrgEmailEditDataProps) => {
  const [getByOrgId, { loading: loadingByOrgId }] =
    useIrcOrgEmailsByOrgIdLazyQuery();

  useEffect(() => {
    if (mode !== 'edit' || !masterId) return;

    const fallbackOrgId = Number(masterId);
    const orgId =
      orgIdFromUrl != null && !Number.isNaN(orgIdFromUrl)
        ? orgIdFromUrl
        : !Number.isNaN(fallbackOrgId)
          ? fallbackOrgId
          : null;
    if (!orgId) return;

    const load = async () => {
      const byOrgResult = await getByOrgId({
        variables: {
          orgId,
          requestDate: getStableRequestDate(),
        },
        fetchPolicy: 'no-cache',
      });

      const items = byOrgResult.data?.ircOrgEmails?.items ?? [];
      const record = items[0];
      if (!record?.organization?.id) return;

      setOrganization({
        id: record.organization.id,
        name: record.organization.name,
        shortName: record.organization.shortName,
      } as ImpOrgPassport);

      const emails = items
        .map(item => item?.email?.trim() ?? '')
        .filter(Boolean);
      setEmails(emails.length > 0 ? emails : ['']);
      setLoadedOrgId(Number(record.organization.id));
    };

    load();
  }, [
    getByOrgId,
    masterId,
    mode,
    orgIdFromUrl,
    setEmails,
    setLoadedOrgId,
    setOrganization,
  ]);

  return {
    loading: loadingByOrgId,
  };
};
