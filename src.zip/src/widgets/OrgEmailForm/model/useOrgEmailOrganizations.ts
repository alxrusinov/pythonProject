import {
  ImpOrgPassport,
  useImpOrgPassportsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import {
  FILTER_TYPE_NAME_KONTRAGENT,
  FILTER_TYPE_NAME_TCFTO,
} from 'widgets/InstructionForm/lib/constants';
import { canFetchLookup } from 'widgets/InstructionForm/lib/lookupSearch';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

type UseOrgEmailOrganizationsProps = {
  restoredOrganization: ImpOrgPassport | null;
};

export const useOrgEmailOrganizations = ({
  restoredOrganization,
}: UseOrgEmailOrganizationsProps) => {
  const [organizationSearchParams, setOrganizationSearchParams] = useState('');
  const [fetchOrganizations, { data }] = useImpOrgPassportsLazyQuery();

  const handleChangeOrganizationSearch = useCallback(
    (value: string) => {
      const q = value.trim();
      setOrganizationSearchParams(q);
      if (!canFetchLookup(q)) return;

      fetchOrganizations({
        variables: {
          where: {
            and: [
              { lastRec: { eq: true } },
              { shortName: { icontains: q } },
              {
                or: [
                  { typeName: { icontains: FILTER_TYPE_NAME_TCFTO } },
                  { typeName: { icontains: FILTER_TYPE_NAME_KONTRAGENT } },
                ],
              },
            ],
          },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchOrganizations],
  );

  const organizations = useMemo(
    () =>
      canFetchLookup(organizationSearchParams)
        ? (data?.impOrgPassports?.items ?? [])
        : [],
    [data, organizationSearchParams],
  );

  return {
    handleChangeOrganizationSearch,
    organizations: restoredOrganization
      ? compareRecords(organizations, restoredOrganization)
      : [...organizations, { id: null, name: undefined }],
  };
};
