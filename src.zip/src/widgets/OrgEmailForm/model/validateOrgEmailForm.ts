import { ImpOrgPassport } from 'graphql/generated/generated';

import { EMAIL_REGEXP, makeDefaultErrors } from '../lib/constants';
import { OrgEmailValidationErrors } from '../lib/types';

type ValidateParams = {
  organization: ImpOrgPassport | null;
  emails: string[];
};

type ValidateResult = {
  isValid: boolean;
  errors: OrgEmailValidationErrors;
};

export const validateOrgEmailForm = ({
  organization,
  emails,
}: ValidateParams): ValidateResult => {
  const errors = makeDefaultErrors();

  if (!organization?.id) {
    errors.organization = 'Поле "Наименование организации" обязательно';
  }

  const trimmed = emails.map(value => value.trim());
  const nonEmpty = trimmed.filter(Boolean);

  if (nonEmpty.length === 0) {
    errors.emails = 'Нужно добавить хотя бы один email-адрес';
  }

  trimmed.forEach((value, index) => {
    if (!value) {
      errors.emailRows[index] = 'Email-адрес обязателен';
      return;
    }

    if (!EMAIL_REGEXP.test(value)) {
      errors.emailRows[index] = 'Некорректный формат email';
    }
  });

  const indexMap = new Map<string, number[]>();
  trimmed.forEach((value, index) => {
    if (!value) return;
    const key = value.toLowerCase();
    indexMap.set(key, [...(indexMap.get(key) ?? []), index]);
  });

  indexMap.forEach(indexes => {
    if (indexes.length < 2) return;
    indexes.forEach(index => {
      errors.emailRows[index] =
        'Email-адрес должен быть уникален в рамках организации';
    });
  });

  return {
    isValid:
      !errors.organization &&
      !errors.emails &&
      Object.keys(errors.emailRows).length === 0,
    errors,
  };
};
