import { FileDataValue } from 'graphql/generated/generated';

export const createFakeFileFromMeta = (meta: FileDataValue) =>
  ({
    name: meta.fileName,
    size: meta.fileSizeInBytes,
  }) as File;
