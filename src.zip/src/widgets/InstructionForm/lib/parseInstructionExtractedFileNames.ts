import { EntityNotificationExtension } from 'graphql/generated/generated';

type FileNameEntry = {
  instructionTypeFileId?: string | null;
  fileId?: string | null;
  id?: string | null;
  instructionTypeFileID?: string | null;
  fileName?: string | null;
  name?: string | null;
  displayName?: string | null;
  title?: string | null;
  generatedFileName?: string | null;
};

const LIST_KEYS = [
  'fileNames',
  'instructionFileNames',
  'instructionTypeFiles',
  'files',
  'items',
] as const;

const readId = (entry: FileNameEntry): string | null => {
  const raw =
    entry.instructionTypeFileId ??
    entry.fileId ??
    entry.id ??
    entry.instructionTypeFileID;
  if (raw == null || raw === '') return null;
  return String(raw).toLowerCase();
};

const readName = (entry: FileNameEntry): string => {
  const raw =
    entry.fileName ??
    entry.name ??
    entry.displayName ??
    entry.title ??
    entry.generatedFileName;
  if (raw == null) return '';
  return String(raw);
};

const parseParsedValue = (parsed: unknown): FileNameEntry[] => {
  if (Array.isArray(parsed)) {
    return parsed.filter(
      (item): item is FileNameEntry =>
        item != null && typeof item === 'object' && !Array.isArray(item),
    );
  }
  if (parsed != null && typeof parsed === 'object') {
    return [parsed as FileNameEntry];
  }
  return [];
};

const tryParseExtensionValue = (value: string | null | undefined): unknown => {
  if (value == null || value === '') return null;
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
};

const collectFromParsed = (parsed: unknown): FileNameEntry[] => {
  if (parsed == null) return [];

  if (Array.isArray(parsed)) {
    return parseParsedValue(parsed);
  }

  const asRecord = parsed as Record<string, unknown>;
  for (const key of LIST_KEYS) {
    const nested = asRecord[key];
    if (Array.isArray(nested)) {
      return parseParsedValue(nested);
    }
  }

  return [];
};

const addEntriesToMap = (
  map: Record<string, string>,
  entries: FileNameEntry[],
): void => {
  for (const entry of entries) {
    const id = readId(entry);
    if (!id) continue;
    const name = readName(entry).trim();
    if (name) map[id] = name;
  }
};

/**
 * Строит карту id файла → сгенерированное имя из extensions уведомления entityNotifications.
 */
export const parseInstructionExtractedFileNames = (
  extensions: ReadonlyArray<EntityNotificationExtension>,
): Record<string, string> => {
  const map: Record<string, string> = {};

  for (const ext of extensions) {
    const parsed = tryParseExtensionValue(ext.value);
    if (parsed == null) continue;

    if (LIST_KEYS.includes(ext.key as (typeof LIST_KEYS)[number])) {
      addEntriesToMap(map, collectFromParsed(parsed));
      continue;
    }

    const asObject =
      parsed != null && typeof parsed === 'object' && !Array.isArray(parsed)
        ? (parsed as Record<string, unknown>)
        : null;

    if (asObject) {
      for (const key of LIST_KEYS) {
        const nested = asObject[key];
        addEntriesToMap(map, collectFromParsed(nested));
      }
    }
  }

  return map;
};
