/** Флаг: только что выполнен restore в useRestoreInstructionData (нужен для корректирующего reset в InstructionForm) */
let restoreJustFinished = false;

export const setRestoreJustFinished = (value: boolean): void => {
  restoreJustFinished = value;
};

export const getRestoreJustFinished = (): boolean => restoreJustFinished;
