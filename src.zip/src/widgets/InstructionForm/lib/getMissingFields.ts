import { DataType } from 'graphql/generated/generated';

type GetMissingFieldsProps = {
  dataTypes?: DataType[];
  inputDataTabValues?: DataType[];
};

export const getMissingFields = ({
  dataTypes,
  inputDataTabValues,
}: GetMissingFieldsProps) => {
  const requiredFields =
    dataTypes?.filter(
      item =>
        item.isFileLoadable &&
        !item.isPeriodSelectable &&
        !item.isPreviousCalcSelectable,
    ) ?? [];

  const currentIds = new Set(inputDataTabValues?.map(item => item.id));
  return requiredFields.filter(item => !currentIds.has(item.id));
};
