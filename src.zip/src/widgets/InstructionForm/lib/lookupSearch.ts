export {
  LOOKUP_MIN_SEARCH_LENGTH,
  canFetchLookup,
  normalizeLookupSearch,
} from 'shared/lib/lookupSearch';
