import { IrcOrgEmailsByOrgIdLazyQueryHookResult } from 'graphql/generated/generated';

import { CREATE_INSTRUCTION_FORM_NAMES } from './constants';
import { CreateInstructionFormValues } from './types';

const parseClientEmails = (clientEmails: string | undefined): string[] =>
  (clientEmails ?? '')
    .split(/[,\s]+/)
    .map(s => s.trim())
    .filter(Boolean);

type LoadOrgEmails = IrcOrgEmailsByOrgIdLazyQueryHookResult[0];

export const hasInstructionRecipientEmails = async (
  formData: CreateInstructionFormValues,
  loadOrgEmails: LoadOrgEmails,
  requestDate: string,
): Promise<boolean> => {
  const inputDataTab = formData.inputInstructionDataTab;

  if (formData.recieverInfoSwitch) {
    const clientEmails =
      inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CLIENTS_EMAILS];
    const manualEmails = parseClientEmails(
      typeof clientEmails === 'string' ? clientEmails : '',
    );
    return manualEmails.length > 0;
  }

  const client = inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.CLIENT];
  const orgId = client?.id;
  const normalizedOrgId = orgId != null ? Number(orgId) : null;

  if (normalizedOrgId == null || Number.isNaN(normalizedOrgId)) {
    return false;
  }

  const result = await loadOrgEmails({
    variables: {
      orgId: normalizedOrgId,
      requestDate,
    },
    fetchPolicy: 'no-cache',
  });

  const orgEmails = (result.data?.ircOrgEmails?.items ?? [])
    .map(item => item?.email?.trim() ?? '')
    .filter(Boolean);

  return orgEmails.length > 0;
};
