import { getStableRequestDate } from 'shared/utils/date';

/** Дата версионирования справочников в форме инструкции: calcDate из URL или текущая. */
export const resolveInstructionLookupRequestDate = (
  calcDateParam: string | null,
): string => {
  if (calcDateParam) {
    const timestamp = Number(calcDateParam);
    return !Number.isNaN(timestamp)
      ? new Date(timestamp).toISOString()
      : getStableRequestDate();
  }
  return getStableRequestDate();
};
