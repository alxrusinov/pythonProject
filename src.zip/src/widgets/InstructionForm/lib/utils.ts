import { IrcInstructionTypeFile } from 'graphql/generated/generated';

import {
  FILE_FORMAT_MIME_TYPES,
  FILE_SOURCE_TYPE_ID,
} from 'widgets/InstructionForm/lib/constants';

// Функция для фильтрации файлов по типу источника
export const filterFilesBySourceType = (
  files: Array<IrcInstructionTypeFile | null | undefined> | null | undefined,
): IrcInstructionTypeFile[] => {
  return (files || []).filter(
    (file): file is IrcInstructionTypeFile =>
      file !== null &&
      file !== undefined &&
      file?.fileSourceType?.id === FILE_SOURCE_TYPE_ID,
  );
};

// Функция для формирования href для скачивания файла
export const getFileDownloadHref = (
  content: string | null | undefined,
  fileFormat?: { name?: string | null } | null,
): string => {
  if (!content) {
    return '';
  }

  const formatName = fileFormat?.name?.toLowerCase() || 'pdf';
  const mimeType =
    FILE_FORMAT_MIME_TYPES[formatName] || `application/${formatName}`;

  return `data:${mimeType};base64,${content}`;
};

/** Фильтрует пустые объекты-заглушки {id: 0, name: null} при восстановлении данных */
export const filterEmptyRestoredObject = <
  T extends { id?: number | string | null; name?: string | null },
>(
  obj: T | null | undefined,
): T | null => {
  if (obj == null) return null;
  const id = obj.id;
  const name = obj.name;
  const isEmpty =
    (id === 0 || id === null || id === undefined || id === '') &&
    (name === null || name === undefined || name === '');
  return isEmpty ? null : obj;
};
