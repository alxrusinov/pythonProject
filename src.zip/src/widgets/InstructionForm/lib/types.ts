import {
  IrcInstruction,
  IrcInstructionCar,
  IrcInstructionRoute,
  IrcInstructionType,
  IrcInstructionUserFileInput,
} from 'graphql/generated/generated';

import { ExportingData } from 'features/VerificationWagons';

import {
  CREATE_INSTRUCTION_FORM_NAMES,
  CREATE_INSTRUCTION_FORM_STEPS,
} from './constants';

export type StepValue = (typeof CREATE_INSTRUCTION_FORM_STEPS)[number]['value'];

type IdentificationTabParamKey = keyof CreateInstructionFormParams;
export type IdentificationTabFieldEntry = [
  IdentificationTabParamKey,
  CreateInstructionFormParams[IdentificationTabParamKey],
];

export type CalcParams = {
  masterId: string;
};

// instruction types
export type CreateInstructionFormValues = {
  inputInstructionDataTab: CreateInstructionFormParams;
  recieverSwitch: boolean;
  senderSwitch: boolean;
  recieverInfoSwitch: boolean;
  newCarsInput: string;
};

export type InstructionParams = {
  masterId: string;
};

export type CreateInstructionFormParams = {
  [CREATE_INSTRUCTION_FORM_NAMES.ID]: IrcInstruction['id'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.ACCOMP_TEXT]:
    | IrcInstruction['accompText']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.ACCOMP_TEXT_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CALC_DATE]: IrcInstruction['calcDate'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CLIENT_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CLIENT]: IrcInstruction['client'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CARS]: IrcInstruction['cars'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CLAIMS]: IrcInstruction['claims'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CLIENT_EMAIL_TEXT]:
    | IrcInstruction['clientEmailText']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.NUMBER]: IrcInstruction['number'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CLIENTS]: IrcInstruction['clients'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.DATE]: IrcInstruction['date'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.DEFECT_OPER]:
    | IrcInstruction['defectOper']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.EMAIL_TEXT]:
    | IrcInstruction['emailText']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.EMAIL_TEXT_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.FR_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.FREIGHT]: IrcInstruction['freight'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.GNG_FR_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.GNG_FREIGHT]:
    | IrcInstruction['gngFreight']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.INSTRUCTION_TYPE_ID]: string | null;
  [CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_NAME]:
    | IrcInstruction['manualClientName']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_OKPO]:
    | IrcInstruction['manualClientOkpo']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_TGNL]:
    | IrcInstruction['manualClientTgnl']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.NOT_FOR_CARRIER_TEXT]:
    | IrcInstruction['notForCarrierText']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.OPERATIONS]:
    | IrcInstruction['operations']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.OPTIONAL_MARKS_TEXT]:
    | IrcInstruction['optionalMarksText']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.PARENT_ID]: string | null;
  [CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_ST_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION]:
    | IrcInstruction['receiverStation']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_MANUAL_RECIP_NAME]:
    | IrcInstruction['recieverManualRecipName']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_MANUAL_RECIP_OKPO]:
    | IrcInstruction['recieverManualRecipOkpo']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_MANUAL_RECIP_TGNL]:
    | IrcInstruction['recieverManualRecipTgnl']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP]:
    | IrcInstruction['recieverRecip']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.ROUTES]: IrcInstruction['routes'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SEND_FULL_COMP_OPER]:
    | IrcInstruction['sendFullCompOper']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SEND_NOT_FULL_COMP_OPER]:
    | IrcInstruction['sendNotFullCompOper']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDER_MANUAL_RECIP_NAME]:
    | IrcInstruction['senderManualRecipName']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDER_MANUAL_RECIP_OKPO]:
    | IrcInstruction['senderManualRecipOkpo']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDER_MANUAL_RECIP_TGNL]:
    | IrcInstruction['senderManualRecipTgnl']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP]:
    | IrcInstruction['senderRecip']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDER_ST_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION]:
    | IrcInstruction['senderStation']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDING_TYPE]:
    | IrcInstruction['sendingType']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.SENDING_TYPE_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.STATION_FROM_NAME]:
    | IrcInstruction['stationFromName']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.STATUS]: IrcInstruction['status'] | null;
  [CREATE_INSTRUCTION_FORM_NAMES.STATUS_ID]: number | null;
  [CREATE_INSTRUCTION_FORM_NAMES.TYPES]: IrcInstructionType | null;
  [CREATE_INSTRUCTION_FORM_NAMES.USER_FILES]:
    | IrcInstructionUserFileInput[]
    | null;

  // [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_PPS]:
  //   | IrcInstructionRoute['contractPps']
  //   | null;
  // [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_REPAIR]:
  //   | IrcInstructionRoute['contractRepair']
  //   | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_FREIGHT]:
    | IrcInstructionCar['prevFreight']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_GNG_FREIGHT]:
    | IrcInstructionCar['prevGngFreight']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_RECIEVER_ADDRESS]:
    | IrcInstructionRoute['recipAddress']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS]:
    | IrcInstructionRoute['recipAddress']
    | null;

  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_ADDRESS]:
    | IrcInstructionRoute['manualRecipAddress']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_ADDRESS]:
    | IrcInstructionRoute['manualRecipAddress']
    | null;

  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_NAME]:
    | IrcInstructionRoute['manualRecipName']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_NAME]:
    | IrcInstructionRoute['manualRecipName']
    | null;

  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_OKPO]:
    | IrcInstructionRoute['manualRecipOkpo']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_OKPO]:
    | IrcInstructionRoute['manualRecipOkpo']
    | null;

  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_TGNL]:
    | IrcInstructionRoute['manualRecipTgnl']
    | null;
  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_TGNL]:
    | IrcInstructionRoute['manualRecipTgnl']
    | null;

  [CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CLIENTS_EMAILS]: string | '';
};

export type StoreState = {
  preFillingFields: ExportingData | null;
};

type StoreActions = {
  setPreFillingFields: (preFillingFields: ExportingData | null) => void;
  resetSenderStation: () => void;
  resetClient: () => void;
  resetSenderRecip: () => void;
  resetCustomPrevFreight: () => void;
  resetCustomPrevGngFreight: () => void;
  reset: () => void;
};

export type StoreType = StoreState & StoreActions;
