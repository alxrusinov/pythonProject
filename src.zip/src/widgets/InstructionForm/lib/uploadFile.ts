import { api } from 'shared/utils/fetchApi';
import { sanitizeFileName } from 'shared/utils/file';

const PREFIX = '/Upload';

export const uploadFile = async (file: File): Promise<string> => {
  const formData = new FormData();
  formData.append('File', file);
  formData.append('FileName', sanitizeFileName(file.name));

  const response = await api.uploadFile<{ fileId: string }>(PREFIX, formData);

  return response.fileId;
};
