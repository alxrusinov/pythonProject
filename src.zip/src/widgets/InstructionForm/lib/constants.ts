import { CompareItem } from 'features/VerificationWagons';

import { TabMenuElements } from 'shared/types/common';

export const CREATE_INSTRUCTION_FORM_STEPS: TabMenuElements[] = [
  {
    label: 'Основные реквизиты',
    value: 'inputInstructionDataTab',
  },
];

export const EDIT_INSTRUCTION_FORM_STEPS: TabMenuElements[] = [
  {
    label: 'Основные реквизиты',
    value: 'inputInstructionDataTab',
  },
  {
    label: 'Печатная форма',
    value: 'printForm',
  },
  {
    label: 'История операций',
    value: 'operationHistory',
  },
];

export const CALCULATION_FORM_NAME = {
  MODEL_TYPE: 'modelType',
  CALC_NAME: 'calcName',
  CALC_TYPE: 'calcType',
  PLAN_PERIOD: 'planPeriod',
  PLAN_HORIZON_DAYS: 'planHorizonDays',
  PUBLICATION_DATE: 'publicationDate',
  ON_PUBLICATION_DATE: 'onPublicationDate',
  DATE_VERSION: 'dateVersion',
  ON_DATE_VERSION: 'onDateVersion',
  COMMENT: 'comment',
  INPUT_DATA_TYPES: 'inputDataTypes',
  PREVIOUS_CALCULATIONS: 'previousCalculations',
} as const;

/** Номер вагона: только цифры, от 1 до 8 знаков */
export const CAR_NUMBER_REGEX = /^\d{1,8}$/;

export const CREATE_INSTRUCTION_FORM_NAMES = {
  ID: 'id',
  ACCOMP_TEXT: 'accompText',
  ACCOMP_TEXT_ID: 'accompTextId',
  CALC_DATE: 'calcDate',
  CLIENT_ID: 'clientId',
  CLIENT: 'client',
  MANUAL_CLIENT_NAME: 'manualClientName',
  CARS: 'cars',
  CLAIMS: 'claims',
  CLIENT_EMAIL_TEXT: 'clientEmailText',
  NUMBER: 'number',
  CLIENTS: 'clients',
  CUSTOM_CLIENTS_EMAILS: 'customClientsEmails',
  DATE: 'date',
  DEFECT_OPER: 'defectOper',
  EMAIL_TEXT: 'emailText',
  EMAIL_TEXT_ID: 'emailTextId',
  FR_ID: 'frId',
  FREIGHT: 'freight',
  GNG_FR_ID: 'gngFrId',
  GNG_FREIGHT: 'gngFreight',
  INSTRUCTION_TYPE_ID: 'instructionTypeId',
  MANUAL_CLIENT_OKPO: 'manualClientOkpo',
  MANUAL_CLIENT_TGNL: 'manualClientTgnl',
  NOT_FOR_CARRIER_TEXT: 'notForCarrierText',
  OPERATIONS: 'operations',
  OPTIONAL_MARKS_TEXT: 'optionalMarksText',
  PARENT_ID: 'parentId',
  RECIEVER_ST_ID: 'receiverStId',
  RECIEVER_STANTION: 'receiverStation',
  RECIEVER_MANUAL_RECIP_NAME: 'recieverManualRecipName',
  RECIEVER_MANUAL_RECIP_OKPO: 'recieverManualRecipOkpo',
  RECIEVER_MANUAL_RECIP_TGNL: 'recieverManualRecipTgnl',
  RECIEVER_RECIP: 'recieverRecip',
  RECIEVER_RECIP_ID: 'recieverRecipId',
  ROUTES: 'routes',
  SEND_FULL_COMP_OPER: 'sendFullCompOper',
  SEND_NOT_FULL_COMP_OPER: 'sendNotFullCompOper',
  SENDER_MANUAL_RECIP_NAME: 'senderManualRecipName',
  SENDER_MANUAL_RECIP_OKPO: 'senderManualRecipOkpo',
  SENDER_MANUAL_RECIP_TGNL: 'senderManualRecipTgnl',
  SENDER_RECIP: 'senderRecip',
  SENDER_RECIP_ID: 'senderRecipId',
  SENDER_ST_ID: 'senderStId',
  SENDER_STANTION: 'senderStation',
  SENDING_TYPE: 'sendingType',
  SENDING_TYPE_ID: 'sendingTypeId',
  STATION_FROM_NAME: 'stationFromName',
  STATUS: 'status',
  STATUS_ID: 'statusId',
  TYPES: 'types',
  USER_FILES: 'userFiles',

  CUSTOM_RECIEVER_ADDRESS: 'customRecieverAddress',
  CUSTOM_MANUAL_RECIEVER_NAME: 'customManualRecieverName',
  CUSTOM_MANUAL_RECIEVER_ADDRESS: 'customManualRecieverAddress',
  CUSTOM_MANUAL_RECIEVER_OKPO: 'customManualRecieverOkpo',
  CUSTOM_MANUAL_RECIEVER_TGNL: 'customManualRecieverTgnl',
  CUSTOM_CONTRACT_PPS: 'customContractPps',
  CUSTOM_CONTRACT_REPAIR: 'customContractRepair',
  CUSTOM_SENDER_ADDRESS: 'customSenderAddress',
  CUSTOM_MANUAL_SENDER_NAME: 'customManualSenderName',
  CUSTOM_MANUAL_SENDER_ADDRESS: 'customManualSenderAddress',
  CUSTOM_MANUAL_SENDER_OKPO: 'customManualSenderOkpo',
  CUSTOM_MANUAL_SENDER_TGNL: 'customManualSenderTgnl',
  CUSTOM_PREV_FREIGHT: 'customPrevFreight',
  CUSTOM_PREV_GNG_FREIGHT: 'customPrevGngFreight',
} as const;

export const INSTRUCTION_STATUSES = {
  canceled: 'Испорчена',
  created: 'Заготовка',
  sended: 'Отправлена',
};

export const CREATE_INSTRUCTION_FILES_FORM_NAMES = {
  FILE_FORMAT: 'fileFormatId',
  FILE_NAME: 'name',
  FILE_SOURCE_TYPE: 'fileSourceTypeId',
  TEMPLATE: 'templateId',
  DATE_FROM: 'dateFrom',
  DATE_TO: 'dateTo',
};

export const FILE_FIELD_PREFIX = 'file_';
export const FIELD_KEY = 'key_';

export const FILTER_TYPE_NAME_TCFTO = 'ТЦФТО';
export const FILTER_TYPE_NAME_KONTRAGENT = 'Контрагент';
export const FREIGHTS_FILTER_CODE = '421';

/** Организации для поля "Получатель инструкции": ЦФТО/ТЦФТО или Контрагент. */
export const impOrgPassportMatchesInstructionClientType = (
  typeName: string | null | undefined,
): boolean => {
  if (typeName == null || String(typeName).trim() === '') return false;
  const n = String(typeName).toLowerCase();
  return (
    n.includes(FILTER_TYPE_NAME_TCFTO.toLowerCase()) ||
    n.includes(FILTER_TYPE_NAME_KONTRAGENT.toLowerCase())
  );
};

/** Организации для полей ГО/ГП: только Контрагент. */
export const impOrgPassportMatchesCounterpartyType = (
  typeName: string | null | undefined,
): boolean => {
  if (typeName == null || String(typeName).trim() === '') return false;
  const n = String(typeName).toLowerCase();
  return n.includes(FILTER_TYPE_NAME_KONTRAGENT.toLowerCase());
};

// Константа для фильтрации файлов по типу источника
export const FILE_SOURCE_TYPE_ID = 2;
export const PAYER_TYPE_ID = 16;

// Маппинг форматов файлов на MIME-типы
export const FILE_FORMAT_MIME_TYPES: Record<string, string> = {
  pdf: 'application/pdf',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  xls: 'application/vnd.ms-excel',
  doc: 'application/msword',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  txt: 'text/plain',
  csv: 'text/csv',
  xml: 'application/xml',
  json: 'application/json',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  gif: 'image/gif',
};

export const InitialFieldsForWagonModal: {
  station: CompareItem<number> | null;
  customer: CompareItem<number> | null;
} = {
  station: null,
  customer: null,
};
