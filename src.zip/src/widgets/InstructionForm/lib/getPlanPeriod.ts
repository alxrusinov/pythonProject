export const getPlanPeriod = () => {
  const now = new Date();

  return now;
};
