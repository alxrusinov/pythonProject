import { FC, useEffect, useMemo, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import {
  generatePath,
  Link,
  useParams,
  useSearchParams,
} from 'react-router-dom';

import { Loader } from 'shared_ui/components';
import { formatDate, formatDateWithTime } from 'shared_ui/utils';

import { InstructionFormTabMenu } from 'features/InstructionFormTabMenu';

import { paths } from 'shared/routes/paths';
import { InstructionFormFooter } from 'shared/ui/InstructionFormFooter';
import { InstructionFormHeader } from 'shared/ui/InstructionFormHeader';
import { TabPanel } from 'shared/ui/TabPanel';
import { buildPath } from 'shared/utils/buildPath';
import { toCalcDateTimestamp } from 'shared/utils/date';

import {
  CREATE_INSTRUCTION_FORM_NAMES,
  CREATE_INSTRUCTION_FORM_STEPS,
  EDIT_INSTRUCTION_FORM_STEPS,
} from '../lib/constants';
import {
  getRestoreJustFinished,
  setRestoreJustFinished,
} from '../lib/instructionFormDebugLog';
import { StepValue } from '../lib/types';
import { InstructionExtractedFileNamesProvider } from '../model/InstructionExtractedFileNamesContext';
import {
  RestoredInstructionProvider,
  useRestoredInstructionContext,
} from '../model/RestoredInstructionContext';
import { useBackAction } from '../model/useBackAction';
import { useCreateInstruction } from '../model/useCreateInstruction';
import { useFieldsPrefilling } from '../store';
import { HistoryOperationsInstructionTab } from './HistoryOperationsInstructionTab';
import { InputInstructionDataTab } from './InputInstructionDataTab';
import { PrintForm } from './PrintForm';

const InstructionFormContent: FC = () => {
  const {
    restoredInstructionData,
    loading: instructionDataLoading,
    refetch: refetchInstruction,
  } = useRestoredInstructionContext();

  const {
    methods,
    handleTabValidate,
    activeTab,
    saveForm,
    registerForm,
    tabSteps,
    cancelInstruction,
    sendInstruction,
    correctForm,
    isSubmitting,
    saveSuccessTick,
  } = useCreateInstruction();

  const resetPrefilling = useFieldsPrefilling(s => s.reset);

  useEffect(() => {
    return () => resetPrefilling();
  }, [resetPrefilling]);

  const { formState, reset, getValues } = methods;
  const isDirty = formState.isDirty;
  const dirtyFields = formState.dirtyFields;

  useEffect(() => {
    if (!isDirty || !getRestoreJustFinished()) return;
    const userFilesDirty =
      dirtyFields?.inputInstructionDataTab?.[
        CREATE_INSTRUCTION_FORM_NAMES.USER_FILES
      ] === true;
    if (userFilesDirty) return;

    setRestoreJustFinished(false);
    reset(getValues());
  }, [isDirty, dirtyFields, reset, getValues]);

  const handleBack = useBackAction();
  const { masterId } = useParams();
  const [searchParams] = useSearchParams();
  const copyFrom = searchParams.get('copyFrom');

  const needsRestoredInstructionData = Boolean(masterId || copyFrom);
  const isInstructionDataInitialLoad =
    needsRestoredInstructionData &&
    instructionDataLoading &&
    !restoredInstructionData;

  const isPrintTabActive = activeTab === EDIT_INSTRUCTION_FORM_STEPS[1].value;
  const isHistoryTabActive = activeTab === EDIT_INSTRUCTION_FORM_STEPS[2].value;
  const [printTabRefreshTick, setPrintTabRefreshTick] = useState(0);

  const isEditMode = !!masterId && !copyFrom;
  const isCorrection = isEditMode && !!restoredInstructionData?.parent?.id;
  const instructionNumber = isEditMode
    ? (restoredInstructionData?.number ?? '')
    : '';
  const instructionDate = isEditMode ? restoredInstructionData?.date : null;
  const parent = restoredInstructionData?.parent;

  const parentInstructionPath = useMemo(() => {
    if (!parent?.id) return null;
    const calcDate = toCalcDateTimestamp(parent.calcDate ?? parent.date);
    return (
      buildPath(generatePath(paths.editInstruction, { masterId: parent.id })) +
      `?calcDate=${encodeURIComponent(String(calcDate))}`
    );
  }, [parent?.id, parent?.calcDate, parent?.date]);

  const instructionName = useMemo(() => {
    const currentInstructionTitle =
      instructionNumber +
      (instructionDate ? ` от ${formatDateWithTime(instructionDate)}` : '');

    const currentInstructionTitleCorrection =
      instructionNumber +
      (instructionDate ? ` от ${formatDate(instructionDate)}` : '');

    if (isCorrection && parent) {
      const parentNumber = parent.number ?? '';
      const parentDate = parent.date ?? '';
      const parentDateFormatted = parentDate
        ? ` от ${formatDate(parentDate)}`
        : '';
      return (
        <>
          {currentInstructionTitleCorrection}
          {parentNumber ? (
            <>
              {' '}
              Изм{' '}
              {parentInstructionPath ? (
                <>
                  <Link to={parentInstructionPath}>{parentNumber}</Link>{' '}
                  {parentDateFormatted}
                </>
              ) : (
                parentNumber
              )}
            </>
          ) : null}
        </>
      );
    }

    return currentInstructionTitle;
  }, [
    isCorrection,
    parent,
    parentInstructionPath,
    instructionNumber,
    instructionDate,
  ]);
  const instructionStatus =
    isEditMode && restoredInstructionData?.status?.name
      ? restoredInstructionData.status.name
      : '';

  useEffect(() => {
    if (isPrintTabActive) {
      refetchInstruction();
      setPrintTabRefreshTick(tick => tick + 1);
    }
  }, [isPrintTabActive, refetchInstruction]);

  return (
    <>
      {(isSubmitting || isInstructionDataInitialLoad) && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'rgba(159, 159, 159, 0.8)',
          }}
        >
          <Loader variant="global" />
        </div>
      )}
      <FormProvider {...methods}>
        <InstructionExtractedFileNamesProvider
          refreshTick={saveSuccessTick}
          printTabRefreshTick={printTabRefreshTick}
        >
          <InstructionFormHeader
            onBack={handleBack}
            instructionName={instructionName}
            status={instructionStatus}
          >
            <InstructionFormTabMenu
              elements={tabSteps}
              initialTab={CREATE_INSTRUCTION_FORM_STEPS[0].value}
              onChooseCb={handleTabValidate}
            />
          </InstructionFormHeader>

          <TabPanel<StepValue>
            step={CREATE_INSTRUCTION_FORM_STEPS[0].value}
            activeStep={activeTab}
          >
            <InputInstructionDataTab />
          </TabPanel>
          {masterId && (
            <>
              <TabPanel<StepValue>
                step={EDIT_INSTRUCTION_FORM_STEPS[1].value}
                activeStep={activeTab}
              >
                {isPrintTabActive && (
                  <PrintForm saveSuccessTick={saveSuccessTick} />
                )}
              </TabPanel>
              <TabPanel<StepValue>
                step={EDIT_INSTRUCTION_FORM_STEPS[2].value}
                activeStep={activeTab}
              >
                {isHistoryTabActive && <HistoryOperationsInstructionTab />}
              </TabPanel>
            </>
          )}
        </InstructionExtractedFileNamesProvider>
      </FormProvider>

      <InstructionFormFooter
        onSave={() => (masterId ? saveForm() : registerForm())}
        onCancel={cancelInstruction}
        onBack={handleBack}
        onSend={sendInstruction}
        onCorrect={correctForm}
        status={instructionStatus}
        isDirty={isDirty}
      />
    </>
  );
};

export const InstructionForm: FC = () => (
  <RestoredInstructionProvider>
    <InstructionFormContent />
  </RestoredInstructionProvider>
);
