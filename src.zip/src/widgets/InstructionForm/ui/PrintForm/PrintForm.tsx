import {
  EntityNotificationExtension,
  IrcInstructionTypeFile,
  useEntityNotificationsSubscription,
  useGetIrcFileBase64Mutation,
  useGetIrcFilePreviewMutation,
} from 'graphql/generated/generated';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import {
  Box,
  Button,
  Column,
  Loader,
  makeNotification,
  Typography,
} from 'shared_ui/components';
import { DataTable } from 'shared_ui/primereact';
import { UUID } from 'shared_ui/utils';

import { useInstructionExtractedFileNames } from 'widgets/InstructionForm/model/InstructionExtractedFileNamesContext';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';

import { decodeOperationError } from 'shared/utils/decodeOperationError';
import { entityNotificationExtensionsToRecord } from 'shared/utils/entityNotificationExtensions';
import { sanitizeFileName } from 'shared/utils/file';

import styles from './PrintForm.module.scss';

type PrintFormProps = {
  saveSuccessTick?: number;
};

type ParsedFilePayload = {
  fileContent: string;
  fileName: string;
  fileFormat: string;
};

// Ответы по WS (preview/base64) могут приходить с другим entityType.
const SUBSCRIBE_ALL_ENTITY_TYPES: string[] | undefined = undefined;

const asRecord = (value: unknown): Record<string, unknown> | null =>
  value && typeof value === 'object'
    ? (value as Record<string, unknown>)
    : null;

const pickString = (
  source: Record<string, unknown>,
  keys: string[],
): string | null => {
  for (const key of keys) {
    const raw = source[key];
    if (typeof raw === 'string' && raw.trim() !== '') return raw;
  }
  return null;
};

const parseFilePayloadFromExtensions = (
  extensions: ReadonlyArray<EntityNotificationExtension>,
): ParsedFilePayload | null => {
  const record = entityNotificationExtensionsToRecord(extensions);
  const nestedFile =
    asRecord(record.file) ??
    asRecord(record.result) ??
    asRecord(record.payload);
  const source = nestedFile ?? record;

  const fileContent = pickString(source, [
    'fileContent',
    'content',
    'fileBase64',
    'base64',
    'previewContent',
  ]);
  if (!fileContent) return null;

  return {
    fileContent,
    fileName: pickString(source, ['fileName', 'name']) ?? '',
    fileFormat: pickString(source, ['fileFormat', 'format', 'extension']) ?? '',
  };
};

const toPreviewSrc = (fileContent: string): string =>
  fileContent.startsWith('data:')
    ? fileContent
    : `data:image;base64,${fileContent}`;

export const PrintForm = ({ saveSuccessTick }: PrintFormProps) => {
  const { restoredInstructionData } = useRestoredInstructionContext();
  const { getDisplayName, isLoadingFileNames } =
    useInstructionExtractedFileNames();
  const getFilePreviewUUID = useMemo(() => UUID(), []);
  const getFileBase64UUID = useMemo(() => UUID(), []);
  const [filePreview, setFilePreview] = useState('');
  const [filePreviewName, setFilePreviewName] = useState('');
  const [isLoadingPreview, setIsLoadingPreview] = useState(false);

  const previewInFlightRef = useRef(false);
  const base64InFlightRef = useRef(false);
  const handledPreviewNotificationRef = useRef(false);
  const handledBase64NotificationRef = useRef(false);

  const subscriptionVariables = useMemo(
    () => ({
      entityTypes: SUBSCRIBE_ALL_ENTITY_TYPES,
    }),
    [],
  );

  const finalizePreview = useCallback(() => {
    previewInFlightRef.current = false;
    setIsLoadingPreview(false);
  }, []);

  useEntityNotificationsSubscription({
    variables: subscriptionVariables,
    shouldResubscribe: true,
    onData: ({ data }) => {
      const notification = data.data?.entityNotifications;
      if (!notification) return;

      if (
        notification.correlationId === getFilePreviewUUID &&
        previewInFlightRef.current &&
        !handledPreviewNotificationRef.current
      ) {
        handledPreviewNotificationRef.current = true;
        finalizePreview();

        if (notification.error) {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: decodeOperationError(notification.error, 'instruction'),
          });
          return;
        }

        const payload = parseFilePayloadFromExtensions(notification.extensions);
        if (payload) {
          setFilePreviewName(payload.fileName);
          setFilePreview(payload.fileContent);
        }
        return;
      }

      if (
        notification.correlationId === getFileBase64UUID &&
        base64InFlightRef.current &&
        !handledBase64NotificationRef.current
      ) {
        handledBase64NotificationRef.current = true;
        base64InFlightRef.current = false;

        if (notification.error) {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: decodeOperationError(notification.error, 'instruction'),
          });
          return;
        }

        const payload = parseFilePayloadFromExtensions(notification.extensions);
        if (payload) {
          const link = document.createElement('a');
          const fileNameWithExt = payload.fileFormat
            ? `${payload.fileName}.${payload.fileFormat}`
            : payload.fileName;
          link.download = sanitizeFileName(fileNameWithExt || 'file');
          link.href = payload.fileContent.startsWith('data:')
            ? payload.fileContent
            : `data:application/${payload.fileFormat || 'octet-stream'};base64,${payload.fileContent}`;
          link.click();
          link.remove();
        }
      }
    },
    onError: () => {
      if (
        previewInFlightRef.current &&
        !handledPreviewNotificationRef.current
      ) {
        handledPreviewNotificationRef.current = true;
        finalizePreview();
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: 'Не удалось получить превью файла',
        });
      }
      if (base64InFlightRef.current && !handledBase64NotificationRef.current) {
        handledBase64NotificationRef.current = true;
        base64InFlightRef.current = false;
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: 'Не удалось скачать файл',
        });
      }
    },
  });

  const restoredFiles =
    restoredInstructionData?.instructionType?.files?.filter(
      (file: IrcInstructionTypeFile) => file?.fileSourceType?.id !== 2,
    ) || [];

  const [files, setFiles] = useState<IrcInstructionTypeFile[]>([]);

  useEffect(() => {
    setFiles(restoredFiles || []);
    // При смене типа инструкции сбрасываем текущее превью файла
    setFilePreview('');
    setFilePreviewName('');
  }, [restoredInstructionData?.instructionType]);

  useEffect(() => {
    if (!saveSuccessTick) return;
    setFilePreview('');
    setFilePreviewName('');
    setIsLoadingPreview(false);
  }, [saveSuccessTick]);

  const [getIrcFilePreviewMutation] = useGetIrcFilePreviewMutation();
  const [getIrcFileBase64Mutation] = useGetIrcFileBase64Mutation();
  const handleGetFilePreview = (fileInfo: IrcInstructionTypeFile) => {
    if (!restoredInstructionData?.id || !fileInfo?.id) {
      return;
    }
    previewInFlightRef.current = true;
    handledPreviewNotificationRef.current = false;
    setIsLoadingPreview(true);
    setFilePreview('');
    setFilePreviewName('');
    getIrcFilePreviewMutation({
      variables: {
        input: {
          correlationId: getFilePreviewUUID,
          id: restoredInstructionData.id,
          instructionTypeFileId: fileInfo.id,
        },
      },
    });
  };

  const handleGetFileBase64 = (fileInfo: IrcInstructionTypeFile) => {
    if (!restoredInstructionData?.id || !fileInfo?.id) {
      return;
    }
    base64InFlightRef.current = true;
    handledBase64NotificationRef.current = false;
    getIrcFileBase64Mutation({
      variables: {
        input: {
          correlationId: getFileBase64UUID,
          id: restoredInstructionData.id,
          instructionTypeFileId: fileInfo.id,
        },
      },
    });
  };

  return (
    <Box className="flex flex-column gap-2 flex-grow-1 overflow-auto">
      <div
        className="grid row-gap-1 align-items-start"
        style={{ maxWidth: '1440px', width: '100%' }}
      >
        <div className={`flex flex-column col-5 ${styles.filesColumn}`}>
          <Typography className="mb-4" fontStyle={10} fontWeight={700}>
            Список файлов:
          </Typography>
          <DataTable
            dataKey="id"
            value={files}
            size="small"
            loading={isLoadingFileNames && files.length > 0}
            emptyMessage="Нет файлов"
            selectionMode="single"
          >
            <Column
              style={{ width: '5%' }}
              body={rowData => {
                return (
                  <Button
                    className="gap-0 ml-2"
                    size="small"
                    variant="primary"
                    icon="pi pi-download"
                    onClick={() => handleGetFileBase64(rowData)}
                  ></Button>
                );
              }}
            ></Column>
            <Column
              header="Наименование файла"
              body={rowData => getDisplayName(rowData) || 'Файл'}
              style={{ width: '70%' }}
            ></Column>
            <Column
              header="Формат"
              body={rowData => rowData?.fileFormat?.name}
              style={{ width: '20%' }}
            ></Column>
            <Column
              style={{ width: '5%' }}
              body={rowData => {
                return (
                  <Button
                    className="gap-0 ml-2"
                    size="small"
                    variant="primary"
                    icon="pi pi-search"
                    onClick={() => handleGetFilePreview(rowData)}
                  ></Button>
                );
              }}
            ></Column>
          </DataTable>
        </div>
        <div className="flex flex-column col-7">
          <Typography
            className="mb-4 text-center"
            fontStyle={10}
            fontWeight={700}
          >
            {filePreviewName}
          </Typography>
          <div className={styles.previewContainer}>
            {isLoadingPreview ? (
              <div
                className="flex align-items-center justify-content-center"
                style={{ height: '100%' }}
              >
                <Loader variant="icon" size="large" color="blue" />
              </div>
            ) : filePreview ? (
              <img src={toPreviewSrc(filePreview)} />
            ) : (
              ''
            )}
          </div>
        </div>
      </div>
    </Box>
  );
};
