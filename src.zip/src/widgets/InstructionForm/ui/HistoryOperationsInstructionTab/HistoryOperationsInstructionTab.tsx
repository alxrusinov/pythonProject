import { useParams } from 'react-router-dom';

import { Box, Column } from 'shared_ui/components';
import { DataTable } from 'shared_ui/primereact';
import { formatDateWithTime } from 'shared_ui/utils';

import { useGetInstructionOperations } from 'widgets/InstructionForm/model/useGetInstructionOperations';

export const HistoryOperationsInstructionTab = () => {
  const { masterId } = useParams();
  if (!masterId) {
    return null;
  }

  const { operations } = useGetInstructionOperations(true);

  return (
    <Box className="flex flex-column gap-2 flex-grow-1 max-w-full overflow-auto">
      <DataTable
        dataKey="id"
        value={operations}
        size="small"
        tableStyle={{ minWidth: '50rem' }}
        emptyMessage="Нет операций"
        selectionMode="single"
      >
        <Column
          body={rowData => formatDateWithTime(rowData.date)}
          header="Дата"
          style={{ width: '20%' }}
        ></Column>
        <Column
          header="Пользователь"
          body={rowData => {
            const user = rowData.user;
            if (!user?.shortName) return null;
            return (
              <span title={user.fullName ?? undefined}>{user.shortName}</span>
            );
          }}
          style={{ width: '50%' }}
        ></Column>
        <Column
          header="Операция"
          body={rowData => {
            return rowData?.operation?.name;
          }}
          style={{ width: '30%' }}
        ></Column>
      </DataTable>
    </Box>
  );
};
