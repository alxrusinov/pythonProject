import { Controller, useFormContext } from 'react-hook-form';

import { InputText, Select, Typography } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetInstructionAccompTextsApi } from 'widgets/InstructionForm/model/useGetInstructionAccompTextsApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

import { AutoResizeTextArea } from 'shared/ui/AutoResizeTextArea';
import { FormField } from 'shared/ui/FormField';

export const IrcAdditionalInfoFields = () => {
  const { control, formState } = useFormContext<CreateInstructionFormValues>();
  const { restoredInstructionData } = useRestoredInstructionContext();
  const { isDisabled } = useIsInstructionDisabled();
  const { handleChangeAccompText } = useInputInstructionDataTab();

  const { accompTexts, handleChangeAccompTextSearch } =
    useGetInstructionAccompTextsApi({
      restoredAccompText: restoredInstructionData?.accompText || null,
    });

  return (
    <div>
      <Typography className="mb-2" fontStyle={10} fontWeight={700}>
        Дополнительные сведения
      </Typography>

      <FormField
        label="Сопроводительный текст"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.ACCOMP_TEXT
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionDataTabFieldName(
            CREATE_INSTRUCTION_FORM_NAMES.ACCOMP_TEXT,
          )}
          control={control}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40 }}
              placeholder="Выберите сопроводительный текст"
              value={field.value}
              options={accompTexts}
              onChange={(e: DropdownChangeEvent) =>
                handleChangeAccompText(e, field.onChange)
              }
              onFilter={(e: DropdownFilterEvent) => {
                handleChangeAccompTextSearch(e.filter);
              }}
              optionLabel="text"
              dataKey="id"
              filter
              showClear
              disabled={isDisabled}
            />
          )}
        />
      </FormField>

      {/* <FormField
        label="Номер договора на поставку"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.NOT_FOR_CARRIER_TEXT
          ]?.message
        }
      >
        <InputText
          className="w-full"
          placeholder=""
          {...register(
            getInputInstructionDataTabFieldName(
              CREATE_INSTRUCTION_FORM_NAMES.NOT_FOR_CARRIER_TEXT,
            ),
          )}
          disabled={isDisabled}
        />
      </FormField> */}
      <FormField label="Комментарий к грузу" alignItems="start">
        <Controller
          name={getInputInstructionDataTabFieldName(
            CREATE_INSTRUCTION_FORM_NAMES.OPTIONAL_MARKS_TEXT,
          )}
          control={control}
          render={({ field }) => (
            <AutoResizeTextArea
              placeholder="Комментарий"
              value={field.value ?? ''}
              onChange={field.onChange}
              onBlur={field.onBlur}
              ref={field.ref}
              disabled={isDisabled}
            />
          )}
        />
      </FormField>
      <FormField label="Комментарий к email" alignItems="start">
        <Controller
          name={getInputInstructionDataTabFieldName(
            CREATE_INSTRUCTION_FORM_NAMES.CLIENT_EMAIL_TEXT,
          )}
          control={control}
          render={({ field }) => (
            <AutoResizeTextArea
              placeholder="Комментарий"
              value={field.value ?? ''}
              onChange={field.onChange}
              onBlur={field.onBlur}
              ref={field.ref}
              disabled={isDisabled}
            />
          )}
        />
      </FormField>
    </div>
  );
};
