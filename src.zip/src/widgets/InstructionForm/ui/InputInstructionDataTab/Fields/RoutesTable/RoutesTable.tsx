import {
  IrcInstructionRoute,
  NsiStation,
  useEntityNotificationsSubscription,
} from 'graphql/generated/generated';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useFormContext } from 'react-hook-form';

import {
  Button,
  CheckBox,
  Column,
  makeNotification,
} from 'shared_ui/components';
import { DataTable } from 'shared_ui/primereact';
import { UUID } from 'shared_ui/utils';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetIrcInstructionRoutes } from 'widgets/InstructionForm/model/useGetIrcInstructionRoutes';
import { useGetRoutesStationsInfoApi } from 'widgets/InstructionForm/model/useGetRoutesStationsInfoApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

import { decodeOperationError } from 'shared/utils/decodeOperationError';
import { getEntityNotificationExtensionValue } from 'shared/utils/entityNotificationExtensions';

import { EditRouteModal } from '../EditRouteModal';
import styles from './RoutesTable.module.scss';

const NTS_RF_PAYER_ID = 220287;
const NTS_RF_PAYER_NAME = 'АО "НефтеТрансСервис"';
const NTS_RF_PAYER_CODE = '1002218840';

const NTS_BY_PAYER_NAME = 'Белинтертранс';
const NTS_BY_PAYER_CODE = '2000436';
const NTS_BY_PAYER_SUBCODE = '1048172';

const NTS_KZ_PAYER_NAME = 'ТОО «АзияНефтеТранс»';
const NTS_KZ_PAYER_CODE = '4595586';
const NTS_KZ_TRANSIT_SUBCODE = '2734776';
const NTS_KZ_NON_TRANSIT_SUBCODE = '2764401';

const normalizeCountryValue = (value?: string | null): string => {
  return (value ?? '').trim().toLowerCase();
};

const isKazakhstanCountry = (countryName?: string | null): boolean => {
  const v = normalizeCountryValue(countryName);
  return v === 'казахстан' || v === 'кз' || v.includes('казах');
};

const isRussianCountry = (countryName?: string | null): boolean => {
  const v = normalizeCountryValue(countryName);
  return v === 'россия' || v === 'рф' || v.includes('росс');
};

const isBelarusCountry = (countryName?: string | null): boolean => {
  const v = normalizeCountryValue(countryName);
  return v === 'беларусь' || v === 'рб' || v.includes('беларус');
};

const getRoutePayerDisplayName = (route: IrcInstructionRoute): string => {
  const manualName = route?.manualPayerName?.trim();
  if (manualName) {
    return manualName;
  }

  const payer = route?.payer;
  if (!payer) {
    return '';
  }

  return (payer.name ?? payer.shortName ?? '').trim();
};

// Ответы по WS могут приходить с другим entityType.
const SUBSCRIBE_ALL_ENTITY_TYPES: string[] | undefined = undefined;

export const RoutesTable = () => {
  const { watch } = useFormContext<CreateInstructionFormValues>();
  const { restoredInstructionData } = useRestoredInstructionContext();
  const { isDisabled } = useIsInstructionDisabled();

  const { handleRoutesChange } = useInputInstructionDataTab();

  // Вычисляем restoredRoutes с правильным hidePayer
  // Сначала сортируем по sequenceNumber, затем вычисляем hidePayer
  const restoredRoutes = useMemo(() => {
    if (!restoredInstructionData?.routes) {
      return restoredInstructionData?.routes;
    }
    const sorted = [...restoredInstructionData.routes].sort(
      (a, b) => (a.sequenceNumber ?? 0) - (b.sequenceNumber ?? 0),
    );
    let countryNameFilter = '';
    return sorted.map(route => {
      const currentCountryName = route?.station?.country?.name ?? '';
      const isHidePayer = countryNameFilter === currentCountryName;

      if (!isHidePayer) {
        countryNameFilter = currentCountryName;
      }
      return {
        ...route,
        hidePayer: isHidePayer,
      };
    });
  }, [restoredInstructionData?.routes]);

  const routesFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.ROUTES,
  );
  const senderFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION,
  );
  const recieverFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION,
  );

  // Используем watch для отслеживания изменений полей формы
  const formRoutes = watch(routesFieldName);
  const formSenderStation = watch(senderFieldName);
  const formRecieverStation = watch(recieverFieldName);

  const getRoutesUUID = useMemo(() => UUID(), []);
  const routesInFlightRef = useRef(false);
  const handledRoutesNotificationRef = useRef(false);

  type RailTarifRoute = {
    stId: string | number;
    sequenceNumber?: number;
  };
  const [railTarifData, setRailTarifData] = useState<RailTarifRoute[]>([]);
  const [stationIds, setStationIds] = useState<number[]>([]);
  const [routes, setRoutes] = useState<IrcInstructionRoute[]>([]);
  const [isLoadingRoutes, setIsLoadingRoutes] = useState(false);
  const isInitialized = useRef(false);

  const subscriptionVariables = useMemo(
    () => ({
      entityTypes: SUBSCRIBE_ALL_ENTITY_TYPES,
    }),
    [],
  );

  useEntityNotificationsSubscription({
    variables: subscriptionVariables,
    shouldResubscribe: true,
    onData: ({ data }) => {
      const notification = data.data?.entityNotifications;
      if (!notification) return;
      if (!routesInFlightRef.current) return;
      if (notification.correlationId !== getRoutesUUID) return;
      if (handledRoutesNotificationRef.current) return;

      handledRoutesNotificationRef.current = true;
      routesInFlightRef.current = false;
      setIsLoadingRoutes(false);

      if (notification.error) {
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: decodeOperationError(notification.error, 'instruction'),
        });
        return;
      }

      const routesExtension = getEntityNotificationExtensionValue(
        notification.extensions,
        'routes',
      );
      const routesList = Array.isArray(routesExtension) ? routesExtension : [];

      setStationIds(
        routesList.map((route: { stId: string | number }) => {
          return Number(route.stId);
        }),
      );
      setRailTarifData(routesList);
    },
    onError: () => {
      if (!routesInFlightRef.current) return;
      handledRoutesNotificationRef.current = true;
      routesInFlightRef.current = false;
      setIsLoadingRoutes(false);
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Не удалось рассчитать маршрут',
      });
    },
  });

  // Функция для пересчета hidePayer для маршрутов
  const recalculateHidePayer = (
    routesToProcess: IrcInstructionRoute[],
  ): IrcInstructionRoute[] => {
    let countryNameFilter = '';
    return routesToProcess.map(route => {
      const currentCountryName = route?.station?.country?.name ?? '';
      const isHidePayer = countryNameFilter === currentCountryName;

      if (!isHidePayer) {
        countryNameFilter = currentCountryName;
      }

      return {
        ...route,
        hidePayer: isHidePayer,
      };
    });
  };

  // Инициализация маршрутов из restoredInstructionData
  useEffect(() => {
    if (restoredRoutes && restoredRoutes.length > 0) {
      setRoutes(restoredRoutes);
      isInitialized.current = true;
    } else if (restoredRoutes && restoredRoutes.length === 0) {
      // Если restoredRoutes пуст, очищаем локальное состояние
      setRoutes([]);
      isInitialized.current = true;
    } else if (!restoredInstructionData) {
      // Если нет данных для восстановления, помечаем как инициализированное
      isInitialized.current = true;
    }
  }, [restoredInstructionData?.routes, restoredRoutes]);

  // Обновление маршрутов при изменении формы (только после инициализации)
  useEffect(() => {
    // Пропускаем обновления во время инициализации
    if (!isInitialized.current) {
      return;
    }

    if (formRoutes) {
      if (formRoutes.length > 0) {
        // Сортируем маршруты перед пересчетом hidePayer
        const sortedRoutes = [...formRoutes].sort(
          (a, b) => (a.sequenceNumber ?? 0) - (b.sequenceNumber ?? 0),
        );
        // Пересчитываем hidePayer для маршрутов из формы
        const routesWithHidePayer = recalculateHidePayer(sortedRoutes);

        setRoutes(routesWithHidePayer);
      } else {
        // Если маршруты очищены, очищаем локальное состояние
        setRoutes([]);
      }
    }
  }, [formRoutes]);

  const [senderStation, setSenderStation] = useState<NsiStation | null>(null);

  useEffect(() => {
    const station =
      formSenderStation || restoredInstructionData?.senderStation || null;
    setSenderStation(station);
  }, [formSenderStation, restoredInstructionData?.senderStation]);

  const [recieverStation, setRecieverStation] = useState<NsiStation | null>(
    null,
  );

  useEffect(() => {
    const station =
      formRecieverStation || restoredInstructionData?.receiverStation || null;
    setRecieverStation(station);
  }, [formRecieverStation, restoredInstructionData?.receiverStation]);

  const { getRoutes } = useGetIrcInstructionRoutes({
    correlationId: getRoutesUUID,
    senderStationId: senderStation?.id || null,
    receiverStationId: recieverStation?.id || null,
  });

  const { routesStations } = useGetRoutesStationsInfoApi({
    stationIds,
  });

  useEffect(() => {
    //Когда получили станции, формируем массив routes для таблицы
    if (railTarifData?.length > 0 && routesStations?.length > 0) {
      const newRoutesInfo: IrcInstructionRoute[] = railTarifData.map(route => {
        const stationInfoByRoute = routesStations.find(
          station => station?.id === route?.stId,
        );

        const stIdNumber =
          route?.stId != null
            ? typeof route.stId === 'number'
              ? route.stId
              : Number(route.stId) || null
            : null;
        return {
          id: UUID(),
          station: { ...stationInfoByRoute },
          sequenceNumber: route?.sequenceNumber,
          stId: stIdNumber,
          manualRecipAddress: null,
          manualRecipName: null,
          manualRecipOkpo: null,
          manualRecipTgnl: null,
          manualPayerSubCode: null,
          manualPayerName: null,
          manualPayerCode: null,
          ntsPayerFlag: false,
          payer: null,
          hidePayer: false, // Временно, будет пересчитано ниже
        } as IrcInstructionRoute;
      });

      const sortedRoutes = newRoutesInfo.sort(
        (a, b) => (a.sequenceNumber ?? 0) - (b.sequenceNumber ?? 0),
      );
      // Пересчитываем hidePayer после сортировки
      const routesWithHidePayer = recalculateHidePayer(sortedRoutes);
      setRoutes(routesWithHidePayer);
      handleRoutesChange(routesWithHidePayer);
    }
  }, [routesStations, railTarifData]);

  const handleChangeRouteNtsFlag = (
    selectedRoute: IrcInstructionRoute,
    value: boolean,
  ) => {
    const selectedRouteCountry = selectedRoute?.station?.country?.name ?? '';
    const senderCountry = senderStation?.country?.name ?? '';
    const receiverCountry = recieverStation?.country?.name ?? '';

    const isTransitViaKazakhstan =
      !isKazakhstanCountry(senderCountry) &&
      !isKazakhstanCountry(receiverCountry);

    const modifiedRoutes = routes
      .map(route => {
        if (route?.id === selectedRoute?.id) {
          const isNtsActivatedNow = !route?.ntsPayerFlag && value === true;

          if (value === false) {
            return {
              ...route,
              ntsPayerFlag: false,
              payer: null,
              manualPayerName: '',
              manualPayerCode: '',
              manualPayerSubCode: '',
            };
          }

          if (isNtsActivatedNow && isRussianCountry(selectedRouteCountry)) {
            return {
              ...route,
              ntsPayerFlag: true,
              payer: {
                id: NTS_RF_PAYER_ID,
                name: NTS_RF_PAYER_NAME,
                orgPayer: {
                  code: NTS_RF_PAYER_CODE,
                },
              },
              manualPayerName: '',
              manualPayerCode: '',
              manualPayerSubCode: '',
            } as IrcInstructionRoute;
          }

          if (isNtsActivatedNow && isBelarusCountry(selectedRouteCountry)) {
            return {
              ...route,
              ntsPayerFlag: true,
              payer: null,
              manualPayerName: NTS_BY_PAYER_NAME,
              manualPayerCode: NTS_BY_PAYER_CODE,
              manualPayerSubCode: NTS_BY_PAYER_SUBCODE,
            };
          }

          if (isNtsActivatedNow && isKazakhstanCountry(selectedRouteCountry)) {
            return {
              ...route,
              ntsPayerFlag: true,
              payer: null,
              manualPayerName: NTS_KZ_PAYER_NAME,
              manualPayerCode: NTS_KZ_PAYER_CODE,
              manualPayerSubCode: isTransitViaKazakhstan
                ? NTS_KZ_TRANSIT_SUBCODE
                : NTS_KZ_NON_TRANSIT_SUBCODE,
            };
          }

          return {
            ...route,
            ntsPayerFlag: value,
            // Для других стран сохраняем текущее поведение:
            // пользователь заполняет плательщика вручную в модальном окне.
          };
        }
        return route;
      })
      .sort((a, b) => (a.sequenceNumber ?? 0) - (b.sequenceNumber ?? 0));
    // Пересчитываем hidePayer после изменения
    const routesWithHidePayer = recalculateHidePayer(modifiedRoutes);
    setRoutes(routesWithHidePayer);
    handleRoutesChange(routesWithHidePayer);
  };

  const handleChangeRoute = (changedRoute: IrcInstructionRoute) => {
    const modifiedRoutes = routes
      .map(route => {
        if (route?.id === changedRoute?.id) {
          return {
            ...changedRoute,
          };
        }
        return route;
      })
      .sort((a, b) => (a.sequenceNumber ?? 0) - (b.sequenceNumber ?? 0));

    // Пересчитываем hidePayer после изменения маршрута
    // (на случай, если изменилась станция и соответственно страна)
    const routesWithHidePayer = recalculateHidePayer(modifiedRoutes);
    setRoutes(routesWithHidePayer);
    handleRoutesChange(routesWithHidePayer);
  };

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<IrcInstructionRoute>();

  return (
    <>
      {selectedRoute && (
        <EditRouteModal
          visible={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          route={selectedRoute}
          handleChangeRoutes={handleChangeRoute}
        />
      )}
      <div>
        <Button
          size="small"
          variant="primary"
          className="mb-2"
          onClick={() => {
            routesInFlightRef.current = true;
            handledRoutesNotificationRef.current = false;
            setIsLoadingRoutes(true);
            getRoutes();
            setRailTarifData([]);
          }}
          disabled={
            !(formSenderStation?.id && formRecieverStation?.id) ||
            isLoadingRoutes ||
            isDisabled ||
            routes.length > 0
          }
        >
          Расчет маршрута
        </Button>
      </div>
      <DataTable
        loading={isLoadingRoutes}
        dataKey="id"
        value={routes}
        size="small"
        tableStyle={{ minWidth: '80rem', minHeight: '100px' }}
        emptyMessage="Нет маршрутов"
      >
        <Column
          header="Станция"
          body={rowData => rowData?.station?.name}
          style={{ width: '20%' }}
        ></Column>
        <Column
          header="Код станции"
          body={rowData => rowData?.station?.code}
          style={{ width: '10%' }}
        ></Column>
        <Column
          header="Дорога"
          body={rowData => rowData?.station?.railway?.name}
          style={{ width: '10%' }}
        ></Column>
        <Column
          header="Страна"
          body={rowData => rowData?.station?.country?.name}
          style={{ width: '10%' }}
        ></Column>
        <Column
          header="Платит НТС"
          style={{ width: '5%' }}
          body={rowData => {
            return (
              <div className={styles.checkboxContainer}>
                <CheckBox
                  disabled={rowData?.hidePayer || isDisabled}
                  checked={rowData?.ntsPayerFlag}
                  onChange={e =>
                    handleChangeRouteNtsFlag(rowData, e.checked ?? false)
                  }
                />
              </div>
            );
          }}
        ></Column>
        <Column
          header="Плательщик"
          body={rowData => {
            const payerName = getRoutePayerDisplayName(rowData);

            return (
              <div className={styles.payerCell}>
                <span className={styles.editPayerBtnWrapper}>
                  <Button
                    className={styles.editPayerBtn}
                    size="small"
                    variant="primary"
                    disabled={
                      rowData?.hidePayer || !rowData?.ntsPayerFlag || isDisabled
                    }
                    icon="pi pi-pencil"
                    onClick={() => {
                      setSelectedRoute(rowData);
                      setIsModalOpen(true);
                    }}
                  />
                </span>
                <span className={styles.payerName}>{payerName}</span>
              </div>
            );
          }}
          style={{ width: '15%' }}
        ></Column>
        <Column
          header="Код"
          body={rowData => {
            return rowData?.manualPayerCode
              ? rowData?.manualPayerCode
              : rowData?.payer?.orgPayer?.code;
          }}
          style={{ width: '10%' }}
        ></Column>
        <Column
          header="Подкод"
          body={rowData => rowData?.manualPayerSubCode}
          style={{ width: '10%' }}
        ></Column>
      </DataTable>
    </>
  );
};
