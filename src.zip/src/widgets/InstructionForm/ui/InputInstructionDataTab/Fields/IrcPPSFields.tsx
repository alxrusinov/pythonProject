// import { PpsContract } from 'graphql/generated/generated';
// import { useEffect, useState } from 'react';
// import { Controller, useFormContext } from 'react-hook-form';

// import { Select, Typography } from 'shared_ui/components';
// import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

// import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
// import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
// import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
// import { useGetInstructionPpsContractsApi } from 'widgets/InstructionForm/model/useGetInstructionPpsContractsApi';
// import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
// // import { useRestoredInstructionContext } from "widgets/InstructionForm/model/useRestoredInstructionContext";
// import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

// import { FormField } from 'shared/ui/FormField';

// export const IrcPPSFields = () => {
//   const { control, formState, getValues } =
//     useFormContext<CreateInstructionFormValues>();
//   const { isDisabled } = useIsInstructionDisabled();
//   const ppsContractFieldName = getInputInstructionDataTabFieldName(
//     CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_PPS,
//   );
//   const [restoredPpsContract, setRestoredPpsContract] =
//     useState<PpsContract | null>(null);

//   useEffect(() => {
//     const ppsContractValue = getValues(ppsContractFieldName);
//     setRestoredPpsContract(ppsContractValue ?? restoredPpsContract ?? null);
//   }, [getValues(ppsContractFieldName), restoredPpsContract]);

//   // const { restoredInstructionData } = useRestoredInstructionContext();
//   const { handleChangePpsContract } = useInputInstructionDataTab();

//   const { ppsContracts, handleChangePpsContractSearch } =
//     useGetInstructionPpsContractsApi({
//       restoredPpsContract: restoredPpsContract || null,
//     });

//   return (
//     <div>
//       <Typography className="mb-2" fontStyle={10} fontWeight={700}>
//         Договор ППС
//       </Typography>

//       <FormField
//         label="Договор ППС"
//         errorMessage={
//           formState.errors?.inputInstructionDataTab?.[
//             CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_PPS
//           ]?.message
//         }
//       >
//         <Controller
//           name={getInputInstructionDataTabFieldName(
//             CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_PPS,
//           )}
//           control={control}
//           render={({ field }) => (
//             <Select
//               panelStyle={{ width: '320px' }}
//               wrapOptions={true}
//               style={{ height: 40 }}
//               placeholder="Выберите договор"
//               value={field.value}
//               options={ppsContracts}
//               onChange={(e: DropdownChangeEvent) =>
//                 handleChangePpsContract(e, field.onChange)
//               }
//               onFilter={(e: DropdownFilterEvent) => {
//                 handleChangePpsContractSearch(e.filter);
//               }}
//               optionLabel="contractName"
//               dataKey="id"
//               filter
//               showClear
//               disabled={isDisabled}
//             />
//           )}
//         />
//       </FormField>
//     </div>
//   );
// };
