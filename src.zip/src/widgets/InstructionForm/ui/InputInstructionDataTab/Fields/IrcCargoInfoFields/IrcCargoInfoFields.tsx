import { NsiFreight, NsiGngFreight2001 } from 'graphql/generated/generated';
import { useEffect, useState } from 'react';
import { Controller, useFormContext, useWatch } from 'react-hook-form';

import { Select, Typography } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetInstructionFreightsApi } from 'widgets/InstructionForm/model/useGetInstructionFreightsApi';
import { useGetInstructionGngFreightsApi } from 'widgets/InstructionForm/model/useGetInstructionGngFreightsApi';
import { useGetInstructionPrevFreightsApi } from 'widgets/InstructionForm/model/useGetInstructionPrevFreightsApi';
import { useGetInstructionPrevGngFreightsApi } from 'widgets/InstructionForm/model/useGetInstructionPrevGngFreightsApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';
import { useFieldsPrefilling } from 'widgets/InstructionForm/store';

import { FormField } from 'shared/ui/FormField';
import { compareRecords } from 'shared/utils/compareRecords';

import styles from './IrcCargoInfoFields.module.scss';

export const IrcCargoInfoFields = () => {
  const { control, formState, getValues, setValue } =
    useFormContext<CreateInstructionFormValues>();
  const { restoredInstructionData } = useRestoredInstructionContext();
  const { isDisabled } = useIsInstructionDisabled();

  const prevFreightFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_FREIGHT,
  );
  const prevGngFreightFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_GNG_FREIGHT,
  );
  const [restoredPrevFreight, setRestoredPrevFreight] =
    useState<NsiFreight | null>(null);
  const [restoredPrevGngFreight, setRestoredPrevGngFreight] =
    useState<NsiGngFreight2001 | null>(null);

  const preFillingFields = useFieldsPrefilling(state => state.preFillingFields);
  const resetCustomPrevFreight = useFieldsPrefilling(
    state => state.resetCustomPrevFreight,
  );
  const resetCustomPrevGngFreight = useFieldsPrefilling(
    state => state.resetCustomPrevGngFreight,
  );

  const [currentFreight, curentGngFreight] = useWatch({
    name: [prevFreightFieldName, prevGngFreightFieldName],
    control,
  });

  useEffect(() => {
    const prevFreightValue = getValues(prevFreightFieldName);
    setRestoredPrevFreight(prevFreightValue ?? restoredPrevFreight ?? null);
    const prevGngFreightValue = getValues(prevGngFreightFieldName);
    setRestoredPrevGngFreight(
      prevGngFreightValue ?? restoredPrevGngFreight ?? null,
    );
  }, [
    getValues(prevFreightFieldName),
    getValues(prevGngFreightFieldName),
    restoredPrevFreight,
    restoredPrevGngFreight,
  ]);

  const {
    handleChangeGngFreight,
    handleChangeFreight,
    handleChangePrevGngFreight,
    handleChangePrevFreight,
  } = useInputInstructionDataTab();

  const { prevFreights, handleChangePrevFreightSearch } =
    useGetInstructionPrevFreightsApi({
      restoredPrevFreight:
        restoredPrevFreight || preFillingFields?.customPrevFreight || null,
    });
  const { prevGngFreights, handleChangePrevGngFreightSearch } =
    useGetInstructionPrevGngFreightsApi({
      restoredPrevGngFreight:
        restoredPrevGngFreight ||
        preFillingFields?.customPrevGngFreight ||
        null,
    });

  const { freights, handleChangeFreightSearch } = useGetInstructionFreightsApi({
    restoredFreight: restoredInstructionData?.freight || null,
  });
  const { gngFreights, handleChangeGngFreightSearch } =
    useGetInstructionGngFreightsApi({
      restoredGngFreight: restoredInstructionData?.gngFreight || null,
    });

  useEffect(() => {
    if (preFillingFields?.customPrevFreight && !currentFreight) {
      setValue(prevFreightFieldName, preFillingFields.customPrevFreight, {
        shouldDirty: false,
      });
    }
  }, [preFillingFields?.customPrevFreight, currentFreight]);

  useEffect(() => {
    if (preFillingFields?.customPrevGngFreight && !curentGngFreight) {
      setValue(prevGngFreightFieldName, preFillingFields.customPrevGngFreight, {
        shouldDirty: false,
      });
    }
  }, [preFillingFields?.customPrevGngFreight, curentGngFreight]);

  return (
    <div>
      <Typography className="mb-2" fontStyle={10} fontWeight={700}>
        Информация о грузах
      </Typography>

      <FormField
        label="Предыдущий груз ЕТСНГ"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_FREIGHT
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionDataTabFieldName(
            CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_FREIGHT,
          )}
          control={control}
          render={({ field }) => (
            <div className={styles.inputBlock}>
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                placeholder="Выберите груз"
                value={field.value}
                options={
                  field.value
                    ? compareRecords(prevFreights, field.value)
                    : prevFreights
                }
                onChange={(e: DropdownChangeEvent) => {
                  if (!e.value) {
                    resetCustomPrevFreight();
                  }
                  handleChangePrevFreight(e, field.onChange);
                }}
                onFilter={(e: DropdownFilterEvent) => {
                  handleChangePrevFreightSearch(e.filter);
                }}
                optionLabel="name"
                filterBy="name,codeEtsng"
                dataKey="id"
                filter
                showClear
                disabled={isDisabled}
              />
              <div className={styles.inputText}>{field.value?.codeEtsng}</div>
            </div>
          )}
        />
      </FormField>

      <FormField
        label="Предыдущий груз ГНГ"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_GNG_FREIGHT
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionDataTabFieldName(
            CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_GNG_FREIGHT,
          )}
          control={control}
          render={({ field }) => (
            <div className={styles.inputBlock}>
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                placeholder="Выберите груз"
                value={field.value}
                options={
                  field.value
                    ? compareRecords(prevGngFreights, field.value)
                    : prevGngFreights
                }
                onChange={(e: DropdownChangeEvent) => {
                  if (!e.value) {
                    resetCustomPrevGngFreight();
                  }
                  handleChangePrevGngFreight(e, field.onChange);
                }}
                onFilter={(e: DropdownFilterEvent) => {
                  handleChangePrevGngFreightSearch(e.filter);
                }}
                optionLabel="name"
                filterBy="name,code"
                dataKey="id"
                filter
                showClear
                disabled={isDisabled}
              />
              <div className={styles.inputText}>{field.value?.code}</div>
            </div>
          )}
        />
      </FormField>

      <FormField
        label="Текущий груз ЕТСНГ"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.FREIGHT
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionDataTabFieldName(
            CREATE_INSTRUCTION_FORM_NAMES.FREIGHT,
          )}
          control={control}
          render={({ field }) => (
            <div className={styles.inputBlock}>
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                placeholder="Выберите груз"
                value={field.value}
                options={freights}
                onChange={(e: DropdownChangeEvent) =>
                  handleChangeFreight(e, field.onChange)
                }
                onFilter={(e: DropdownFilterEvent) => {
                  handleChangeFreightSearch(e.filter);
                }}
                optionLabel="name"
                filterBy="name,codeEtsng"
                dataKey="id"
                filter
                showClear
                disabled={isDisabled}
              />
              <div className={styles.inputText}>{field.value?.codeEtsng}</div>
            </div>
          )}
        />
      </FormField>

      <FormField
        label="Текущий груз ГНГ"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.GNG_FREIGHT
          ]?.message
        }
      >
        <Controller
          name={getInputInstructionDataTabFieldName(
            CREATE_INSTRUCTION_FORM_NAMES.GNG_FREIGHT,
          )}
          control={control}
          render={({ field }) => (
            <div className={styles.inputBlock}>
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                placeholder="Выберите груз"
                value={field.value}
                options={gngFreights}
                onChange={(e: DropdownChangeEvent) =>
                  handleChangeGngFreight(e, field.onChange)
                }
                onFilter={(e: DropdownFilterEvent) => {
                  handleChangeGngFreightSearch(e.filter);
                }}
                optionLabel="name"
                filterBy="name,code"
                dataKey="id"
                filter
                showClear
                disabled={isDisabled}
              />
              <div className={styles.inputText}>{field.value?.code}</div>
            </div>
          )}
        />
      </FormField>
    </div>
  );
};
