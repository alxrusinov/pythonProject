import { Typography } from 'shared_ui/components';

import styles from './DefaultFields.module.scss';
import { InstructionTypeField } from './InstructionTypeField';
import { ReceiverStationField } from './ReceiverStationField';
import { SenderStationField } from './SenderStationField';
import { StationFromNameField } from './StationFromNameField';

export const DefaultFields = () => {
  return (
    <div className={styles.card}>
      <Typography className="mb-2" fontStyle={10} fontWeight={700}>
        Основная информация
      </Typography>
      <StationFromNameField />
      <SenderStationField />
      <ReceiverStationField />
      <InstructionTypeField />
    </div>
  );
};
