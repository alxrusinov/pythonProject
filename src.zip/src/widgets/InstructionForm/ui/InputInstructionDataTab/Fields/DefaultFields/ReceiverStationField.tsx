import { useState } from 'react';
import { Controller, useFormContext } from 'react-hook-form';

import { Select } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetRecieverNsiStationsApi } from 'widgets/InstructionForm/model/useGetRecieverNsiStationsApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

import { FormField } from 'shared/ui/FormField';

import { RoutesClearModal } from '../RoutesClearModal';
import styles from './DefaultFields.module.scss';
import { getStationOptionLabel } from './utils';

export const ReceiverStationField = () => {
  const { control, formState, getValues, register, setValue } =
    useFormContext<CreateInstructionFormValues>();

  const { restoredInstructionData } = useRestoredInstructionContext();
  const { isDisabled } = useIsInstructionDisabled();

  const { handleReciverStationChange, handleRoutesChange } =
    useInputInstructionDataTab();

  const routesFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.ROUTES,
  );
  const recieverFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION,
  );

  const { recieverSations, handleChangeRecieverSationsSearch } =
    useGetRecieverNsiStationsApi({
      restoredRecieverSations: restoredInstructionData?.receiverStation || null,
    });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [inputSelectedValue, setInputSelectedValue] =
    useState<DropdownChangeEvent>();

  const recieverInput = register(recieverFieldName, { required: true });

  const handleOpenModal = (selectedValue: DropdownChangeEvent) => {
    setInputSelectedValue(selectedValue);

    const currentRoutes = getValues(routesFieldName);

    if (currentRoutes && currentRoutes.length > 0) {
      setIsModalOpen(true);
    } else {
      if (selectedValue) {
        handleReciverStationChange(selectedValue, () =>
          recieverInput.onChange(selectedValue),
        );
      }
    }
  };

  const handleCloseModal = () => {
    if (inputSelectedValue) {
      const recieverPrevValue = getValues(recieverFieldName);
      const opts = { shouldDirty: false };

      // Восстанавливаем предыдущее значение станции без сброса типа инструкции
      setValue(recieverFieldName, recieverPrevValue, opts);
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_ST_ID,
        ),
        recieverPrevValue?.id ?? null,
        opts,
      );
      recieverInput.onChange({
        ...inputSelectedValue,
        target: { ...inputSelectedValue.target, value: recieverPrevValue },
      });
    }

    setIsModalOpen(false);
  };

  const handleSuccessModal = () => {
    if (inputSelectedValue) {
      handleReciverStationChange(inputSelectedValue, () =>
        recieverInput.onChange(inputSelectedValue),
      );
    }

    handleRoutesChange([]);
    setIsModalOpen(false);
  };

  return (
    <>
      <RoutesClearModal
        visible={isModalOpen}
        onClose={handleCloseModal}
        onSuccess={handleSuccessModal}
      />
      <FormField
        label="Назначенная станция"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION
          ]?.message
        }
      >
        <Controller
          name={recieverFieldName}
          control={control}
          rules={{ required: true }}
          render={({ field }) => (
            <div className={styles.inputBlock}>
              <Select
                panelStyle={{ width: '320px' }}
                wrapOptions={true}
                style={{ height: 40 }}
                placeholder="Выберите станцию"
                value={field.value}
                options={recieverSations}
                onChange={(e: DropdownChangeEvent) => {
                  handleOpenModal(e);
                }}
                onFilter={(e: DropdownFilterEvent) => {
                  handleChangeRecieverSationsSearch(e.filter);
                }}
                optionLabel="name"
                itemTemplate={option => getStationOptionLabel(option)}
                valueTemplate={(selected, props) =>
                  selected?.id != null
                    ? getStationOptionLabel(selected)
                    : props.placeholder
                }
                dataKey="id"
                filter
                showClear
                disabled={isDisabled}
              />
              <div className={styles.inputText}>
                {field.value?.railway?.shortName}
              </div>
            </div>
          )}
        />
      </FormField>
    </>
  );
};
