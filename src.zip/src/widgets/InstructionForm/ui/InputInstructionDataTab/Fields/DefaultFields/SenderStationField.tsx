import { useEffect, useState } from 'react';
import { Controller, useFormContext, useWatch } from 'react-hook-form';

import { Select } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetSenderNsiStationsApi } from 'widgets/InstructionForm/model/useGetSenderNsiStationsApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';
import { useFieldsPrefilling } from 'widgets/InstructionForm/store';

import { FormField } from 'shared/ui/FormField';
import { compareRecords } from 'shared/utils/compareRecords';

import { RoutesClearModal } from '../RoutesClearModal';
import styles from './DefaultFields.module.scss';
import { getStationOptionLabel } from './utils';

export const SenderStationField = () => {
  const { control, formState, getValues, register, setValue } =
    useFormContext<CreateInstructionFormValues>();

  const { restoredInstructionData } = useRestoredInstructionContext();
  const { isDisabled, isCorrectionInstruction } = useIsInstructionDisabled();
  const disabledSenderStation = isDisabled || isCorrectionInstruction;

  const { handleSenderStationChange, handleRoutesChange } =
    useInputInstructionDataTab();

  const preFillingFields = useFieldsPrefilling(state => state.preFillingFields);
  const resetSenderStation = useFieldsPrefilling(
    state => state.resetSenderStation,
  );

  const routesFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.ROUTES,
  );
  const senderFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION,
  );

  const currentField = useWatch({ name: senderFieldName, control });

  const { senderSations, handleChangeSenderSationsSearch } =
    useGetSenderNsiStationsApi({
      restoredSenderSations:
        restoredInstructionData?.senderStation ||
        preFillingFields?.senderStation ||
        null,
    });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [inputSelectedValue, setInputSelectedValue] =
    useState<DropdownChangeEvent>();

  const senderInput = register(senderFieldName, { required: true });

  const handleOpenModal = (selectedValue: DropdownChangeEvent) => {
    setInputSelectedValue(selectedValue);

    const currentRoutes = getValues(routesFieldName);

    if (currentRoutes && currentRoutes.length > 0) {
      setIsModalOpen(true);
    } else {
      if (selectedValue) {
        handleSenderStationChange(selectedValue, () =>
          senderInput.onChange(selectedValue),
        );
      }
    }
  };

  const handleCloseModal = () => {
    if (inputSelectedValue) {
      const senderPrevValue = getValues(senderFieldName);
      const opts = { shouldDirty: false };

      // Восстанавливаем предыдущее значение станции без сброса типа инструкции
      setValue(senderFieldName, senderPrevValue, opts);
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.SENDER_ST_ID,
        ),
        senderPrevValue?.id ?? null,
        opts,
      );
      senderInput.onChange({
        ...inputSelectedValue,
        target: { ...inputSelectedValue.target, value: senderPrevValue },
      });
    }

    setIsModalOpen(false);
  };

  const handleSuccessModal = () => {
    if (inputSelectedValue) {
      handleSenderStationChange(inputSelectedValue, () =>
        senderInput.onChange(inputSelectedValue),
      );
    }

    handleRoutesChange([]);
    setIsModalOpen(false);
  };

  useEffect(() => {
    if (preFillingFields?.senderStation && !currentField) {
      const opts = { shouldDirty: false };
      setValue(senderFieldName, preFillingFields.senderStation, opts);
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.SENDER_ST_ID,
        ),
        preFillingFields.senderStation.id ?? null,
        opts,
      );
      senderInput.onChange({
        ...inputSelectedValue,
        target: { value: preFillingFields.senderStation },
      });
    }
  }, [preFillingFields?.senderStation, currentField]);

  return (
    <>
      <RoutesClearModal
        visible={isModalOpen}
        onClose={handleCloseModal}
        onSuccess={handleSuccessModal}
      />
      <FormField
        label="Станция выгрузки"
        errorMessage={
          formState.errors?.inputInstructionDataTab?.[
            CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION
          ]?.message
        }
      >
        <Controller
          name={senderFieldName}
          control={control}
          rules={{ required: true }}
          render={({ field }) => {
            return (
              <div className={styles.inputBlock}>
                <Select
                  panelStyle={{ width: '320px' }}
                  wrapOptions={true}
                  style={{ height: 40 }}
                  placeholder="Выберите станцию"
                  value={field.value}
                  options={
                    field.value
                      ? compareRecords(senderSations, field.value)
                      : senderSations
                  }
                  onChange={(e: DropdownChangeEvent) => {
                    if (!e.value) {
                      resetSenderStation();
                    }
                    handleOpenModal(e);
                  }}
                  onFilter={(e: DropdownFilterEvent) => {
                    handleChangeSenderSationsSearch(e.filter);
                  }}
                  optionLabel="name"
                  itemTemplate={option => getStationOptionLabel(option)}
                  valueTemplate={(selected, props) =>
                    selected?.id != null
                      ? getStationOptionLabel(selected)
                      : props.placeholder
                  }
                  dataKey="id"
                  filter
                  showClear
                  disabled={disabledSenderStation}
                />
                <div className={styles.inputText}>
                  {field.value?.railway?.shortName}
                </div>
              </div>
            );
          }}
        />
      </FormField>
    </>
  );
};
