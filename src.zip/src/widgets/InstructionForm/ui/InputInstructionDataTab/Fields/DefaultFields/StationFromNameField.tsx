import { useEffect } from 'react';
import { useFormContext } from 'react-hook-form';

import { InputText } from 'shared_ui/components';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';
import { useFieldsPrefilling } from 'widgets/InstructionForm/store';

import { FormField } from 'shared/ui/FormField';

export const StationFromNameField = () => {
  const { register, setValue, getValues } =
    useFormContext<CreateInstructionFormValues>();
  const { isDisabled } = useIsInstructionDisabled();
  const preFillingFields = useFieldsPrefilling(state => state.preFillingFields);

  const stationFromNameFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.STATION_FROM_NAME,
  );

  useEffect(() => {
    const currentField = getValues(stationFromNameFieldName);

    if (preFillingFields?.stationFromName && !currentField) {
      setValue(stationFromNameFieldName, preFillingFields.stationFromName, {
        shouldDirty: false,
      });
    }
  }, [preFillingFields, getValues, setValue, stationFromNameFieldName]);

  return (
    <FormField label="Станция погрузки">
      <InputText
        className="w-full"
        placeholder="Введите станцию погрузки"
        {...register(stationFromNameFieldName)}
        disabled={isDisabled}
      />
    </FormField>
  );
};
