export const getStationOptionLabel = (
  station: {
    name?: string;
    railway?: { shortName?: string };
  } | null,
) =>
  station?.name != null
    ? `${station.name}${station?.railway?.shortName ? ` / ${station.railway.shortName}` : ''}`
    : '';
