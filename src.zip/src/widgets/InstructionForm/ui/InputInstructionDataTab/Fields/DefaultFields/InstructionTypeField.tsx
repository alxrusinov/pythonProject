import {
  CalculationType,
  IrcInstructionType,
} from 'graphql/generated/generated';
import { useState } from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { useParams, useSearchParams } from 'react-router-dom';

import { Select } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import {
  CreateInstructionFormValues,
  InstructionParams,
} from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetIrcTypeApi } from 'widgets/InstructionForm/model/useGetIrcTypeApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

import { FormField } from 'shared/ui/FormField';
import { compareRecords } from 'shared/utils/compareRecords';

import { TypeChangeClearModal } from '../TypeChangeClearModal';

export const InstructionTypeField = () => {
  const { control, getValues, watch } =
    useFormContext<CreateInstructionFormValues>();

  const { masterId } = useParams<InstructionParams>();
  const [searchParams] = useSearchParams();
  const copyFrom = searchParams.get('copyFrom');
  const isRestoringInstruction = !!(masterId || copyFrom);

  const { restoredInstructionData, loading: isRestoreLoading } =
    useRestoredInstructionContext();
  const { isDisabled } = useIsInstructionDisabled();
  // Для корректировочной инструкции тип должен быть доступен для изменения
  const disabledType = isDisabled;
  const { handleTypeChange, handleChangeFiles } = useInputInstructionDataTab();

  const userFilesFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.USER_FILES,
  );
  const typeFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.TYPES,
  );

  const senderStation = watch(
    getInputInstructionDataTabFieldName(
      CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION,
    ),
  );
  const receiverStation = watch(
    getInputInstructionDataTabFieldName(
      CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION,
    ),
  );
  const currentType = watch(typeFieldName);

  // Список типов подгружается автоматически после выбора обеих станций.
  const senderStationId = senderStation?.id ?? null;
  const receiverStationId = receiverStation?.id ?? null;
  const senderCountryId = senderStation?.country?.id ?? null;
  const receiverCountryId = receiverStation?.country?.id ?? null;

  const { handleChangeTypesSearch, types } = useGetIrcTypeApi({
    restoredTypes: currentType?.id
      ? (restoredInstructionData?.instructionType ?? null)
      : null,
    senderStationId,
    receiverStationId,
    senderCountryId,
    receiverCountryId,
    isLoadEnabled: !isRestoringInstruction || !isRestoreLoading,
  });

  const [isTypeChangeModalOpen, setIsTypeChangeModalOpen] = useState(false);
  const [typeChangeSelectedValue, setTypeChangeSelectedValue] =
    useState<DropdownChangeEvent>();
  const [typeChangeOnChange, setTypeChangeOnChange] = useState<
    ((value: IrcInstructionType | null) => void) | null
  >(null);

  const handleTypeChangeWithModal = (
    e: DropdownChangeEvent,
    onChange: (value: IrcInstructionType | null) => void,
  ) => {
    const currentFiles = getValues(userFilesFieldName);
    const hasFiles = currentFiles && currentFiles.length > 0;

    if (hasFiles) {
      setTypeChangeSelectedValue(e);
      setTypeChangeOnChange(() => onChange);
      setIsTypeChangeModalOpen(true);
    } else {
      // Создаем обертку для преобразования типов
      const onChangeWrapper = (value: CalculationType | null) => {
        onChange(value as IrcInstructionType | null);
      };
      handleTypeChange(e, onChangeWrapper);
    }
  };

  const handleCloseTypeChangeModal = () => {
    if (typeChangeSelectedValue && typeChangeOnChange) {
      const typePrevValue = getValues(typeFieldName);
      // Восстанавливаем предыдущее значение типа инструкции
      typeChangeOnChange(typePrevValue);
      // Создаем обертку для преобразования типов
      const onChangeWrapper = (value: CalculationType | null) => {
        typeChangeOnChange(value as IrcInstructionType | null);
      };
      handleTypeChange(
        {
          ...typeChangeSelectedValue,
          value: typePrevValue as CalculationType | null,
        },
        onChangeWrapper,
      );
    }
    setIsTypeChangeModalOpen(false);
    setTypeChangeOnChange(null);
  };

  const handleSuccessTypeChangeModal = () => {
    if (typeChangeSelectedValue && typeChangeOnChange) {
      // Очищаем файлы при смене типа инструкции
      handleChangeFiles([]);
      // Создаем обертку для преобразования типов
      const onChangeWrapper = (value: CalculationType | null) => {
        typeChangeOnChange(value as IrcInstructionType | null);
      };
      handleTypeChange(typeChangeSelectedValue, onChangeWrapper);
    }
    setIsTypeChangeModalOpen(false);
    setTypeChangeOnChange(null);
  };

  return (
    <>
      <TypeChangeClearModal
        visible={isTypeChangeModalOpen}
        onClose={handleCloseTypeChangeModal}
        onSuccess={handleSuccessTypeChangeModal}
      />
      <FormField label="Тип инструкции">
        <Controller
          name={typeFieldName}
          control={control}
          rules={{ required: true }}
          render={({ field }) => (
            <Select
              panelStyle={{ width: '320px' }}
              wrapOptions={true}
              style={{ height: 40, width: '100%' }}
              placeholder="Выберите тип"
              value={field.value}
              options={
                field.value?.id
                  ? compareRecords(
                      types.filter((item): item is IrcInstructionType =>
                        Boolean(item.id),
                      ),
                      field.value,
                    )
                  : types
              }
              onChange={(e: DropdownChangeEvent) => {
                handleTypeChangeWithModal(e, field.onChange);
              }}
              onFilter={(e: DropdownFilterEvent) => {
                handleChangeTypesSearch(e.filter);
              }}
              optionLabel="name"
              filterBy="name"
              dataKey="id"
              filter
              showClear
              disabled={disabledType}
            />
          )}
        />
      </FormField>
    </>
  );
};
