import { FC } from 'react';

import { Button } from 'shared_ui/components';

import { Modal } from 'shared/ui/Modal';

import styles from './RoutesClearModal.module.scss';

type RoutesClearModalProps = {
  onClose(): void;
  onSuccess(): void;
  visible: boolean;
};

export const RoutesClearModal: FC<RoutesClearModalProps> = ({
  onClose,
  visible,
  onSuccess,
}) => {
  return (
    <Modal visible={visible} title="Смена станции" onClose={onClose}>
      <div className={styles.modal}>
        <p>
          Таблица маршрутов, тип инструкции, вложенные файлы будут очищены, вы
          действительно хотите сменить станцию ?
        </p>
        <div className="flex flex-row justify-content-between mb-2">
          <Button
            size="medium"
            variant="danger"
            className="md:w-8rem"
            onClick={onClose}
          >
            Отмена
          </Button>
          <Button
            size="medium"
            variant="primary"
            className="md:w-8rem"
            onClick={onSuccess}
          >
            Ок
          </Button>
        </div>
      </div>
    </Modal>
  );
};
