import { useEffect, useRef } from 'react';
import {
  Controller,
  useController,
  useFormContext,
  useWatch,
} from 'react-hook-form';

import { InputText, Select, Typography } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetInstructionRecieverAddressApi } from 'widgets/InstructionForm/model/useGetInstructionRecieverAddressApi';
import { useGetInstructionRecieverRecipsApi } from 'widgets/InstructionForm/model/useGetInstructionRecieverRecipsApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';
import { useFieldsPrefilling } from 'widgets/InstructionForm/store';

import { FormField } from 'shared/ui/FormField';
import { SwitcherField } from 'shared/ui/SwitcherField/SwitcherField';

export const IrcRecieverFields = () => {
  const { control, formState, register, getValues, setValue } =
    useFormContext<CreateInstructionFormValues>();
  const { restoredInstructionData, loading } = useRestoredInstructionContext();
  const { isDisabled } = useIsInstructionDisabled();

  const recieverRoute = restoredInstructionData?.routes?.find(
    route => route.sequenceNumber === 1000,
  );
  const hasManualRecieverName = !!recieverRoute?.manualRecipName;

  const { field } = useController({
    control,
    name: 'recieverSwitch',
    defaultValue: false,
  });

  const preFillingFields = useFieldsPrefilling(state => state.preFillingFields);

  // Синхронизируем значение переключателя после загрузки данных
  const isInitialized = useRef(false);
  useEffect(() => {
    if (!loading && restoredInstructionData && !isInitialized.current) {
      // Устанавливаем значение переключателя на основе наличия ручного имени
      const shouldBeManual = hasManualRecieverName;
      if (shouldBeManual !== field.value) {
        field.onChange(shouldBeManual);
      }
      isInitialized.current = true;
    }
  }, [loading, restoredInstructionData, hasManualRecieverName, field]);

  const recieverAddressFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_RECIEVER_ADDRESS,
  );

  const recieverRecipFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP,
  );
  const currentRecieverRecip = useWatch({
    name: recieverRecipFieldName,
    control,
  });
  const currentRecieverAddress = useWatch({
    name: recieverAddressFieldName,
    control,
  });

  const manualRecieverNameFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_NAME,
  );

  const { handleRecieverRecipChange, handleRecieverAddressChange } =
    useInputInstructionDataTab();

  const { recieverRecips, handleChangeRecieverRecipSearch } =
    useGetInstructionRecieverRecipsApi({
      restoredRecieverRecip:
        restoredInstructionData?.recieverRecip ||
        preFillingFields?.senderRecip ||
        null,
    });

  const {
    recieverAddresses,
    recieverAddressesBackendCount,
    recieverAddressesLoading,
  } = useGetInstructionRecieverAddressApi({
    restoredRecieverAddress: currentRecieverAddress ?? null,
    restoredRecieverRecip:
      currentRecieverRecip ?? restoredInstructionData?.recieverRecip ?? null,
  });

  useEffect(() => {
    if (
      !currentRecieverRecip ||
      currentRecieverAddress ||
      recieverAddressesLoading ||
      recieverAddressesBackendCount !== 1
    )
      return;

    setValue(recieverAddressFieldName, recieverAddresses[0], {
      shouldDirty: false,
    });
  }, [
    currentRecieverRecip,
    currentRecieverAddress,
    recieverAddresses,
    recieverAddressesBackendCount,
    recieverAddressesLoading,
    recieverAddressFieldName,
    setValue,
  ]);

  const prevSwitchValue = useRef(field.value);

  useEffect(() => {
    // Пропускаем первый рендер (инициализацию)
    if (prevSwitchValue.current === field.value) {
      return;
    }

    if (field.value) {
      // Переключились на ручной ввод - очищаем поля выбора из списка
      setValue(recieverRecipFieldName, null);
      setValue(recieverAddressFieldName, null);
    } else {
      // Переключились на выбор из списка - очищаем поля ручного ввода
      setValue(manualRecieverNameFieldName, '');
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_ADDRESS,
        ),
        '',
      );
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_OKPO,
        ),
        '',
      );
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_TGNL,
        ),
        '',
      );
    }

    prevSwitchValue.current = field.value;
  }, [
    field.value,
    setValue,
    recieverRecipFieldName,
    recieverAddressFieldName,
    manualRecieverNameFieldName,
  ]);

  return (
    <div>
      <div className="flex flex-row justify-content-between align-items-center md:w-full mb-2">
        <Typography fontStyle={10} fontWeight={700}>
          Грузополучатель
        </Typography>
        <SwitcherField
          name="recieverSwitch"
          label="Ручной ввод реквизитов ГП"
          control={control}
          disabled={isDisabled}
        />
      </div>

      {field.value ? (
        <>
          <FormField
            label="Наименование ГП"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_NAME
              ]?.message
            }
          >
            <InputText
              className="w-full "
              placeholder="Наименование получателя"
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_NAME,
                ),
              )}
              disabled={isDisabled}
            />
          </FormField>
          <FormField
            label="Адрес ГП"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_ADDRESS
              ]?.message
            }
          >
            <InputText
              className="w-full"
              placeholder=""
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_ADDRESS,
                ),
              )}
              disabled={isDisabled}
            />
          </FormField>
          <FormField
            label="ОКПО ГП"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_OKPO
              ]?.message
            }
          >
            <InputText
              className="w-full"
              placeholder=""
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_OKPO,
                ),
              )}
              disabled={isDisabled}
            />
          </FormField>
          <FormField
            label="ТГНЛ ГП"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_TGNL
              ]?.message
            }
          >
            <InputText
              className="w-full"
              placeholder=""
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_TGNL,
                ),
              )}
              disabled={isDisabled}
            />
          </FormField>
        </>
      ) : (
        <>
          <FormField
            label="Грузополучатель"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP
              ]?.message
            }
          >
            <Controller
              name={getInputInstructionDataTabFieldName(
                CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP,
              )}
              control={control}
              render={({ field }) => (
                <Select
                  panelStyle={{ width: '320px' }}
                  wrapOptions={true}
                  style={{ height: 40 }}
                  placeholder="Выберите грузополучателя"
                  value={field.value}
                  options={recieverRecips}
                  onChange={(e: DropdownChangeEvent) =>
                    handleRecieverRecipChange(e, field.onChange)
                  }
                  onFilter={(e: DropdownFilterEvent) => {
                    handleChangeRecieverRecipSearch(e.filter);
                  }}
                  optionLabel="shortName"
                  filterBy="shortName,name,okpo"
                  dataKey="id"
                  filter
                  showClear
                  disabled={isDisabled}
                />
              )}
            />
          </FormField>
          <FormField
            label="Адрес грузополучателя"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_RECIEVER_ADDRESS
              ]?.message
            }
          >
            <Controller
              name={getInputInstructionDataTabFieldName(
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_RECIEVER_ADDRESS,
              )}
              control={control}
              render={({ field }) => (
                <Select
                  panelStyle={{ width: '320px' }}
                  wrapOptions={true}
                  style={{ height: 40 }}
                  placeholder="Выберите адрес"
                  value={field.value}
                  options={recieverAddresses}
                  onChange={(e: DropdownChangeEvent) =>
                    handleRecieverAddressChange(e, field.onChange)
                  }
                  optionLabel="addressSelectLabel"
                  filterBy="addressSelectLabel"
                  dataKey="id"
                  filter
                  showClear
                  disabled={
                    !getValues(
                      getInputInstructionDataTabFieldName(
                        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP,
                      ),
                    ) || isDisabled
                  }
                />
              )}
            />
          </FormField>
        </>
      )}
    </div>
  );
};
