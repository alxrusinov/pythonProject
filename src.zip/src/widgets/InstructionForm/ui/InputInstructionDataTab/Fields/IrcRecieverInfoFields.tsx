import { useEffect, useRef } from 'react';
import {
  Controller,
  useController,
  useFormContext,
  useWatch,
} from 'react-hook-form';

import { InputText, Select, Typography } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useClientOrgEmails } from 'widgets/InstructionForm/model/useClientOrgEmails';
import { useGetInstructionClientsApi } from 'widgets/InstructionForm/model/useGetInstructionClientsApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';
import { useFieldsPrefilling } from 'widgets/InstructionForm/store';

import { FormField } from 'shared/ui/FormField';
import { SwitcherField } from 'shared/ui/SwitcherField/SwitcherField';
import { compareRecords } from 'shared/utils/compareRecords';

export const IrcRecieverInfoFields = () => {
  const { control, formState, register, setValue, getValues } =
    useFormContext<CreateInstructionFormValues>();
  const { restoredInstructionData, loading } = useRestoredInstructionContext();
  const { isDisabled, isCorrectionInstruction } = useIsInstructionDisabled();
  const disabledRecipient = isDisabled || isCorrectionInstruction;

  const hasManualClientName = !!restoredInstructionData?.manualClientName;

  const clientFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CLIENT,
  );

  const manualClientNameFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_NAME,
  );

  const { field } = useController({
    control,
    name: 'recieverInfoSwitch',
    defaultValue: false,
  });

  const preFillingFields = useFieldsPrefilling(state => state.preFillingFields);
  const resetClient = useFieldsPrefilling(state => state.resetClient);

  // Синхронизируем значение переключателя после загрузки данных
  const isInitialized = useRef(false);
  useEffect(() => {
    if (!loading && restoredInstructionData && !isInitialized.current) {
      if (hasManualClientName && !field.value) {
        field.onChange(true);
      }
      isInitialized.current = true;
    }
  }, [loading, restoredInstructionData, hasManualClientName, field]);

  const { handleClientChange } = useInputInstructionDataTab();

  const { clients, handleChangeClientsSearch } = useGetInstructionClientsApi({
    restoredClient:
      restoredInstructionData?.client || preFillingFields?.client || null,
  });

  const selectedClient = useWatch({
    control,
    name: clientFieldName,
  });
  const clientOrgEmails = useClientOrgEmails(selectedClient?.id);
  const clientOrgEmailsText = clientOrgEmails.join(', ');

  const prevSwitchValue = useRef(field.value);

  useEffect(() => {
    // Пропускаем первый рендер (инициализацию)
    if (prevSwitchValue.current === field.value) {
      return;
    }

    if (field.value) {
      // Переключились на ручной ввод - очищаем поле выбора клиента
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CLIENT,
        ),
        null,
      );
    } else {
      // Переключились на выбор из списка - очищаем поля ручного ввода
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_NAME,
        ),
        '',
      );
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CLIENTS_EMAILS,
        ),
        '',
      );
    }

    prevSwitchValue.current = field.value;
  }, [field.value, setValue]);

  useEffect(() => {
    if (preFillingFields?.client) {
      const currentClient = getValues(clientFieldName);
      const currentManualClientName = getValues(manualClientNameFieldName);

      if (!currentClient && !currentManualClientName && !field.value) {
        setValue(clientFieldName, preFillingFields.client, {
          shouldDirty: false,
        });
      }
    }
  }, [
    preFillingFields?.client,
    clientFieldName,
    manualClientNameFieldName,
    getValues,
    setValue,
  ]);

  return (
    <div>
      <div className="flex flex-row justify-content-between align-items-center md:w-full mb-2">
        <Typography fontStyle={10} fontWeight={700}>
          Получатель инструкции
        </Typography>
        <SwitcherField
          name="recieverInfoSwitch"
          label="Ручной ввод реквизитов получателя"
          control={control}
          disabled={disabledRecipient}
        />
      </div>

      {field.value ? (
        <>
          <FormField
            label="Наименование получателя"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_NAME
              ]?.message
            }
          >
            <InputText
              className="w-full "
              placeholder="Наименование получателя"
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_NAME,
                ),
              )}
              disabled={disabledRecipient}
            />
          </FormField>
          <FormField
            label="Email-адреса получателя"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CLIENTS_EMAILS
              ]?.message
            }
          >
            <InputText
              className="w-full"
              placeholder="Введите email-адреса через запятую"
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CLIENTS_EMAILS,
                ),
              )}
              disabled={disabledRecipient}
            />
          </FormField>
        </>
      ) : (
        <>
          <FormField
            label="Получатель инструкции"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CLIENT
              ]?.message
            }
          >
            <Controller
              name={getInputInstructionDataTabFieldName(
                CREATE_INSTRUCTION_FORM_NAMES.CLIENT,
              )}
              control={control}
              render={({ field }) => (
                <div className="flex flex-column gap-2 w-full">
                  <Select
                    panelStyle={{ width: '320px' }}
                    wrapOptions={true}
                    style={{ height: 40 }}
                    placeholder="Выберите получателя"
                    value={field.value}
                    options={
                      field.value
                        ? compareRecords(clients, field.value)
                        : clients
                    }
                    onChange={(e: DropdownChangeEvent) => {
                      if (!e.value) {
                        resetClient();
                      }
                      handleClientChange(e, field.onChange);
                    }}
                    onFilter={(e: DropdownFilterEvent) => {
                      handleChangeClientsSearch(e.filter);
                    }}
                    optionLabel="shortName"
                    filterBy="shortName,name,okpo"
                    dataKey="id"
                    filter
                    showClear
                    disabled={disabledRecipient}
                  />
                  {clientOrgEmailsText ? (
                    <span
                      className="white-space-normal"
                      style={{ wordBreak: 'break-word' }}
                    >
                      <Typography component="span" fontStyle={12}>
                        {clientOrgEmailsText}
                      </Typography>
                    </span>
                  ) : null}
                </div>
              )}
            />
          </FormField>
        </>
      )}
    </div>
  );
};
