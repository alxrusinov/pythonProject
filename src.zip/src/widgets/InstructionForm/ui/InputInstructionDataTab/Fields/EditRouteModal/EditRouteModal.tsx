import {
  ImpOrgPassport,
  ImpOrgPayer,
  IrcInstructionRoute,
} from 'graphql/generated/generated';
import { FC, useEffect, useState } from 'react';

import { InputText, Label, Modal, Select, Switch } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { useGetInstructionPayerRecipsApi } from 'widgets/InstructionForm/model/useGetInstructionPayerRecipsApi';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

import { FormField } from 'shared/ui/FormField';

import styles from './EditRouteModal.module.scss';

type EditRouteModalProps = {
  handleChangeRoutes(routeInfo: IrcInstructionRoute): void;
  onClose(): void;
  visible: boolean;
  route: IrcInstructionRoute;
};

export const EditRouteModal: FC<EditRouteModalProps> = ({
  route,
  handleChangeRoutes,
  onClose,
  visible,
}) => {
  const { isDisabled } = useIsInstructionDisabled();
  const hasManualPayerName = !!route?.manualPayerName;
  const [isMalualInputSwitch, setIsManualInputSwitch] =
    useState(hasManualPayerName);
  const [routeInfo, setRouteInfo] = useState(route);

  const { payerRecips, handleChangePayerRecipSearch } =
    useGetInstructionPayerRecipsApi({
      restoredPayerRecip: (route?.payer ?? null) as
        | ImpOrgPayer
        | ImpOrgPassport
        | null,
    });

  useEffect(() => {
    if (visible) {
      setRouteInfo(route);
      setIsManualInputSwitch(!!route?.manualPayerName);
    }
  }, [visible, route]);

  const handleSwitchChange = (value: boolean) => {
    setIsManualInputSwitch(value);
    if (value) {
      // Переключились на ручной ввод - очищаем поле выбора плательщика
      setRouteInfo(prev => ({
        ...prev,
        payer: null,
        manualPayerName: '',
        manualPayerCode: '',
        manualPayerSubCode: '',
      }));
    } else {
      // Переключились на выбор из списка - очищаем поля ручного ввода
      setRouteInfo(prev => ({
        ...prev,
        manualPayerName: '',
        manualPayerCode: '',
        manualPayerSubCode: '',
      }));
    }
  };
  const handleChangeRouteInfo = (
    value: string | ImpOrgPayer | ImpOrgPassport | null,
    fieldName: string,
  ) => {
    if (fieldName === 'payer') {
      const payer = value as ImpOrgPayer | ImpOrgPassport | null;
      const payerWithOrgPayer =
        payer == null
          ? null
          : {
              ...payer,
              name:
                (payer as ImpOrgPassport)?.name ??
                (payer as ImpOrgPayer)?.name ??
                (payer as ImpOrgPassport)?.shortName ??
                '',
              orgPayer: {
                code:
                  (payer as ImpOrgPassport)?.orgPayer?.code ??
                  (payer as ImpOrgPayer)?.code,
              },
            };
      setRouteInfo({
        ...routeInfo,
        payer: payerWithOrgPayer as ImpOrgPassport,
        manualPayerName: '',
        manualPayerCode: '',
        manualPayerSubCode: '',
      });
    } else if (fieldName === 'manualPayerName') {
      setRouteInfo({
        ...routeInfo,
        manualPayerName: value as string,
        manualPayerSubCode: '',
        manualPayerCode: '',
      });
    } else if (fieldName === 'manualPayerCode') {
      const digitsOnly = String(value ?? '').replace(/\D/g, '');
      setRouteInfo({
        ...routeInfo,
        manualPayerCode: digitsOnly,
      });
    } else {
      setRouteInfo({
        ...routeInfo,
        [fieldName]: value,
      });
    }
  };

  return (
    <Modal
      visible={visible}
      title="Плательщик"
      className={styles.modalDialog}
      contentClassName={styles.modalContent}
      size="medium"
      onClose={onClose}
      onComplete={() => {
        handleChangeRoutes(routeInfo);
        onClose();
      }}
    >
      <div className={styles.modal}>
        <div>
          <div className="flex flex-row justify-content-start mb-2">
            <Label
              className="mb-0 mr-2"
              label="Ручной ввод плательщика"
            ></Label>
            <Switch
              size="medium"
              onChange={e => handleSwitchChange(!!e?.value)}
              checked={isMalualInputSwitch}
              disabled={isDisabled}
            />
          </div>
          <div className="mb-2">
            {isMalualInputSwitch ? (
              <>
                <FormField label="Наименование плательщика">
                  <InputText
                    className="w-full "
                    placeholder="Наименование плательщика"
                    value={routeInfo?.manualPayerName || ''}
                    onChange={e =>
                      handleChangeRouteInfo(e.target.value, 'manualPayerName')
                    }
                    disabled={isDisabled}
                  />
                </FormField>
                <FormField label="Код плательщика">
                  <InputText
                    className="w-full "
                    value={routeInfo?.manualPayerCode || ''}
                    onChange={e =>
                      handleChangeRouteInfo(e.target.value, 'manualPayerCode')
                    }
                    inputMode="numeric"
                    disabled={isDisabled}
                  />
                </FormField>
                <FormField label="Подкод плательщика">
                  <InputText
                    className="w-full"
                    value={routeInfo?.manualPayerSubCode || ''}
                    onChange={e =>
                      handleChangeRouteInfo(
                        e.target.value,
                        'manualPayerSubCode',
                      )
                    }
                    disabled={isDisabled}
                  />
                </FormField>
              </>
            ) : (
              <>
                <FormField label="Плательщик">
                  <div className={styles.payerField}>
                    <Select
                      className={styles.payerSelect}
                      panelStyle={{ width: '320px' }}
                      wrapOptions={true}
                      style={{ height: 40, width: '100%' }}
                      placeholder="Выберите плательщика"
                      value={routeInfo.payer}
                      options={payerRecips}
                      onChange={(e: DropdownChangeEvent) =>
                        handleChangeRouteInfo(e.value, 'payer')
                      }
                      onFilter={(e: DropdownFilterEvent) => {
                        handleChangePayerRecipSearch(e.filter);
                      }}
                      optionLabel="name"
                      dataKey="id"
                      filter
                      showClear
                      disabled={isDisabled}
                    />
                  </div>
                </FormField>
                {routeInfo?.payer?.orgPayer?.code && (
                  <FormField label="Код плательщика">
                    <InputText
                      className="w-full"
                      value={routeInfo?.payer?.orgPayer?.code ?? ''}
                      disabled
                    />
                  </FormField>
                )}
                <FormField label="Подкод плательщика">
                  <InputText
                    className="w-full"
                    value={routeInfo?.manualPayerSubCode || ''}
                    onChange={e =>
                      handleChangeRouteInfo(
                        e.target.value,
                        'manualPayerSubCode',
                      )
                    }
                    placeholder="Введите подкод плательщика"
                    disabled={isDisabled}
                  />
                </FormField>
              </>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};
