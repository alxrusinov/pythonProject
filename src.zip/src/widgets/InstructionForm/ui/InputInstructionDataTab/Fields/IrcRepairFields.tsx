// import { ImpRepairContract } from 'graphql/generated/generated';
// import { useEffect, useState } from 'react';
// import { Controller, useFormContext } from 'react-hook-form';

// import { Select, Typography } from 'shared_ui/components';
// import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

// import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
// import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
// import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
// import { useGetInstructionRepairContractsApi } from 'widgets/InstructionForm/model/useGetInstructionRepairContractsApi';
// import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
// import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

// import { FormField } from 'shared/ui/FormField';

// export const IrcRepairFields = () => {
//   const { control, formState, getValues } =
//     useFormContext<CreateInstructionFormValues>();
//   const { isDisabled } = useIsInstructionDisabled();
//   const { handleChangeRepairContract } = useInputInstructionDataTab();

//   const repairContractFieldName = getInputInstructionDataTabFieldName(
//     CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_REPAIR,
//   );
//   const [restoredRepairContract, setRestoredRepairContract] =
//     useState<ImpRepairContract | null>(null);

//   useEffect(() => {
//     const repairContractValue = getValues(repairContractFieldName);
//     setRestoredRepairContract(
//       (repairContractValue ??
//         restoredRepairContract ??
//         null) as ImpRepairContract | null,
//     );
//   }, [getValues(repairContractFieldName), restoredRepairContract]);

//   const { repairContracts, handleChangeRepairContractSearch } =
//     useGetInstructionRepairContractsApi({
//       restoredRepairContract: restoredRepairContract || null,
//     });

//   return (
//     <div>
//       <Typography className="mb-2" fontStyle={10} fontWeight={700}>
//         Договор ремонта
//       </Typography>

//       <FormField
//         label="Договор ремонта"
//         errorMessage={
//           formState.errors?.inputInstructionDataTab?.[
//             CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_REPAIR
//           ]?.message
//         }
//       >
//         <Controller
//           name={getInputInstructionDataTabFieldName(
//             CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_REPAIR,
//           )}
//           control={control}
//           render={({ field }) => (
//             <Select
//               panelStyle={{ width: '320px' }}
//               wrapOptions={true}
//               style={{ height: 40 }}
//               placeholder="Выберите договор"
//               value={field.value}
//               options={repairContracts}
//               onChange={(e: DropdownChangeEvent) =>
//                 handleChangeRepairContract(e, field.onChange)
//               }
//               onFilter={(e: DropdownFilterEvent) => {
//                 handleChangeRepairContractSearch(e.filter);
//               }}
//               optionLabel="contractNum"
//               dataKey="id"
//               filter
//               showClear
//               disabled={isDisabled}
//             />
//           )}
//         />
//       </FormField>
//     </div>
//   );
// };
