import { IrcInstructionCar } from 'graphql/generated/generated';
import { useEffect, useRef, useState } from 'react';
import { useController, useFormContext } from 'react-hook-form';

import { Button, Column, InputText, Typography } from 'shared_ui/components';
import { DataTable } from 'shared_ui/primereact';

import {
  CAR_NUMBER_REGEX,
  CREATE_INSTRUCTION_FORM_NAMES,
  InitialFieldsForWagonModal,
} from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';
import { useFieldsPrefilling } from 'widgets/InstructionForm/store';

import { Modal } from 'features/Modal';
import {
  CompareItem,
  ExportingData,
  VerificationWagons,
} from 'features/VerificationWagons';

import styles from './CarsTable.module.scss';

/** Только цифры, запятая и пробел; каждое число — не более 8 цифр */
const normalizeCarsInput = (value: string): string =>
  value.replace(/[^\d,\s]/g, '').replace(/\d{9,}/g, match => match.slice(0, 8));

export const CarsTable = () => {
  const { control, setValue, getValues, watch } =
    useFormContext<CreateInstructionFormValues>();
  const { restoredInstructionData } = useRestoredInstructionContext();
  const { isDisabled } = useIsInstructionDisabled();
  const restoredCars = restoredInstructionData?.cars;

  const [isModalShown, setIsModalShown] = useState(false);
  const [wagonNumbers, setWagonNumber] = useState<string[]>([]);
  const [fields, setFields] = useState<{
    station: CompareItem<number> | null;
    customer: CompareItem<number> | null;
  }>(InitialFieldsForWagonModal);

  const setPreFillingFields = useFieldsPrefilling(
    state => state.setPreFillingFields,
  );

  const onOpenModal = () => {
    setIsModalShown(true);
  };

  const onCloseModal = () => {
    setIsModalShown(false);
    setWagonNumber([]);
    setFields(InitialFieldsForWagonModal);
  };

  const { field } = useController({
    control,
    name: 'newCarsInput',
    defaultValue: '',
  });
  const carsFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CARS,
  );

  const [selectedCars, setSelectedCars] = useState<IrcInstructionCar[]>([]);
  const [cars, setCars] = useState<IrcInstructionCar[]>([]);
  const isInitialized = useRef(false);

  // Отслеживаем изменения вагонов в форме
  const formCars = watch(carsFieldName);

  // Инициализация вагонов из restoredInstructionData
  useEffect(() => {
    if (restoredCars && !isInitialized.current) {
      setCars(restoredCars);
      isInitialized.current = true;
    } else if (!restoredInstructionData && !isInitialized.current) {
      // Если нет данных для восстановления, помечаем как инициализированное
      isInitialized.current = true;
    }
  }, [restoredCars, restoredInstructionData]);

  // Обновление вагонов при изменении формы (только после инициализации)
  useEffect(() => {
    // Пропускаем обновления во время инициализации
    if (!isInitialized.current) {
      return;
    }

    if (formCars) {
      setCars(formCars);
    }
  }, [formCars]);

  const handleAddNewCars = (numbers: string) => () => {
    const newCars = numbers
      .split(/[,\s]+/)
      .map(carNumber => carNumber.trim())
      .filter(carNumber => carNumber.length > 0)
      .filter(carNumber => CAR_NUMBER_REGEX.test(carNumber));

    const { inputInstructionDataTab } = getValues();
    const customer: CompareItem<number> | null = inputInstructionDataTab.client
      ?.id
      ? {
          id: inputInstructionDataTab.client.id,
          name: inputInstructionDataTab.client.name || '',
        }
      : null;

    const station: CompareItem<number> | null = inputInstructionDataTab
      .senderStation?.id
      ? {
          id: inputInstructionDataTab.senderStation.id,
          name: inputInstructionDataTab.senderStation?.name || '',
        }
      : null;

    setWagonNumber(newCars);
    setFields({ customer, station });
    onOpenModal();
    field.onChange('');
  };

  const handleRemoveSelectedCars = () => {
    const setOfValues = new Set(selectedCars.map(item => item.number));
    const filtredCars = cars.filter(item => !setOfValues.has(item.number));

    setSelectedCars([]);
    setValue(carsFieldName, filtredCars, { shouldDirty: true });
  };

  const onSave = (data: ExportingData) => {
    const currentCars = getValues(carsFieldName) || [];
    const existingNumbers = new Set(currentCars.map(car => car.number));

    const newCars = data.carNumbers.reduce<{ number: string }[]>(
      (acc, value) => {
        if (!existingNumbers.has(value)) {
          existingNumbers.add(value);
          return [...acc, { number: value }];
        }
        return acc;
      },
      [],
    );

    setValue(carsFieldName, currentCars.concat(newCars), {
      shouldDirty: true,
    });

    setPreFillingFields(data);

    onCloseModal();
  };

  return (
    <>
      <Typography className="mb-4" fontStyle={10} fontWeight={700}>
        Вагоны: {cars.length > 0 ? `${cars.length} шт.` : ''}
      </Typography>
      <div className={styles.carsTableScroll}>
        <DataTable
          header={() => (
            <div className="flex justify-content-end">
              <Button
                className="gap-0"
                size="small"
                variant="danger"
                icon="pi pi-trash"
                disabled={!selectedCars.length || isDisabled}
                onClick={handleRemoveSelectedCars}
              ></Button>
            </div>
          )}
          dataKey="number"
          value={cars}
          size="small"
          emptyMessage="Нет вагонов"
          selectionMode="checkbox"
          selection={selectedCars}
          onSelectionChange={e => setSelectedCars(e.value)}
          disabled={isDisabled}
        >
          <Column selectionMode="multiple" headerStyle={{ width: 40 }} />
          <Column
            header="Номер"
            body={rowData => rowData.number}
            style={{ width: '100%' }}
          ></Column>
        </DataTable>
      </div>

      <InputText
        className="w-full"
        placeholder="Введите номера вагонов через запятую или пробел (только цифры, до 8 знаков)"
        value={field.value ?? ''}
        onChange={e => {
          const next = normalizeCarsInput(e.target?.value ?? '');
          field.onChange(next);
        }}
        onBlur={field.onBlur}
        disabled={isDisabled}
      />
      <Button
        size="small"
        variant="primary"
        disabled={!getValues('newCarsInput') || isDisabled}
        className="mt-2 w-full"
        onClick={handleAddNewCars(field.value)}
      >
        Добавить вагоны
      </Button>
      <Modal
        style={{ height: '82vh' }}
        visible={isModalShown}
        title="Добавление вагонов"
        onClose={onCloseModal}
        size="large"
        appendTo={document.getElementById('root')}
      >
        {isModalShown && (
          <VerificationWagons
            fields={fields}
            wagonNumbers={wagonNumbers}
            onSave={onSave}
          />
        )}
      </Modal>
    </>
  );
};
