import { useEffect, useRef } from 'react';
import {
  Controller,
  useController,
  useFormContext,
  useWatch,
} from 'react-hook-form';

import { InputText, Select, Typography } from 'shared_ui/components';
import { DropdownChangeEvent, DropdownFilterEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import { CreateInstructionFormValues } from 'widgets/InstructionForm/lib/types';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useGetInstructionSenderAddressApi } from 'widgets/InstructionForm/model/useGetInstructionSenderAddressApi';
import { useGetInstructionSenderRecipsApi } from 'widgets/InstructionForm/model/useGetInstructionSenderRecipsApi';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';
import { useFieldsPrefilling } from 'widgets/InstructionForm/store';

import { FormField } from 'shared/ui/FormField';
import { SwitcherField } from 'shared/ui/SwitcherField/SwitcherField';
import { compareRecords } from 'shared/utils/compareRecords';

export const IrcSenderFields = () => {
  const { control, formState, register, getValues, setValue } =
    useFormContext<CreateInstructionFormValues>();
  const { restoredInstructionData, loading } = useRestoredInstructionContext();
  const { isDisabled, isCorrectionInstruction } = useIsInstructionDisabled();
  const disabledSender = isDisabled || isCorrectionInstruction;

  const senderRoute = restoredInstructionData?.routes?.find(
    route => route.sequenceNumber === 1,
  );
  const hasManualSenderName = !!senderRoute?.manualRecipName;

  const { field } = useController({
    control,
    name: 'senderSwitch',
    defaultValue: false,
  });

  const preFillingFields = useFieldsPrefilling(state => state.preFillingFields);
  const resetSenderRecip = useFieldsPrefilling(state => state.resetSenderRecip);
  const senderRecipName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP,
  );
  const senderAddressName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS,
  );

  const currentField = useWatch({ name: senderRecipName, control });
  const currentSenderAddress = useWatch({ name: senderAddressName, control });

  // Синхронизируем значение переключателя после загрузки данных
  const isInitialized = useRef(false);
  useEffect(() => {
    if (!loading && restoredInstructionData && !isInitialized.current) {
      if (hasManualSenderName && !field.value) {
        field.onChange(true);
      }
      isInitialized.current = true;
    }
  }, [loading, restoredInstructionData, hasManualSenderName, field]);

  const senderAddressFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS,
  );

  const senderRecipFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP,
  );
  const manualSenderNameFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_NAME,
  );

  const { handleSenderRecipChange, handleSenderAddressChange } =
    useInputInstructionDataTab();

  const { senderRecips, handleChangeSenderRecipSearch } =
    useGetInstructionSenderRecipsApi({
      restoredSenderRecip:
        restoredInstructionData?.senderRecip ||
        preFillingFields?.senderRecip ||
        null,
    });

  const {
    senderAddresses,
    senderAddressesBackendCount,
    senderAddressesLoading,
  } = useGetInstructionSenderAddressApi({
    restoredSenderAddress: currentSenderAddress ?? null,
    restoredSenderRecip: currentField ?? null,
  });

  useEffect(() => {
    if (
      !currentField ||
      currentSenderAddress ||
      senderAddressesLoading ||
      senderAddressesBackendCount !== 1
    )
      return;

    setValue(senderAddressName, senderAddresses[0], {
      shouldDirty: false,
    });
  }, [
    currentField,
    currentSenderAddress,
    senderAddresses,
    senderAddressesBackendCount,
    senderAddressesLoading,
    senderAddressName,
    setValue,
  ]);

  const prevSwitchValue = useRef(field.value);
  const lastAppliedPrefillingRef = useRef(preFillingFields);

  useEffect(() => {
    // Пропускаем первый рендер (инициализацию)
    if (prevSwitchValue.current === field.value) {
      return;
    }

    if (field.value) {
      // Переключились на ручной ввод - очищаем поля выбора из списка
      setValue(senderRecipFieldName, null);
      setValue(senderAddressFieldName, null);
    } else {
      // Переключились на выбор из списка - очищаем поля ручного ввода
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_NAME,
        ),
        '',
      );
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_ADDRESS,
        ),
        '',
      );
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_OKPO,
        ),
        '',
      );
      setValue(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_TGNL,
        ),
        '',
      );
    }

    prevSwitchValue.current = field.value;
  }, [field.value, setValue, senderRecipFieldName, senderAddressFieldName]);

  useEffect(() => {
    if (
      !preFillingFields?.senderRecip ||
      lastAppliedPrefillingRef.current === preFillingFields
    ) {
      return;
    }

    const currentSenderRecip = getValues(senderRecipFieldName);
    const currentManualSenderName = getValues(manualSenderNameFieldName);

    lastAppliedPrefillingRef.current = preFillingFields;

    if (currentSenderRecip || currentManualSenderName || field.value) {
      return;
    }

    setValue(senderRecipFieldName, preFillingFields.senderRecip, {
      shouldDirty: false,
    });
  }, [
    preFillingFields,
    senderRecipFieldName,
    manualSenderNameFieldName,
    getValues,
    setValue,
  ]);

  return (
    <div>
      <div className="flex flex-row justify-content-between align-items-center md:w-full mb-2">
        <Typography fontStyle={10} fontWeight={700}>
          Грузоотправитель
        </Typography>
        <SwitcherField
          name="senderSwitch"
          label="Ручной ввод реквизитов ГО"
          control={control}
          disabled={disabledSender}
        />
      </div>
      {field.value ? (
        <>
          <FormField
            label="Наименование ГО"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_NAME
              ]?.message
            }
          >
            <InputText
              className="w-full "
              placeholder="Наименование отправителя"
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_NAME,
                ),
              )}
              disabled={disabledSender}
            />
          </FormField>
          <FormField
            label="Адрес ГО"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_ADDRESS
              ]?.message
            }
          >
            <InputText
              className="w-full"
              placeholder=""
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_ADDRESS,
                ),
              )}
              disabled={disabledSender}
            />
          </FormField>
          <FormField
            label="ОКПО ГО"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_OKPO
              ]?.message
            }
          >
            <InputText
              className="w-full"
              placeholder=""
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_OKPO,
                ),
              )}
              disabled={disabledSender}
            />
          </FormField>
          <FormField
            label="ТГНЛ ГО"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_TGNL
              ]?.message
            }
          >
            <InputText
              className="w-full"
              placeholder=""
              {...register(
                getInputInstructionDataTabFieldName(
                  CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_TGNL,
                ),
              )}
              disabled={disabledSender}
            />
          </FormField>
        </>
      ) : (
        <>
          <FormField
            label="Грузоотправитель"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP
              ]?.message
            }
          >
            <Controller
              name={getInputInstructionDataTabFieldName(
                CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP,
              )}
              control={control}
              render={({ field }) => (
                <Select
                  panelStyle={{ width: '320px' }}
                  wrapOptions={true}
                  style={{ height: 40 }}
                  placeholder="Выберите грузоотправителя"
                  value={field.value}
                  options={
                    field.value
                      ? compareRecords(senderRecips, field.value)
                      : senderRecips
                  }
                  onChange={(e: DropdownChangeEvent) => {
                    if (!e.value) {
                      resetSenderRecip();
                    }
                    handleSenderRecipChange(e, field.onChange);
                  }}
                  onFilter={(e: DropdownFilterEvent) => {
                    handleChangeSenderRecipSearch(e.filter);
                  }}
                  optionLabel="shortName"
                  filterBy="shortName,name,okpo"
                  dataKey="id"
                  filter
                  showClear
                  disabled={disabledSender}
                />
              )}
            />
          </FormField>
          <FormField
            label="Адрес грузоотправителя"
            errorMessage={
              formState.errors?.inputInstructionDataTab?.[
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS
              ]?.message
            }
          >
            <Controller
              name={getInputInstructionDataTabFieldName(
                CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS,
              )}
              control={control}
              render={({ field }) => (
                <Select
                  panelStyle={{ width: '320px' }}
                  wrapOptions={true}
                  style={{ height: 40 }}
                  placeholder="Выберите адрес"
                  value={field.value}
                  options={senderAddresses}
                  onChange={(e: DropdownChangeEvent) =>
                    handleSenderAddressChange(e, field.onChange)
                  }
                  optionLabel="addressSelectLabel"
                  filterBy="addressSelectLabel"
                  dataKey="id"
                  filter
                  showClear
                  disabled={
                    !getValues(
                      getInputInstructionDataTabFieldName(
                        CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP,
                      ),
                    ) || disabledSender
                  }
                />
              )}
            />
          </FormField>
        </>
      )}
    </div>
  );
};
