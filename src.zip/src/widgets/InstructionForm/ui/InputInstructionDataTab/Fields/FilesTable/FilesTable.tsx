import {
  IrcInstructionTypeFile,
  IrcInstructionUserFileInput,
} from 'graphql/generated/generated';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useFormContext } from 'react-hook-form';
import { useParams, useSearchParams } from 'react-router-dom';

import { Button, Column, Typography } from 'shared_ui/components';
import { DataTable } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from 'widgets/InstructionForm/lib/constants';
import { getInputInstructionDataTabFieldName } from 'widgets/InstructionForm/lib/getFormFields';
import {
  filterFilesBySourceType,
  getFileDownloadHref,
} from 'widgets/InstructionForm/lib/utils';
import { useInstructionExtractedFileNames } from 'widgets/InstructionForm/model/InstructionExtractedFileNamesContext';
import { useRestoredInstructionContext } from 'widgets/InstructionForm/model/RestoredInstructionContext';
import { useFetchInstructionTypeFiles } from 'widgets/InstructionForm/model/useFetchInstructionTypeFiles';
import { useInputInstructionDataTab } from 'widgets/InstructionForm/model/useInputInstructionDataTab';
import { useIsInstructionDisabled } from 'widgets/InstructionForm/model/useIsInstructionDisabled';

import { sanitizeFileName, toBase64 } from 'shared/utils/file';

export const FilesTable = () => {
  const { masterId } = useParams<{ masterId?: string }>();
  const [searchParams] = useSearchParams();
  const copyFrom = searchParams.get('copyFrom');
  const isCopyMode = !!copyFrom;
  const instructionId = masterId ?? copyFrom ?? null;
  const { restoredInstructionData, loading } = useRestoredInstructionContext();
  const { getDisplayName } = useInstructionExtractedFileNames();
  const { handleChangeFiles } = useInputInstructionDataTab();
  const handleChangeFilesRef = useRef(handleChangeFiles);
  handleChangeFilesRef.current = handleChangeFiles;
  const { fetchFilesByTypeId } = useFetchInstructionTypeFiles();
  const { isDisabled } = useIsInstructionDisabled();
  const { watch } = useFormContext();
  const userFilesFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.USER_FILES,
  );

  const senderFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION,
  );
  const receiverFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION,
  );
  const typeFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.TYPES,
  );

  const senderStation = watch(senderFieldName);
  const receiverStation = watch(receiverFieldName);
  const selectedType = watch(typeFieldName);
  const formUserFiles = watch(userFilesFieldName);
  const isInitialized = useRef(false);
  const prevTypeIdRef = useRef<string | null>(null);
  const prevSenderStationIdRef = useRef<number | null>(null);
  const prevReceiverStationIdRef = useRef<number | null>(null);

  // Мемоизируем ID типа инструкции для отслеживания изменений
  const selectedTypeId = useMemo(
    () => selectedType?.id || null,
    [selectedType?.id],
  );

  const restoredFiles = useMemo(
    () =>
      filterFilesBySourceType(restoredInstructionData?.instructionType?.files),
    [restoredInstructionData?.instructionType?.files],
  );

  const restoredTypeId = useMemo(
    () => restoredInstructionData?.instructionType?.id || null,
    [restoredInstructionData?.instructionType?.id],
  );

  const [files, setFiles] = useState<IrcInstructionTypeFile[]>([]);

  // После создания/перехода на другую инструкцию переинициализируем таблицу файлов с нуля.
  useEffect(() => {
    isInitialized.current = false;
    prevTypeIdRef.current = null;
    prevSenderStationIdRef.current = null;
    prevReceiverStationIdRef.current = null;
    setFiles([]);
  }, [instructionId]);

  const mapFilesToFormValue = (filesToMap: IrcInstructionTypeFile[]) =>
    filesToMap
      .filter(file => file?.userFiles?.[0]?.content)
      .map(file => ({
        instructionTypeFileId: file?.id,
        content: file?.userFiles?.[0]?.content,
      })) as IrcInstructionUserFileInput[];

  const areUserFilesEqual = (
    left: IrcInstructionUserFileInput[] = [],
    right: IrcInstructionUserFileInput[] = [],
  ) => {
    if (left.length !== right.length) {
      return false;
    }

    return left.every((item, index) => {
      return (
        item?.instructionTypeFileId === right[index]?.instructionTypeFileId &&
        item?.content === right[index]?.content
      );
    });
  };

  // Сопоставление файлов только с instruction.userFiles (контент из types.files.userFiles
  // не используется — он может содержать файлы из других инструкций)
  const mergeFilesWithUserFiles = (
    filesToMerge: IrcInstructionTypeFile[],
    userFilesData?: Array<{
      instructionTypeFileId?: string | null;
      content?: string | null;
    }> | null,
  ): IrcInstructionTypeFile[] => {
    return filesToMerge.map(file => {
      const userFile = userFilesData?.find(
        uf => uf?.instructionTypeFileId === file?.id,
      );

      if (userFile?.content) {
        return {
          ...file,
          userFiles: [{ content: userFile.content }],
        };
      }

      return { ...file, userFiles: [] };
    });
  };

  const setTypeFilesFromQuery = useCallback(
    (
      typeFiles: IrcInstructionTypeFile[],
      userFilesData?: Array<{
        instructionTypeFileId?: string | null;
        content?: string | null;
      }> | null,
    ) => {
      const formattedFiles = mergeFilesWithUserFiles(typeFiles, userFilesData);
      setFiles(formattedFiles);
      handleChangeFilesRef.current(mapFilesToFormValue(formattedFiles), {
        shouldDirty: false,
      });
    },
    [],
  );

  // Инициализация файлов из restoredInstructionData
  useEffect(() => {
    // Не перезаписываем файлы восстановленными данными, если пользователь уже выбрал другой тип
    if (
      isInitialized.current &&
      selectedTypeId !== null &&
      selectedTypeId !== restoredTypeId
    ) {
      return;
    }

    // Если есть восстановленные файлы
    if (restoredFiles.length > 0) {
      // Сопоставляем userFiles из restoredInstructionData с файлами по instructionTypeFileId
      const filesWithUserFiles = mergeFilesWithUserFiles(
        restoredFiles,
        restoredInstructionData?.userFiles,
      );

      // Обновляем файлы только если они изменились или это первая инициализация
      setFiles(prevFiles => {
        // Проверяем, изменились ли файлы
        const filesChanged =
          prevFiles.length !== filesWithUserFiles.length ||
          filesWithUserFiles.some(
            (file, index) =>
              file?.id !== prevFiles[index]?.id ||
              file?.userFiles?.[0]?.content !==
                prevFiles[index]?.userFiles?.[0]?.content,
          );

        if (filesChanged || !isInitialized.current) {
          return filesWithUserFiles;
        }
        return prevFiles;
      });

      // Формируем массив файлов для формы из файлов с загруженным контентом
      const newFilesForForm = mapFilesToFormValue(filesWithUserFiles);

      if (!isInitialized.current) {
        handleChangeFiles(newFilesForForm, { shouldDirty: false });
      }

      if (!isInitialized.current) {
        prevTypeIdRef.current =
          restoredInstructionData?.instructionType?.id || null;
        isInitialized.current = true;
      }
    } else if (!isInitialized.current) {
      // Не завершаем инициализацию, пока идёт загрузка данных инструкции.
      // Иначе можно зафиксировать пустое состояние таблицы до прихода restored-данных.
      const waitingData = loading || (isCopyMode && !restoredInstructionData);
      if (!waitingData) {
        const restoredTypeIdValue =
          restoredInstructionData?.instructionType?.id || null;
        prevTypeIdRef.current = restoredTypeIdValue;
        isInitialized.current = true;

        if (selectedTypeId && selectedTypeId !== restoredTypeIdValue) {
          prevTypeIdRef.current = selectedTypeId;
          void fetchFilesByTypeId(selectedTypeId).then(typeFiles => {
            setTypeFilesFromQuery(typeFiles, null);
          });
        }
      }
    }
  }, [
    restoredFiles,
    restoredInstructionData?.userFiles,
    restoredTypeId,
    selectedTypeId,
    isCopyMode,
    loading,
    restoredInstructionData,
    fetchFilesByTypeId,
    setTypeFilesFromQuery,
  ]);

  // Держим значение userFiles в форме синхронным с таблицей:
  // если поле в форме очистилось сторонним reset/setValue, но файл не удален в таблице,
  // возвращаем его в форму, чтобы он гарантированно ушел в payload сохранения.
  useEffect(() => {
    if (!isInitialized.current) {
      return;
    }

    const filesForForm = mapFilesToFormValue(files);
    const normalizedFormFiles = Array.isArray(formUserFiles)
      ? formUserFiles
      : [];
    if (areUserFilesEqual(normalizedFormFiles, filesForForm)) {
      return;
    }

    handleChangeFilesRef.current(filesForForm, { shouldDirty: false });
  }, [files, formUserFiles]);

  // Обновление вложений при смене типа (в списке типов нет files — загружаем по id)
  useEffect(() => {
    if (!isInitialized.current) {
      return;
    }

    const currentTypeId = selectedTypeId;

    if (currentTypeId === prevTypeIdRef.current) {
      return;
    }

    if (!currentTypeId) {
      setFiles([]);
      handleChangeFiles([], { shouldDirty: false });
      prevTypeIdRef.current = null;
      return;
    }

    prevTypeIdRef.current = currentTypeId;
    setFiles([]);
    handleChangeFilesRef.current([], { shouldDirty: false });
    let cancelled = false;

    void fetchFilesByTypeId(currentTypeId).then(typeFiles => {
      if (cancelled) return;
      setTypeFilesFromQuery(typeFiles, null);
    });

    return () => {
      cancelled = true;
    };
  }, [selectedTypeId, fetchFilesByTypeId, setTypeFilesFromQuery]);

  // Очищаем файлы при смене станции
  useEffect(() => {
    // Пропускаем первый рендер (инициализацию) и загрузку данных
    if (!isInitialized.current || loading) {
      prevSenderStationIdRef.current = senderStation?.id || null;
      prevReceiverStationIdRef.current = receiverStation?.id || null;
      return;
    }

    const currentSenderStationId = senderStation?.id || null;
    const currentReceiverStationId = receiverStation?.id || null;

    // Проверяем, действительно ли станции изменились
    const senderStationChanged =
      currentSenderStationId !== prevSenderStationIdRef.current;
    const receiverStationChanged =
      currentReceiverStationId !== prevReceiverStationIdRef.current;

    // Проверяем, совпадают ли текущие станции со станциями из restoredInstructionData
    // Если совпадают, значит это восстановление данных, а не изменение пользователем
    const senderStationMatchesRestored =
      currentSenderStationId === restoredInstructionData?.senderStation?.id;
    const receiverStationMatchesRestored =
      currentReceiverStationId === restoredInstructionData?.receiverStation?.id;

    // Очищаем файлы только если:
    // 1. Станции действительно изменились
    // 2. И это не восстановление данных (станции не совпадают с restoredInstructionData)
    if (
      (senderStationChanged || receiverStationChanged) &&
      !(senderStationMatchesRestored && receiverStationMatchesRestored)
    ) {
      // Очищаем локальное состояние файлов
      setFiles(prevFiles =>
        prevFiles.map(file => ({ ...file, userFiles: [] })),
      );
      // Очищаем файлы в форме
      handleChangeFiles([], { shouldDirty: false });
    }

    // Обновляем предыдущие значения
    prevSenderStationIdRef.current = currentSenderStationId;
    prevReceiverStationIdRef.current = currentReceiverStationId;
  }, [senderStation?.id, receiverStation?.id, loading]);

  const handleRemoveFile = (id: string) => {
    setFiles(prevFiles => {
      const newFilesForTable = prevFiles.map(file =>
        file.id === id ? { ...file, userFiles: [] } : file,
      );

      const newFilesForForm = mapFilesToFormValue(newFilesForTable);

      handleChangeFiles(newFilesForForm, { shouldDirty: true });

      return newFilesForTable;
    });
  };

  const handleLoadFile = async (id: string, loadedFile: FileList | null) => {
    if (!loadedFile) return;

    const convertedFile = await toBase64(loadedFile[0]);
    setFiles(prevFiles => {
      const newFilesForTable = prevFiles.map(file =>
        file.id === id
          ? {
              ...file,
              userFiles: [
                {
                  content: convertedFile,
                },
              ],
            }
          : file,
      ) as IrcInstructionTypeFile[];

      const newFilesForForm = mapFilesToFormValue(newFilesForTable);

      handleChangeFiles(newFilesForForm, { shouldDirty: true });
      return newFilesForTable;
    });
  };

  return (
    <>
      <Typography className="mb-4" fontStyle={10} fontWeight={700}>
        Вложения
      </Typography>
      <DataTable
        dataKey="id"
        value={files}
        size="small"
        tableStyle={{ minWidth: '80rem' }}
        emptyMessage="Нет вложений"
      >
        <Column
          style={{ width: '5%' }}
          body={rowData => {
            const fileContent = rowData?.userFiles?.[0]?.content;
            const downloadHref = getFileDownloadHref(
              fileContent,
              rowData?.fileFormat,
            );
            const displayBase = getDisplayName(rowData);
            const downloadName = sanitizeFileName(
              `${displayBase || 'file'}${rowData?.fileFormat?.name ? `.${rowData.fileFormat.name}` : ''}`,
            );

            return (
              <a
                className="styled-like-a-button"
                download={downloadName}
                href={downloadHref}
                onClick={e => {
                  if (!fileContent) {
                    e.preventDefault();
                  }
                }}
              >
                <Button
                  className="gap-0 ml-2"
                  size="small"
                  variant="primary"
                  icon="pi pi-download"
                  disabled={!fileContent}
                ></Button>
              </a>
            );
          }}
        ></Column>
        <Column
          header="Наименование файла"
          body={rowData => getDisplayName(rowData) || 'Файл'}
          style={{ width: '50%' }}
        ></Column>
        <Column
          header="Формат"
          body={rowData => rowData?.fileFormat?.name}
          style={{ width: '15%' }}
        ></Column>
        <Column
          header="Загрузить файл"
          style={{ width: '30%' }}
          body={rowData => {
            return (
              <div>
                {rowData?.userFiles?.length > 0 ? (
                  <div className="flex flex-row align-items-center">
                    Файл загружен
                    <Button
                      className="gap-0 ml-2"
                      size="small"
                      variant="danger"
                      icon="pi pi-trash"
                      onClick={() => handleRemoveFile(rowData?.id)}
                      disabled={isDisabled}
                    ></Button>
                  </div>
                ) : (
                  <input
                    type="file"
                    name="file"
                    accept={`.${rowData?.fileFormat?.name}`}
                    onChange={e => {
                      handleLoadFile(rowData?.id, e.target.files);
                    }}
                    disabled={isDisabled}
                  />
                )}
              </div>
            );
          }}
        ></Column>
      </DataTable>
    </>
  );
};
