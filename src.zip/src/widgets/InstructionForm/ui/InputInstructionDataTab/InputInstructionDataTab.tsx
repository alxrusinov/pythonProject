import { Box, Divider } from 'shared_ui/components';

import { useRestoreInstructionData } from '../../model/useRestoreInstructionData';
import { CarsTable } from './Fields/CarsTable';
import { DefaultFields } from './Fields/DefaultFields/DefaultFields';
import { FilesTable } from './Fields/FilesTable';
import { IrcAdditionalInfoFields } from './Fields/IrcAdditionalInfoFields';
import { IrcCargoInfoFields } from './Fields/IrcCargoInfoFields';
// import { IrcPPSFields } from './Fields/IrcPPSFields';
import { IrcRecieverFields } from './Fields/IrcRecieverFields';
import { IrcRecieverInfoFields } from './Fields/IrcRecieverInfoFields';
// import { IrcRepairFields } from './Fields/IrcRepairFields';
import { IrcSenderFields } from './Fields/IrcSenderFields';
import { RoutesTable } from './Fields/RoutesTable';

export const InputInstructionDataTab = () => {
  useRestoreInstructionData();

  return (
    <Box className="flex flex-column gap-2 flex-grow-1 max-w-full overflow-auto">
      <div className="grid row-gap-1">
        <div className="flex flex-column col-2">
          <CarsTable />
        </div>

        <div className="flex flex-column col-10 mb-4">
          <div className="grid align-center">
            <div className="col-10 divider-bottom">
              <DefaultFields />
            </div>
            <div className="col-10 divider-bottom">
              <IrcRecieverInfoFields />
            </div>
            <div className="col-10 divider-bottom ">
              <IrcSenderFields />
            </div>
            <div className="col-10 divider-bottom">
              <IrcRecieverFields />
            </div>
            <div className="col-10 divider-bottom ">
              <IrcCargoInfoFields />
            </div>
            {/* TODO пока попросили скрыть */}
            {/* <div className="col-10 divider-bottom ">
              <IrcPPSFields />
            </div>
            <div className="col-10 divider-bottom">
              <IrcRepairFields />
            </div> */}
            <div className="col-10 divider-bottom">
              <IrcAdditionalInfoFields />
            </div>
          </div>
        </div>
        <Divider />
        <div className="flex flex-column col-12 mb-4">
          <RoutesTable />
        </div>

        <div className="flex flex-column col-12">
          <FilesTable />
        </div>
      </div>
    </Box>
  );
};
