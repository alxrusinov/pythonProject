import {
  NsiStation,
  useGetNsiStationsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchSenderSationsProps = {
  restoredSenderSations: NsiStation | null;
};

export const useGetSenderNsiStationsApi = ({
  restoredSenderSations,
}: useSearchSenderSationsProps) => {
  const [search, setSearch] = useState('');
  const [fetchStations, { data }] = useGetNsiStationsLazyQuery();

  const handleChangeSenderSationsSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchStations({
        variables: {
          where: { name: { icontains: q } },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchStations],
  );

  const senderSations = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiStations?.items ?? [])
      : [];

    return restoredSenderSations
      ? compareRecords(items, restoredSenderSations)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredSenderSations, search]);

  return {
    handleChangeSenderSationsSearch,
    senderSations,
  };
};
