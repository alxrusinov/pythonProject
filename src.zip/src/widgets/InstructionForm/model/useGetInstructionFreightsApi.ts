import {
  NsiFreight,
  useGetNsiFreightsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchFreightProps = {
  restoredFreight: NsiFreight | null;
};

export const useGetInstructionFreightsApi = ({
  restoredFreight,
}: useSearchFreightProps) => {
  const [search, setSearch] = useState('');
  const [fetchFreights, { data }] = useGetNsiFreightsLazyQuery();

  const handleChangeFreightSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchFreights({
        variables: {
          where: {
            or: [{ name: { icontains: q } }, { codeEtsng: { icontains: q } }],
          },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchFreights],
  );

  const freights = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiFreights?.items ?? [])
      : [];

    return restoredFreight
      ? compareRecords(items, restoredFreight)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredFreight, search]);

  return {
    handleChangeFreightSearch,
    freights,
  };
};
