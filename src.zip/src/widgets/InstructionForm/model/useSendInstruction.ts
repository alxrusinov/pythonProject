import {
  useEntityNotificationsSubscription,
  useIrcOrgEmailsByOrgIdLazyQuery,
  useSendInstructionMutation,
} from 'graphql/generated/generated';
import { useMemo, useRef, useState } from 'react';
import { generatePath, useNavigate } from 'react-router-dom';

import { makeNotification } from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { paths } from 'shared/routes/paths';
import { buildPath } from 'shared/utils/buildPath';
import {
  decodeOperationError,
  IRC_INSTRUCTION_OPERATION_ERROR_MESSAGES,
} from 'shared/utils/decodeOperationError';

import { hasInstructionRecipientEmails } from '../lib/hasInstructionRecipientEmails';
import { CreateInstructionFormValues } from '../lib/types';

// Важно: ответ по WS может приходить с любым entityType, поэтому подписываемся без фильтра.
const SUBSCRIBE_ALL_ENTITY_TYPES: string[] | undefined = undefined;

type UseSendInstructionProps = {
  getFormValues: () => CreateInstructionFormValues;
  requestDate: string;
};

export const useSendInstruction = ({
  getFormValues,
  requestDate,
}: UseSendInstructionProps) => {
  const navigate = useNavigate();
  const sendInstructionUUID = useMemo(() => UUID(), []);
  const sendInFlightRef = useRef(false);
  const handledSendNotificationRef = useRef(false);

  const [sendInstructionMutation] = useSendInstructionMutation();
  const [loadOrgEmails] = useIrcOrgEmailsByOrgIdLazyQuery();
  const [isSendPending, setSendPending] = useState(false);

  const subscriptionVariables = useMemo(
    () => ({
      entityTypes: SUBSCRIBE_ALL_ENTITY_TYPES,
    }),
    [],
  );

  useEntityNotificationsSubscription({
    variables: subscriptionVariables,
    shouldResubscribe: true,
    onData: ({ data }) => {
      const notification = data.data?.entityNotifications;
      if (!notification) return;
      if (!sendInFlightRef.current) return;
      if (notification.correlationId !== sendInstructionUUID) return;
      if (handledSendNotificationRef.current) return;

      handledSendNotificationRef.current = true;
      sendInFlightRef.current = false;
      setSendPending(false);

      if (notification.error) {
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: decodeOperationError(notification.error, 'instruction'),
        });
        return;
      }

      if (notification.entityId) {
        makeNotification({
          variant: 'success',
          title: 'Успех!',
          message: `Инструкция отправлена успешно`,
        });
        navigate(buildPath(generatePath(paths.carInstructions)));
      }
    },
    onError: () => {
      if (!sendInFlightRef.current) return;
      handledSendNotificationRef.current = true;
      sendInFlightRef.current = false;
      setSendPending(false);
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: `Ошибка отправки инструкции`,
      });
    },
  });

  const sendInstruction = async (id: string) => {
    try {
      const hasRecipientEmails = await hasInstructionRecipientEmails(
        getFormValues(),
        loadOrgEmails,
        requestDate,
      );

      if (!hasRecipientEmails) {
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message:
            IRC_INSTRUCTION_OPERATION_ERROR_MESSAGES.EMAIL_RECIPIENTS_NOT_FOUND,
        });
        return;
      }

      sendInFlightRef.current = true;
      handledSendNotificationRef.current = false;
      setSendPending(true);
      await sendInstructionMutation({
        variables: {
          input: {
            id,
            correlationId: sendInstructionUUID,
          },
        },
      });
    } catch {
      sendInFlightRef.current = false;
      setSendPending(false);
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Непредвиденная ошибка при выполнении запроса',
      });
    }
  };

  return { sendInstruction, isSendPending };
};
