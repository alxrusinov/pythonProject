import { FieldErrors } from 'react-hook-form';

import { makeNotification } from 'shared_ui/components';

import { CreateInstructionFormValues } from '../lib/types';
import { validateInstructionForm } from './validateInstructionForm';

type UseInstructionInvalidProps = {
  getValues: () => CreateInstructionFormValues;
};

export const useInstructionInvalid = ({
  getValues,
}: UseInstructionInvalidProps) => {
  const handleInvalid = (errors: FieldErrors<CreateInstructionFormValues>) => {
    if (errors.inputInstructionDataTab) {
      const validationResult = validateInstructionForm(getValues());
      const message =
        validationResult.missingFields.length > 0
          ? `Не заполнены обязательные поля: ${validationResult.missingFields.join(', ')}`
          : 'Не заполнены обязательные поля';
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message,
      });
    }
  };

  return { handleInvalid };
};
