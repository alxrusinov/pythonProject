import { useParams } from 'react-router-dom';

import { InstructionParams } from '../lib/types';
import { useCancelInstruction } from './useCancelInstruction';
import { useInstructionFormDefaults } from './useInstructionFormDefaults';
import { useInstructionFormSubmit } from './useInstructionFormSubmit';
import { useInstructionLookupRequestDate } from './useInstructionLookupRequestDate';
import { useInstructionTabs } from './useInstructionTabs';
import { useSendInstruction } from './useSendInstruction';

export const useCreateInstruction = () => {
  const { masterId } = useParams<InstructionParams>();

  const { methods } = useInstructionFormDefaults(masterId);

  const { tabSteps, activeTab, handleTabValidate } = useInstructionTabs(
    methods,
    masterId || null,
  );

  const {
    saveForm,
    registerForm,
    correctForm,
    isSubmitting: isSubmitSubmitting,
    saveSuccessTick,
  } = useInstructionFormSubmit({
    methods,
  });

  const { cancelInstruction } = useCancelInstruction();
  const requestDate = useInstructionLookupRequestDate();
  const { sendInstruction, isSendPending } = useSendInstruction({
    getFormValues: methods.getValues,
    requestDate,
  });

  const isSubmitting = isSubmitSubmitting || isSendPending;

  return {
    methods,
    activeTab,
    handleTabValidate,
    saveForm,
    registerForm,
    cancelInstruction,
    correctForm,
    sendInstruction,
    tabSteps,
    isSubmitting,
    saveSuccessTick,
  };
};
