import {
  NsiStation,
  useGetNsiStationsLazyQuery,
} from 'graphql/generated/generated';
import { useEffect, useState } from 'react';

import { getStableRequestDate } from 'shared/utils/date';

type useGetRoutesStationsInfoProps = {
  stationIds: number[];
};

export const useGetRoutesStationsInfoApi = ({
  stationIds,
}: useGetRoutesStationsInfoProps) => {
  const [routesStations, setRoutesStations] = useState<NsiStation[]>([]);
  const [fetchStations, { data }] = useGetNsiStationsLazyQuery();

  useEffect(() => {
    if (stationIds.length === 0) {
      setRoutesStations([]);
      return;
    }

    fetchStations({
      variables: {
        where: {
          and: [{ lastRec: { eq: true } }, { id: { in: stationIds } }],
        },
        requestDate: getStableRequestDate(),
      },
    });
  }, [stationIds, fetchStations]);

  useEffect(() => {
    setRoutesStations(data?.nsiStations?.items || []);
  }, [data]);

  return {
    routesStations,
  };
};
