import { useImpOrgPassportsQuery } from 'graphql/generated/generated';

export const useImpOrgAdressesApi = () => {
  const { data } = useImpOrgPassportsQuery();
  const organizationsAdresses = data?.impOrgPassports?.items || [];

  return { organizationsAdresses };
};
