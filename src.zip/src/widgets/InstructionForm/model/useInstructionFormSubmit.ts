import {
  GetInstructionsDocument,
  IrcCreateInstructionInput,
  IrcInstructionRouteInput,
  useCreateInstructionMutation,
  useEntityNotificationsSubscription,
  useUpdateInstructionMutation,
} from 'graphql/generated/generated';
import { useMemo, useRef, useState } from 'react';
import { UseFormReturn } from 'react-hook-form';
import {
  generatePath,
  useNavigate,
  useParams,
  useSearchParams,
} from 'react-router-dom';

import { useApolloClient } from '@apollo/client';

import { makeNotification } from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { paths } from 'shared/routes/paths';
import { buildPath } from 'shared/utils/buildPath';
import { decodeOperationError } from 'shared/utils/decodeOperationError';

import { CreateInstructionFormValues } from '../lib/types';
import { useInstructionInvalid } from './useInstructionInvalid';
import { validateInstructionForm } from './validateInstructionForm';

type UseInstructionFormSubmitProps = {
  methods: UseFormReturn<CreateInstructionFormValues>;
};

// Ответы по WS могут приходить с другим entityType, поэтому подписываемся без фильтра.
const SUBSCRIBE_ALL_ENTITY_TYPES: string[] | undefined = undefined;

export const useInstructionFormSubmit = ({
  methods,
}: UseInstructionFormSubmitProps) => {
  const { masterId } = useParams();
  const [searchParams] = useSearchParams();
  const apolloClient = useApolloClient();

  const [createInstructionMutation] = useCreateInstructionMutation();
  const [updateInstructionMutation] = useUpdateInstructionMutation();

  const navigate = useNavigate();

  const { handleSubmit, reset, getValues } = methods;
  const { handleInvalid } = useInstructionInvalid({ getValues });

  const createInstructionUUID = useMemo(() => UUID(), []);
  const updateInstructionUUID = useMemo(() => UUID(), []);
  const correctInstructionUUID = useMemo(() => UUID(), []);

  const [isCreatePending, setCreatePending] = useState(false);
  const [isUpdatePending, setUpdatePending] = useState(false);
  const [isCorrectPending, setCorrectPending] = useState(false);
  const [saveSuccessTick, setSaveSuccessTick] = useState(0);
  const calcDateParam = searchParams.get('calcDate');

  const createInFlightRef = useRef(false);
  const updateInFlightRef = useRef(false);
  const correctInFlightRef = useRef(false);
  const handledCreateNotificationRef = useRef(false);
  const handledUpdateNotificationRef = useRef(false);
  const handledCorrectNotificationRef = useRef(false);

  const buildEditInstructionPath = (entityId: string, calcDate?: number) => {
    const basePath = buildPath(
      generatePath(paths.editInstruction, {
        masterId: entityId,
      }),
    );
    const calcDateValue =
      calcDate ?? (calcDateParam ? Number(calcDateParam) : null);

    if (calcDateValue == null || Number.isNaN(calcDateValue)) return basePath;
    return `${basePath}?calcDate=${encodeURIComponent(String(calcDateValue))}`;
  };

  const subscriptionVariables = useMemo(
    () => ({
      entityTypes: SUBSCRIBE_ALL_ENTITY_TYPES,
    }),
    [],
  );

  useEntityNotificationsSubscription({
    variables: subscriptionVariables,
    shouldResubscribe: true,
    onData: ({ data }) => {
      const notification = data.data?.entityNotifications;
      if (!notification) return;

      if (
        notification.correlationId === createInstructionUUID &&
        createInFlightRef.current &&
        !handledCreateNotificationRef.current
      ) {
        handledCreateNotificationRef.current = true;
        createInFlightRef.current = false;
        setCreatePending(false);

        if (notification.error) {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: decodeOperationError(notification.error, 'instruction'),
          });
          return;
        }

        if (notification.entityId) {
          makeNotification({
            variant: 'success',
            title: 'Успех!',
            message: `Инструкция создана успешно`,
          });

          apolloClient.refetchQueries({
            include: [GetInstructionsDocument],
          });

          navigate(buildEditInstructionPath(notification.entityId));
          setSaveSuccessTick(tick => tick + 1);
        }
        return;
      }

      if (
        notification.correlationId === correctInstructionUUID &&
        correctInFlightRef.current &&
        !handledCorrectNotificationRef.current
      ) {
        handledCorrectNotificationRef.current = true;
        correctInFlightRef.current = false;
        setCorrectPending(false);

        if (notification.error) {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: decodeOperationError(notification.error, 'instruction'),
          });
          return;
        }

        if (notification.entityId) {
          makeNotification({
            variant: 'success',
            title: 'Успех!',
            message: `Инструкция скорректирована успешно`,
          });

          navigate(buildEditInstructionPath(notification.entityId, Date.now()));
          setSaveSuccessTick(tick => tick + 1);
        }
        return;
      }

      if (
        notification.correlationId === updateInstructionUUID &&
        updateInFlightRef.current &&
        !handledUpdateNotificationRef.current
      ) {
        handledUpdateNotificationRef.current = true;
        updateInFlightRef.current = false;
        setUpdatePending(false);

        if (notification.error) {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: decodeOperationError(notification.error, 'instruction'),
          });
          return;
        }

        if (notification.entityId) {
          makeNotification({
            variant: 'success',
            title: 'Успех!',
            message: `Инструкция сохранена успешно`,
          });

          apolloClient.refetchQueries({
            include: [GetInstructionsDocument],
          });

          const currentValues = getValues();
          reset(currentValues);
          setSaveSuccessTick(tick => tick + 1);
        }
      }
    },
    onError: () => {
      if (createInFlightRef.current && !handledCreateNotificationRef.current) {
        handledCreateNotificationRef.current = true;
        createInFlightRef.current = false;
        setCreatePending(false);
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: `Ошибка создания инструкции`,
        });
      }
      if (updateInFlightRef.current && !handledUpdateNotificationRef.current) {
        handledUpdateNotificationRef.current = true;
        updateInFlightRef.current = false;
        setUpdatePending(false);
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: `Ошибка сохранения инструкции`,
        });
      }
      if (
        correctInFlightRef.current &&
        !handledCorrectNotificationRef.current
      ) {
        handledCorrectNotificationRef.current = true;
        correctInFlightRef.current = false;
        setCorrectPending(false);
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: `Ошибка корректировки инструкции`,
        });
      }
    },
  });

  const onSubmit =
    (createInstruction: boolean) =>
    async (formData: CreateInstructionFormValues) => {
      // Проверка обязательных полей перед отправкой
      const validationResult = validateInstructionForm(formData);

      // Если есть незаполненные поля, прерываем выполнение
      if (!validationResult.isValid) {
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: `Не заполнены обязательные поля: ${validationResult.missingFields.join(', ')}`,
        });
        return;
      }

      const preparedCars = formData?.inputInstructionDataTab?.cars
        ? formData.inputInstructionDataTab.cars.map(car => {
            return {
              number: car.number || '',
              prevFrId:
                formData?.inputInstructionDataTab?.customPrevFreight?.id ??
                null,
              prevGngFrId:
                formData?.inputInstructionDataTab?.customPrevGngFreight?.id ??
                null,
            };
          })
        : [];

      const isRecieverRoute = (sequenceNumber: number) =>
        sequenceNumber === 1000;

      /** Адреса на бэк уходят только как recipAddressId в IrcInstructionRouteInput (не целиком объекты) */
      const senderRecipAddressId =
        formData?.inputInstructionDataTab?.customSenderAddress?.id ?? null;
      const recieverRecipAddressId =
        formData?.inputInstructionDataTab?.customRecieverAddress?.id ?? null;

      const preparedRoutes: IrcInstructionRouteInput[] = formData
        ?.inputInstructionDataTab?.routes
        ? [...formData.inputInstructionDataTab.routes]
            .sort((a, b) => (a?.sequenceNumber ?? 0) - (b?.sequenceNumber ?? 0))
            .map(route => {
              return {
                // sequenceNumber = 1 грузоотправитель
                // sequenceNumber = 1000 грузоплучатель
                contractId: null,
                contractTypeId: null,
                distanceDelta: route?.distanceDelta || 0,
                manualPayerCode: route?.manualPayerCode || null,
                manualPayerName: route?.manualPayerName || null,
                manualPayerSubCode: route?.manualPayerSubCode || null,
                ntsPayerFlag: !!route?.ntsPayerFlag,
                payerId: route?.payer?.id || null,
                recipAddressId: isRecieverRoute(route?.sequenceNumber ?? 0)
                  ? recieverRecipAddressId
                  : senderRecipAddressId,
                recipId: isRecieverRoute(route?.sequenceNumber ?? 0)
                  ? formData?.inputInstructionDataTab?.recieverRecip?.id || null
                  : formData?.inputInstructionDataTab?.senderRecip?.id || null,
                manualRecipAddress: isRecieverRoute(route?.sequenceNumber ?? 0)
                  ? formData?.inputInstructionDataTab
                      ?.customManualRecieverAddress
                  : formData?.inputInstructionDataTab
                      ?.customManualSenderAddress,
                manualRecipName: isRecieverRoute(route?.sequenceNumber ?? 0)
                  ? formData?.inputInstructionDataTab?.customManualRecieverName
                  : formData?.inputInstructionDataTab?.customManualSenderName,
                manualRecipOkpo: isRecieverRoute(route?.sequenceNumber ?? 0)
                  ? formData?.inputInstructionDataTab?.customManualRecieverOkpo
                  : formData?.inputInstructionDataTab?.customManualSenderOkpo,
                manualRecipTgnl: isRecieverRoute(route?.sequenceNumber ?? 0)
                  ? formData?.inputInstructionDataTab?.customManualRecieverTgnl
                  : formData?.inputInstructionDataTab?.customManualSenderTgnl,
                sequenceNumber: route?.sequenceNumber || 0,
                stId: route?.station?.id || 0,
              };
            })
        : [];

      const clientEmails =
        formData?.inputInstructionDataTab?.customClientsEmails ?? '';
      const preparedClientEmails = clientEmails
        ? clientEmails
            .split(/[,\s]+/)
            .map(email => {
              return { clientEmail: email };
            })
            .filter(email => !!email.clientEmail)
        : [];

      const instructionInputData: IrcCreateInstructionInput = {
        correlationId: createInstructionUUID,
        accompTextId: formData?.inputInstructionDataTab?.accompText
          ?.id as number,
        clientId: formData?.inputInstructionDataTab?.client?.id, // Получатель инструкции
        clientEmailText:
          formData?.inputInstructionDataTab?.clientEmailText || '',
        frId: formData?.inputInstructionDataTab?.freight?.id ?? null,
        gngFrId: formData?.inputInstructionDataTab?.gngFreight?.id ?? null,
        instructionTypeId: formData?.inputInstructionDataTab?.types?.id || '',
        manualClientName: formData?.inputInstructionDataTab?.manualClientName, // Наименование получателя
        notForCarrierText: formData?.inputInstructionDataTab?.notForCarrierText,
        optionalMarksText: formData?.inputInstructionDataTab?.optionalMarksText,
        stationFromName: formData?.inputInstructionDataTab?.stationFromName,
        claims: [],
        routes: preparedRoutes || [],
        userFiles: Array.isArray(formData?.inputInstructionDataTab?.userFiles)
          ? formData.inputInstructionDataTab.userFiles.filter(f => {
              const content =
                typeof f?.content === 'string' ? f.content.trim() : '';
              const instructionTypeFileId = f?.instructionTypeFileId;
              return Boolean(instructionTypeFileId) && Boolean(content);
            })
          : [],
        cars: preparedCars,
        clients: preparedClientEmails,
      };

      try {
        if (createInstruction && !masterId) {
          createInFlightRef.current = true;
          handledCreateNotificationRef.current = false;
          setCreatePending(true);
          createInstructionMutation({
            variables: {
              input: {
                ...instructionInputData,
                correlationId: createInstructionUUID,
              },
            },
            refetchQueries: [{ query: GetInstructionsDocument }],
          });
        }

        if (!createInstruction && masterId) {
          updateInFlightRef.current = true;
          handledUpdateNotificationRef.current = false;
          setUpdatePending(true);
          updateInstructionMutation({
            variables: {
              input: {
                ...instructionInputData,
                id: masterId,
                correlationId: updateInstructionUUID,
              },
            },
          });
        }

        if (createInstruction && masterId) {
          correctInFlightRef.current = true;
          handledCorrectNotificationRef.current = false;
          setCorrectPending(true);
          createInstructionMutation({
            variables: {
              input: {
                ...instructionInputData,
                parentId: masterId,
                correlationId: correctInstructionUUID,
              },
            },
          });
        }
      } catch {
        createInFlightRef.current = false;
        updateInFlightRef.current = false;
        correctInFlightRef.current = false;
        setCreatePending(false);
        setUpdatePending(false);
        setCorrectPending(false);
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: 'Непредвиденная ошибка при выполнении запроса',
        });
      }
    };

  const saveForm = () => {
    handleSubmit(onSubmit(false), handleInvalid)();
  };

  const registerForm = () => {
    handleSubmit(onSubmit(true), handleInvalid)();
  };

  const correctForm = () => {
    handleSubmit(onSubmit(true), handleInvalid)();
  };

  const isSubmitting = isCreatePending || isUpdatePending || isCorrectPending;

  return { saveForm, registerForm, correctForm, isSubmitting, saveSuccessTick };
};
