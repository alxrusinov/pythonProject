import {
  NsiGngFreight2001,
  useGetNsiGngFreights2001LazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchPrevGngFreightProps = {
  restoredPrevGngFreight: NsiGngFreight2001 | null;
};

export const useGetInstructionPrevGngFreightsApi = ({
  restoredPrevGngFreight,
}: useSearchPrevGngFreightProps) => {
  const [search, setSearch] = useState('');
  const [fetchGngFreights, { data }] = useGetNsiGngFreights2001LazyQuery();

  const handleChangePrevGngFreightSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchGngFreights({
        variables: {
          where: {
            or: [{ name: { icontains: q } }, { code: { icontains: q } }],
          },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchGngFreights],
  );

  const prevGngFreights = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiGngFreights2001?.items ?? [])
      : [];

    return restoredPrevGngFreight
      ? compareRecords(items, restoredPrevGngFreight)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredPrevGngFreight, search]);

  return {
    handleChangePrevGngFreightSearch,
    prevGngFreights,
  };
};
