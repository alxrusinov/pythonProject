import { useGetInstructionsByIdQuery } from 'graphql/generated/generated';
import { useMemo } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';

import { resolveInstructionLookupRequestDate } from '../lib/resolveInstructionLookupRequestDate';
import { InstructionParams } from '../lib/types';

export const useGetRestoredInstructionData = () => {
  const { masterId } = useParams<InstructionParams>();
  const [searchParams] = useSearchParams();

  const copyFrom = searchParams.get('copyFrom');
  const instructionId = masterId ?? copyFrom ?? null;
  const shouldSkip = !instructionId;

  const calcDateParam = searchParams.get('calcDate');
  const requestDate = useMemo(
    () => resolveInstructionLookupRequestDate(calcDateParam),
    [calcDateParam, instructionId],
  );

  const { data, loading, refetch } = useGetInstructionsByIdQuery({
    variables: shouldSkip
      ? undefined
      : {
          where: { id: { eq: instructionId } },
          requestDate,
        },
    skip: shouldSkip,
    fetchPolicy: 'network-only',
    nextFetchPolicy: 'network-only',
  });

  const disabled = false;

  return {
    restoredInstructionData: data?.ircInstructions?.items?.[0] || null,
    loading,
    disabled,
    refetch,
  };
};
