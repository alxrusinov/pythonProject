import { useEffect, useState } from 'react';
import { UseFormReturn } from 'react-hook-form';

import { makeNotification } from 'shared_ui/components';

import { useInstructionFormTabMenuStore } from 'features/InstructionFormTabMenu';

import { TabMenuElements } from 'shared/types/common';
import { countErrors } from 'shared/utils/countErrors';

import {
  CREATE_INSTRUCTION_FORM_NAMES,
  CREATE_INSTRUCTION_FORM_STEPS,
  EDIT_INSTRUCTION_FORM_STEPS,
} from '../lib/constants';
import { getInputInstructionDataTabFieldName } from '../lib/getFormFields';
import { CreateInstructionFormValues } from '../lib/types';

const PRINT_FORM_STEP_VALUE = EDIT_INSTRUCTION_FORM_STEPS[1].value;

export const useInstructionTabs = (
  methods: UseFormReturn<CreateInstructionFormValues>,
  masterId: string | null,
) => {
  const {
    trigger,
    formState: { errors, isDirty },
  } = methods;

  const ACTUAL_TAB_STEPS = masterId
    ? EDIT_INSTRUCTION_FORM_STEPS
    : CREATE_INSTRUCTION_FORM_STEPS;

  const initialTab = ACTUAL_TAB_STEPS[0].value;

  const [tabSteps, setTabSteps] = useState(ACTUAL_TAB_STEPS);

  const setActiveTab = useInstructionFormTabMenuStore(
    state => state.setActiveTab,
  );

  const inputInstructionDataTabErrorsAmount = countErrors(
    errors?.inputInstructionDataTab,
  );

  const activeTab =
    useInstructionFormTabMenuStore(state => state.activeTab) ?? initialTab;

  useEffect(() => {
    const steps = masterId
      ? EDIT_INSTRUCTION_FORM_STEPS
      : CREATE_INSTRUCTION_FORM_STEPS;
    setTabSteps(steps);
    const validStepValues = steps.map(step => step.value);
    const firstTab = steps[0].value;
    if (!activeTab || !validStepValues.includes(activeTab)) {
      setActiveTab(firstTab);
    }
  }, [masterId, activeTab, setActiveTab]);

  useEffect(() => {
    return () => {
      setActiveTab(CREATE_INSTRUCTION_FORM_STEPS[0].value);
    };
  }, [setActiveTab]);

  useEffect(() => {
    setTabSteps(prev =>
      prev.map(step => {
        if (step.value === ACTUAL_TAB_STEPS[0].value) {
          return {
            ...step,
            indicator:
              inputInstructionDataTabErrorsAmount !== 0
                ? String(inputInstructionDataTabErrorsAmount)
                : undefined,
          } satisfies TabMenuElements;
        }

        return step;
      }),
    );
  }, [inputInstructionDataTabErrorsAmount]);

  const handleTabValidate = async (nextTab: string) => {
    if (nextTab === PRINT_FORM_STEP_VALUE && isDirty) {
      makeNotification({
        variant: 'warning',
        title: 'Внимание',
        message:
          'Сохраните изменения перед переходом на вкладку «Печатная форма»',
      });
      return false;
    }

    if (activeTab === ACTUAL_TAB_STEPS[0].value) {
      const valid = await trigger(
        getInputInstructionDataTabFieldName(
          CREATE_INSTRUCTION_FORM_NAMES.NUMBER,
        ),
      );
      if (!valid) return false;
    }
  };

  return { tabSteps, activeTab, handleTabValidate };
};
