import { DefaultValues, useForm } from 'react-hook-form';

import { CreateInstructionFormValues } from '../lib/types';

export const useInstructionFormDefaults = (masterId?: string) => {
  const defaultValues: DefaultValues<CreateInstructionFormValues> = {
    inputInstructionDataTab: {},
  };

  const methods = useForm<CreateInstructionFormValues>({
    mode: 'all',
    defaultValues: !masterId ? defaultValues : undefined,
  });

  return { methods };
};
