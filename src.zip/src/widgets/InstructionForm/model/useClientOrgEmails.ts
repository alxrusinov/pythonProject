import { useIrcOrgEmailsByOrgIdLazyQuery } from 'graphql/generated/generated';
import { useEffect, useState } from 'react';

import { useInstructionLookupRequestDate } from './useInstructionLookupRequestDate';

export const useClientOrgEmails = (orgId?: number | string | null) => {
  const [emails, setEmails] = useState<string[]>([]);
  const [loadByOrgId] = useIrcOrgEmailsByOrgIdLazyQuery();
  const requestDate = useInstructionLookupRequestDate();
  const normalizedOrgId = orgId != null && orgId !== '' ? Number(orgId) : null;

  useEffect(() => {
    if (normalizedOrgId == null || Number.isNaN(normalizedOrgId)) {
      setEmails([]);
      return;
    }

    let cancelled = false;

    const loadEmails = async () => {
      const result = await loadByOrgId({
        variables: {
          orgId: normalizedOrgId,
          requestDate,
        },
        fetchPolicy: 'no-cache',
      });

      if (cancelled) return;

      const nextEmails = (result.data?.ircOrgEmails?.items ?? [])
        .map(item => item?.email?.trim() ?? '')
        .filter(Boolean);

      setEmails(nextEmails);
    };

    loadEmails();

    return () => {
      cancelled = true;
    };
  }, [normalizedOrgId, loadByOrgId, requestDate]);

  return emails;
};
