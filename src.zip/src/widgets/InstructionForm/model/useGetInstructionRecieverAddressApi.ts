import {
  ImpOrgAddress,
  ImpOrgPassport,
  useGetImpOrgAddressLazyQuery,
} from 'graphql/generated/generated';
import { useEffect, useMemo } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';
import { enrichImpOrgAddressesForSelect } from 'shared/utils/formatImpOrgAddressSelectLabel';

type useSearchRecieverAddressProps = {
  restoredRecieverRecip: ImpOrgPassport | null;
  restoredRecieverAddress: ImpOrgAddress | null;
};

export const useGetInstructionRecieverAddressApi = ({
  restoredRecieverAddress,
  restoredRecieverRecip,
}: useSearchRecieverAddressProps) => {
  const [fetchAddresses, { data, loading }] = useGetImpOrgAddressLazyQuery();

  useEffect(() => {
    if (restoredRecieverRecip?.id == null) return;

    fetchAddresses({
      variables: {
        where: {
          orgPassport: { id: { eq: restoredRecieverRecip.id } },
          lastRec: { eq: true },
        },
        requestDate: getStableRequestDate(),
      },
    });
  }, [restoredRecieverRecip?.id, fetchAddresses]);

  const backendRecieverAddresses = data?.impOrgAddresses?.items || [];

  const recieverAddressesForSelect = useMemo(
    () =>
      enrichImpOrgAddressesForSelect(
        restoredRecieverAddress &&
          restoredRecieverAddress?.orgPassport?.id === restoredRecieverRecip?.id
          ? compareRecords(backendRecieverAddresses, restoredRecieverAddress)
          : backendRecieverAddresses,
      ),
    [
      backendRecieverAddresses,
      restoredRecieverAddress,
      restoredRecieverRecip?.id,
    ],
  );

  return {
    recieverAddresses: recieverAddressesForSelect,
    recieverAddressesBackendCount: backendRecieverAddresses.length,
    recieverAddressesLoading: loading,
  };
};
