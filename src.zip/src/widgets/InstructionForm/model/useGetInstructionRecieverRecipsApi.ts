import {
  ImpOrgPassport,
  useImpOrgPassportsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import {
  FILTER_TYPE_NAME_KONTRAGENT,
  impOrgPassportMatchesCounterpartyType,
} from '../lib/constants';
import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchRecieverRecipProps = {
  restoredRecieverRecip: ImpOrgPassport | null;
};

export const useGetInstructionRecieverRecipsApi = ({
  restoredRecieverRecip,
}: useSearchRecieverRecipProps) => {
  const [search, setSearch] = useState('');
  const [fetchRecips, { data }] = useImpOrgPassportsLazyQuery();

  const handleChangeRecieverRecipSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchRecips({
        variables: {
          where: {
            and: [
              { lastRec: { eq: true } },
              {
                or: [
                  { typeName: { iin: [FILTER_TYPE_NAME_KONTRAGENT] } },
                  { typeName: { icontains: FILTER_TYPE_NAME_KONTRAGENT } },
                ],
              },
              {
                or: [
                  { shortName: { icontains: q } },
                  { okpo: { icontains: q } },
                ],
              },
            ],
          },
          requestDate: getStableRequestDate(),
          take: 200,
        },
      });
    },
    [fetchRecips],
  );

  const recieverRecips = useMemo(() => {
    const raw = canFetchLookup(search)
      ? (data?.impOrgPassports?.items ?? []).filter(item =>
          impOrgPassportMatchesCounterpartyType(item.typeName),
        )
      : [];

    return restoredRecieverRecip
      ? compareRecords(raw, restoredRecieverRecip)
      : [...raw, { id: null, name: undefined }];
  }, [data, restoredRecieverRecip, search]);

  return {
    handleChangeRecieverRecipSearch,
    recieverRecips,
  };
};
