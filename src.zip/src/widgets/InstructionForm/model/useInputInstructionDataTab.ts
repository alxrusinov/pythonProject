import {
  CalculationType,
  IrcInstructionRoute,
  IrcInstructionUserFileInput,
} from 'graphql/generated/generated';
import { useFormContext } from 'react-hook-form';

import { DropdownChangeEvent } from 'shared_ui/primereact';

import { CREATE_INSTRUCTION_FORM_NAMES } from '../lib/constants';
import { getInputInstructionDataTabFieldName } from '../lib/getFormFields';
import { CreateInstructionFormValues } from '../lib/types';

export const useInputInstructionDataTab = () => {
  const { setValue, clearErrors } =
    useFormContext<CreateInstructionFormValues>();

  const handleSenderStationChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION,
      ),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_ST_ID,
      ),
      e.value?.id,
    );

    // Очищаем тип инструкции при смене станции
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.TYPES),
      null,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.INSTRUCTION_TYPE_ID,
      ),
      null,
    );

    // Очищаем файлы при смене станции
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.USER_FILES,
      ),
      [],
    );

    // Очищаем маршруты при смене станции
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.ROUTES),
      [],
    );

    clearErrors('inputInstructionDataTab');
  };

  const handleReciverStationChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION,
      ),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_ST_ID,
      ),
      e.value?.id,
    );

    // Очищаем тип инструкции при смене станции
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.TYPES),
      null,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.INSTRUCTION_TYPE_ID,
      ),
      null,
    );

    // Очищаем файлы при смене станции
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.USER_FILES,
      ),
      [],
    );

    // Очищаем маршруты при смене станции
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.ROUTES),
      [],
    );

    clearErrors('inputInstructionDataTab');
  };

  const handleTypeChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.TYPES),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.INSTRUCTION_TYPE_ID,
      ),
      e.value?.id,
    );
    // Очищаем вложения при смене типа — загруженные файлы относятся к предыдущему типу
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.USER_FILES,
      ),
      [],
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleClientChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.CLIENT),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.CLIENT_ID,
      ),
      e.value?.id,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleSenderRecipChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP,
      ),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP_ID,
      ),
      e.value?.id,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS,
      ),
      null,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleRecieverRecipChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP,
      ),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP_ID,
      ),
      e.value?.id,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_RECIEVER_ADDRESS,
      ),
      null,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleChangeFreight = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.FREIGHT,
      ),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.FR_ID),
      e.value?.id,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleChangeGngFreight = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.GNG_FREIGHT,
      ),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.GNG_FR_ID,
      ),
      e.value?.id,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleChangePpsContract = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    // setValue(
    //   getInputInstructionDataTabFieldName(
    //     CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_PPS
    //   ),
    //   e.value
    // );

    clearErrors('inputInstructionDataTab');
  };

  const handleChangeRepairContract = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    // setValue(
    //   getInputInstructionDataTabFieldName(
    //     CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_REPAIR,
    //   ),
    //   e.value,
    // );

    clearErrors('inputInstructionDataTab');
  };
  const handleChangeAccompText = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.ACCOMP_TEXT,
      ),
      e.value,
    );
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.ACCOMP_TEXT_ID,
      ),
      e.value?.id,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleChangePrevFreight = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_FREIGHT,
      ),
      e.value,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleChangePrevGngFreight = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_GNG_FREIGHT,
      ),
      e.value,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleSenderAddressChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS,
      ),
      e.value,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleRecieverAddressChange = (
    e: DropdownChangeEvent,
    onChange: (value: CalculationType | null) => void,
  ) => {
    onChange(e.value);
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_RECIEVER_ADDRESS,
      ),
      e.value,
    );
    clearErrors('inputInstructionDataTab');
  };

  const handleRoutesChange = (
    value: IrcInstructionRoute[],
    options?: { shouldDirty?: boolean },
  ) => {
    setValue(
      getInputInstructionDataTabFieldName(CREATE_INSTRUCTION_FORM_NAMES.ROUTES),
      value,
      { shouldDirty: options?.shouldDirty ?? true },
    );
  };

  const handleChangeFiles = (
    value: IrcInstructionUserFileInput[],
    options?: { shouldDirty?: boolean },
  ) => {
    setValue(
      getInputInstructionDataTabFieldName(
        CREATE_INSTRUCTION_FORM_NAMES.USER_FILES,
      ),
      value,
      { shouldDirty: options?.shouldDirty ?? true },
    );
  };

  return {
    handleSenderStationChange,
    handleReciverStationChange,
    handleTypeChange,
    handleClientChange,
    handleSenderRecipChange,
    handleRecieverRecipChange,
    handleChangeGngFreight,
    handleChangeFreight,
    handleChangePpsContract,
    handleChangeRepairContract,
    handleChangeAccompText,
    handleChangePrevGngFreight,
    handleChangePrevFreight,
    handleSenderAddressChange,
    handleRecieverAddressChange,
    handleRoutesChange,
    handleChangeFiles,
  };
};
