import { IrcInstructionUserFileInput } from 'graphql/generated/generated';
import { useEffect, useRef } from 'react';
import { useFormContext } from 'react-hook-form';
import { useParams, useSearchParams } from 'react-router-dom';

import {
  CREATE_INSTRUCTION_FORM_NAMES,
  INSTRUCTION_STATUSES,
} from '../lib/constants';
import { setRestoreJustFinished } from '../lib/instructionFormDebugLog';
import {
  CreateInstructionFormValues,
  IdentificationTabFieldEntry,
  InstructionParams,
} from '../lib/types';
import { filterEmptyRestoredObject } from '../lib/utils';
import { useRestoredInstructionContext } from './RestoredInstructionContext';

export const useRestoreInstructionData = () => {
  const { masterId } = useParams<InstructionParams>();
  const [searchParams] = useSearchParams();
  const copyFrom = searchParams.get('copyFrom');
  const { reset, getValues } = useFormContext<CreateInstructionFormValues>();
  const isRestoredRef = useRef(false);

  // Данные для восстановления формы (при редактировании по masterId или при копировании по copyFrom)
  const { loading, restoredInstructionData } = useRestoredInstructionContext();

  const preparedRoutes = restoredInstructionData?.routes
    ?.map(route => ({
      ...route,
      recipAddress: route?.recipAddress?.name ? route?.recipAddress : null,
      payer: filterEmptyRestoredObject(route?.payer) ?? null,
      // contractRepair: filterEmptyRestoredObject(route?.contractRepair) ?? null,
      // contractPps: filterEmptyRestoredObject(route?.contractPps) ?? null,
    }))
    .sort((a, b) => (a?.sequenceNumber ?? 0) - (b?.sequenceNumber ?? 0));

  const senderRoute = preparedRoutes
    ? preparedRoutes.find(route => route.sequenceNumber == 1)
    : null;
  const recieverRoute = preparedRoutes
    ? preparedRoutes.find(route => route.sequenceNumber == 1000)
    : null;

  // const routeWithContractRepair = preparedRoutes
  //   ? preparedRoutes.find(route => !!route?.contractRepair?.id)
  //   : null;
  // const routeWithContractPps = preparedRoutes
  //   ? preparedRoutes.find(route => !!route?.contractPps?.id)
  //   : null;

  // Сбрасываем флаг при изменении masterId или copyFrom
  useEffect(() => {
    isRestoredRef.current = false;
  }, [masterId, copyFrom]);

  useEffect(() => {
    const instructionId = masterId ?? copyFrom;
    if (!instructionId || !restoredInstructionData || loading) {
      return;
    }

    const isStatusSended =
      restoredInstructionData?.status?.name === INSTRUCTION_STATUSES.sended;
    // Если данные уже были восстановлены и инструкция не «Отправлена» — не восстанавливаем повторно.
    // При статусе «Отправлена» при каждом обновлении данных (refetch) сбрасываем форму заново,
    // чтобы значения и defaultValues совпадали с сервером и isDirty не становился true из‑за новых ссылок на объекты.
    if (isRestoredRef.current && !isStatusSended) return;

    const isCopyMode = !masterId && !!copyFrom;

    const newFields: IdentificationTabFieldEntry[] = [
      ...(isCopyMode
        ? ([
            [CREATE_INSTRUCTION_FORM_NAMES.STATUS, null],
            [CREATE_INSTRUCTION_FORM_NAMES.STATUS_ID, null],
          ] as IdentificationTabFieldEntry[])
        : []),
      [CREATE_INSTRUCTION_FORM_NAMES.NUMBER, restoredInstructionData?.number],
      [
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION,
        filterEmptyRestoredObject(restoredInstructionData?.senderStation) ??
          null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION,
        filterEmptyRestoredObject(restoredInstructionData?.receiverStation) ??
          null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.TYPES,
        filterEmptyRestoredObject(restoredInstructionData?.instructionType) ??
          null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CLIENT,
        filterEmptyRestoredObject(restoredInstructionData?.client) ?? null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_NAME,
        restoredInstructionData?.manualClientName,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CLIENT_EMAIL_TEXT,
        restoredInstructionData?.clientEmailText,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.STATION_FROM_NAME,
        restoredInstructionData?.stationFromName ?? '',
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_RECIP,
        filterEmptyRestoredObject(restoredInstructionData?.recieverRecip) ??
          null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_MANUAL_RECIP_NAME,
        restoredInstructionData?.recieverManualRecipName,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_MANUAL_RECIP_OKPO,
        restoredInstructionData?.recieverManualRecipOkpo,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_MANUAL_RECIP_TGNL,
        restoredInstructionData?.recieverManualRecipTgnl,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_RECIP,
        filterEmptyRestoredObject(restoredInstructionData?.senderRecip) ?? null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_MANUAL_RECIP_NAME,
        restoredInstructionData?.senderManualRecipName,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_MANUAL_RECIP_OKPO,
        restoredInstructionData?.senderManualRecipOkpo,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.SENDER_MANUAL_RECIP_TGNL,
        restoredInstructionData?.senderManualRecipTgnl,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.FREIGHT,
        filterEmptyRestoredObject(restoredInstructionData?.freight) ?? null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.GNG_FREIGHT,
        filterEmptyRestoredObject(restoredInstructionData?.gngFreight) ?? null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.ACCOMP_TEXT,
        restoredInstructionData?.accompText,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.NOT_FOR_CARRIER_TEXT,
        restoredInstructionData?.notForCarrierText,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.OPTIONAL_MARKS_TEXT,
        restoredInstructionData?.optionalMarksText,
      ],
      [CREATE_INSTRUCTION_FORM_NAMES.CARS, restoredInstructionData?.cars],

      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_FREIGHT,
        restoredInstructionData?.cars
          ? (filterEmptyRestoredObject(
              restoredInstructionData?.cars[0]?.prevFreight,
            ) ?? null)
          : null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_PREV_GNG_FREIGHT,
        restoredInstructionData?.cars
          ? (filterEmptyRestoredObject(
              restoredInstructionData?.cars[0]?.prevGngFreight,
            ) ?? null)
          : null,
      ],

      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_RECIEVER_ADDRESS,
        recieverRoute?.recipAddress?.name ? recieverRoute?.recipAddress : null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_SENDER_ADDRESS,
        senderRoute?.recipAddress?.name ? senderRoute?.recipAddress : null,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_ADDRESS,
        recieverRoute?.manualRecipAddress,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_ADDRESS,
        senderRoute?.manualRecipAddress,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_NAME,
        recieverRoute?.manualRecipName,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_NAME,
        senderRoute?.manualRecipName,
      ],

      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_OKPO,
        recieverRoute?.manualRecipOkpo,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_OKPO,
        senderRoute?.manualRecipOkpo,
      ],

      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_TGNL,
        recieverRoute?.manualRecipTgnl,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_TGNL,
        senderRoute?.manualRecipTgnl,
      ],

      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_RECIEVER_TGNL,
        recieverRoute?.manualRecipTgnl,
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_MANUAL_SENDER_TGNL,
        senderRoute?.manualRecipTgnl,
      ],

      // [
      //   CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_PPS,
      //   filterEmptyRestoredObject(routeWithContractPps?.contractPps) ?? null,
      // ],
      // [
      //   CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CONTRACT_REPAIR,
      //   filterEmptyRestoredObject(routeWithContractRepair?.contractRepair) ??
      //     null,
      // ],
      [CREATE_INSTRUCTION_FORM_NAMES.ROUTES, preparedRoutes],
      [
        CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CLIENTS_EMAILS,
        restoredInstructionData?.clients
          ?.map(client => client.clientEmail)
          .join(', ') ?? '',
      ],
      [
        CREATE_INSTRUCTION_FORM_NAMES.USER_FILES,
        (restoredInstructionData?.userFiles?.map(uf => ({
          instructionTypeFileId: uf?.instructionTypeFileId,
          content: uf?.content,
        })) ?? []) as IrcInstructionUserFileInput[],
      ],
    ];

    const inputInstructionDataTab = newFields.reduce<Record<string, unknown>>(
      (acc, [fieldName, value]) => {
        acc[fieldName] = value;
        return acc;
      },
      {},
    ) as CreateInstructionFormValues['inputInstructionDataTab'];

    const currentValues = getValues();

    reset({
      ...currentValues,
      recieverInfoSwitch: !!restoredInstructionData?.manualClientName,
      senderSwitch: !!senderRoute?.manualRecipName,
      recieverSwitch: !!recieverRoute?.manualRecipName,
      inputInstructionDataTab: {
        ...currentValues.inputInstructionDataTab,
        ...inputInstructionDataTab,
      },
    });

    setRestoreJustFinished(true);
    isRestoredRef.current = true;
    // Сбрасываем флаг через 200 ms, чтобы корректирующий reset не срабатывал на изменения пользователя
    setTimeout(() => setRestoreJustFinished(false), 200);
  }, [masterId, copyFrom, restoredInstructionData, loading, reset, getValues]);

  return {
    loading,
    restoredInstructionData,
  };
};
