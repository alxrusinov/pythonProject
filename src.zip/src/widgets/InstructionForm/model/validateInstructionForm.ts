import { CREATE_INSTRUCTION_FORM_NAMES } from '../lib/constants';
import { CreateInstructionFormValues } from '../lib/types';

export type ValidationResult = {
  isValid: boolean;
  missingFields: string[];
};

/** Базовая проверка формата email (локаль@домен.зона) */
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const isValidEmailFormat = (value: string): boolean =>
  value.trim() !== '' && EMAIL_REGEX.test(value.trim());

const parseClientEmails = (clientEmails: string | undefined): string[] =>
  (clientEmails ?? '')
    .split(/[,\s]+/)
    .map(s => s.trim())
    .filter(Boolean);

export const validateInstructionForm = (
  formData: CreateInstructionFormValues,
): ValidationResult => {
  const inputDataTab = formData?.inputInstructionDataTab;
  const missingFields: string[] = [];

  /** Заполнено, если значение выбрано (в т.ч. id === 0) */
  const hasSelectedId = (
    obj: { id?: number | string | null } | null | undefined,
  ): boolean => obj != null && obj.id != null && obj.id !== '';

  // Проверка станции выгрузки
  if (
    !hasSelectedId(
      inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION],
    )
  ) {
    missingFields.push('Станция выгрузки');
  }

  // Проверка назначенной станции
  if (
    !hasSelectedId(
      inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION],
    )
  ) {
    missingFields.push('Назначенная станция');
  }

  // Проверка типа инструкции
  if (!hasSelectedId(inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.TYPES])) {
    missingFields.push('Тип инструкции');
  }

  // Проверка вагонов
  const cars = inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.CARS];
  if (!cars || !Array.isArray(cars) || cars.length === 0) {
    missingFields.push('Вагоны');
  }

  // Проверка получателя инструкции: либо выбран из списка (client), либо заполнены поля ручного ввода (наименование + email)
  const client = inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.CLIENT];
  const clientEmails =
    inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.CUSTOM_CLIENTS_EMAILS];
  const manualClientName =
    inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.MANUAL_CLIENT_NAME];

  const hasClientFromList = hasSelectedId(client);
  const hasManualName = !!manualClientName && manualClientName.trim() !== '';
  const hasManualEmails =
    !!clientEmails &&
    (typeof clientEmails !== 'string' || clientEmails.trim() !== '');
  const manualEmailsList = parseClientEmails(
    typeof clientEmails === 'string' ? (clientEmails ?? '') : '',
  );
  const allManualEmailsValid =
    manualEmailsList.length > 0 &&
    manualEmailsList.every(e => isValidEmailFormat(e));
  const hasValidManualRecipient =
    hasManualName && hasManualEmails && allManualEmailsValid;

  if (hasClientFromList) {
    // Получатель выбран из списка — проверка пройдена
  } else if (hasValidManualRecipient) {
    // Ручной ввод: наименование и email заполнены и валидны — проверка пройдена
  } else {
    // Нужно указать либо получателя из списка, либо ручные реквизиты
    if (hasManualName || hasManualEmails) {
      // Частично заполнен ручной ввод — уточняем, чего не хватает
      if (!hasManualName) {
        missingFields.push('Получатель инструкции (наименование)');
      }
      if (!hasManualEmails) {
        missingFields.push('Адреса email-адреса получателя');
      } else if (manualEmailsList.length === 0) {
        missingFields.push('Адреса email-адреса получателя');
      } else if (!allManualEmailsValid) {
        const invalidEmails = manualEmailsList.filter(
          e => !isValidEmailFormat(e),
        );
        missingFields.push(
          `Некорректный формат email-адреса получателя: ${invalidEmails.join(', ')}`,
        );
      }
    } else {
      missingFields.push('Получатель инструкции');
    }
  }

  // Проверка роутов
  const routes = inputDataTab?.[CREATE_INSTRUCTION_FORM_NAMES.ROUTES];
  if (!routes || !Array.isArray(routes) || routes.length === 0) {
    missingFields.push('Маршруты');
  }

  return {
    isValid: missingFields.length === 0,
    missingFields,
  };
};
