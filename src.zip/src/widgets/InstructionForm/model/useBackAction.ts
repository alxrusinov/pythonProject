import { generatePath, useNavigate } from 'react-router-dom';

import { useInstructionFormTabMenuStore } from 'features/InstructionFormTabMenu';

import { paths } from 'shared/routes/paths';
import { buildPath } from 'shared/utils/buildPath';

import { CREATE_INSTRUCTION_FORM_STEPS } from '../lib/constants';

export const useBackAction = () => {
  const navigate = useNavigate();

  const setActiveTab = useInstructionFormTabMenuStore(
    state => state.setActiveTab,
  );

  return () => {
    navigate(buildPath(generatePath(paths.carInstructions)), {
      replace: true,
    });
    setActiveTab(CREATE_INSTRUCTION_FORM_STEPS[0].value);
  };
};
