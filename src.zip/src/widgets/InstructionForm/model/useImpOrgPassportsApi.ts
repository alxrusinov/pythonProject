import { useImpOrgPassportsQuery } from 'graphql/generated/generated';

export const useImpOrgPassportsApi = () => {
  const { data } = useImpOrgPassportsQuery();
  const clients = data?.impOrgPassports?.items || [];

  return { clients };
};
