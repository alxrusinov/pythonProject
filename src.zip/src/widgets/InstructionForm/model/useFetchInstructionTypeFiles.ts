import {
  IrcInstructionTypeFile,
  useInstructionTypeByIdForInstructionLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useRef } from 'react';

import { getStableRequestDate } from 'shared/utils/date';

import { filterFilesBySourceType } from '../lib/utils';

export const useFetchInstructionTypeFiles = () => {
  const [fetchType, { loading }] =
    useInstructionTypeByIdForInstructionLazyQuery({
      fetchPolicy: 'network-only',
    });
  const fetchTypeRef = useRef(fetchType);
  fetchTypeRef.current = fetchType;

  const fetchFilesByTypeId = useCallback(
    async (typeId: string): Promise<IrcInstructionTypeFile[]> => {
      const { data } = await fetchTypeRef.current({
        variables: {
          requestDate: getStableRequestDate(),
          where: { id: { eq: typeId } },
        },
      });

      const type = data?.ircInstructionTypes?.items?.[0];
      return filterFilesBySourceType(type?.files);
    },
    [],
  );

  return { fetchFilesByTypeId, loadingTypeFiles: loading };
};
