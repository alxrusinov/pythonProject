import {
  NsiGngFreight2001,
  useGetNsiGngFreights2001LazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchGngFreightProps = {
  restoredGngFreight: NsiGngFreight2001 | null;
};

export const useGetInstructionGngFreightsApi = ({
  restoredGngFreight,
}: useSearchGngFreightProps) => {
  const [search, setSearch] = useState('');
  const [fetchGngFreights, { data }] = useGetNsiGngFreights2001LazyQuery();

  const handleChangeGngFreightSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchGngFreights({
        variables: {
          where: {
            or: [{ name: { icontains: q } }, { code: { icontains: q } }],
          },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchGngFreights],
  );

  const gngFreights = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiGngFreights2001?.items ?? [])
      : [];

    return restoredGngFreight
      ? compareRecords(items, restoredGngFreight)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredGngFreight, search]);

  return {
    handleChangeGngFreightSearch,
    gngFreights,
  };
};
