import {
  InstructionTypeQuery,
  IrcInstructionType,
  IrcInstructionTypeFilterInput,
  useInstructionTypeLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useEffect, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchTypesProps = {
  restoredTypes: Pick<IrcInstructionType, 'id' | 'name' | '__typename'> | null;
  senderStationId?: number | null;
  receiverStationId?: number | null;
  senderCountryId?: number | null;
  receiverCountryId?: number | null;
  /** false — отложить запрос (например, пока грузятся данные инструкции для редактирования) */
  isLoadEnabled?: boolean;
};

const STATION_TYPES_KEY = '__station_types__';
const TYPES_PAGE_SIZE = 200;

const buildStationsKey = (
  senderStationId?: number | null,
  receiverStationId?: number | null,
  senderCountryId?: number | null,
  receiverCountryId?: number | null,
) =>
  `${senderStationId ?? ''}:${receiverStationId ?? ''}:${senderCountryId ?? ''}:${receiverCountryId ?? ''}`;

const canFetchByStations = (
  senderStationId?: number | null,
  receiverStationId?: number | null,
) => senderStationId != null && receiverStationId != null;

export const useGetIrcTypeApi = ({
  restoredTypes,
  senderStationId,
  receiverStationId,
  senderCountryId,
  receiverCountryId,
  isLoadEnabled = true,
}: useSearchTypesProps) => {
  const [search, setSearch] = useState('');
  const [loadedKey, setLoadedKey] = useState<string | null>(null);
  const [fetchTypes, { data }] = useInstructionTypeLazyQuery();

  const stationsKey = buildStationsKey(
    senderStationId,
    receiverStationId,
    senderCountryId,
    receiverCountryId,
  );

  const getRequestKey = useCallback(
    (q: string) => {
      if (canFetchLookup(q)) {
        return `${stationsKey}:${q}`;
      }

      if (canFetchByStations(senderStationId, receiverStationId)) {
        return `${stationsKey}:${STATION_TYPES_KEY}`;
      }

      return null;
    },
    [receiverStationId, senderStationId, stationsKey],
  );

  const loadTypes = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      const requestKey = getRequestKey(q);

      if (!requestKey) {
        setLoadedKey(null);
        return;
      }

      const requestDate = getStableRequestDate();

      const conditions: NonNullable<IrcInstructionTypeFilterInput['and']> = [
        { dateFrom: { lte: requestDate } },
        { dateTo: { gt: requestDate } },
      ];

      if (canFetchLookup(q)) {
        conditions.push({ name: { icontains: q } });
      }

      // Фильтр по странам — опционально, только когда станции уже выбраны
      if (senderCountryId != null) {
        conditions.push({ countryFrom: { id: { eq: senderCountryId } } });
      }

      if (receiverCountryId != null) {
        conditions.push({ countryTo: { id: { eq: receiverCountryId } } });
      }

      fetchTypes({
        variables: {
          where: { and: conditions },
          requestDate,
          take: TYPES_PAGE_SIZE,
        },
        fetchPolicy: 'network-only',
      }).then(() => {
        setLoadedKey(requestKey);
      });
    },
    [fetchTypes, getRequestKey, senderCountryId, receiverCountryId],
  );

  // При смене станций подгружаем список без поиска; при поиске ≥3 символов уточняем по названию.
  useEffect(() => {
    if (!isLoadEnabled) return;
    const requestKey = getRequestKey(search);
    if (!requestKey || loadedKey === requestKey) return;
    loadTypes(search);
  }, [getRequestKey, isLoadEnabled, loadedKey, search, stationsKey, loadTypes]);

  const handleChangeTypesSearch = useCallback((value: string) => {
    const q = normalizeLookupSearch(value);
    setSearch(q);
  }, []);

  const types = useMemo((): IrcInstructionType[] => {
    const requestKey = getRequestKey(search);
    const isDataFresh = requestKey != null && loadedKey === requestKey;

    const items = (
      isDataFresh ? (data?.ircInstructionTypes?.items ?? []) : []
    ) as IrcInstructionType[];

    const normalizedRestoredType = restoredTypes
      ? ({
          ...restoredTypes,
          __typename: 'IrcInstructionType' as const,
        } as IrcInstructionType)
      : null;

    const emptyOption = {
      __typename: 'IrcInstructionType',
      id: null,
      name: undefined,
    } as IrcInstructionType;

    return normalizedRestoredType
      ? compareRecords(items, normalizedRestoredType)
      : [...items, emptyOption];
  }, [data, getRequestKey, loadedKey, restoredTypes, search]);

  return {
    handleChangeTypesSearch,
    types,
  };
};
