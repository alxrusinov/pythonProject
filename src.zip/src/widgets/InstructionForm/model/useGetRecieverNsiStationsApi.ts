import {
  NsiStation,
  useGetNsiStationsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchRecieverSationsProps = {
  restoredRecieverSations: NsiStation | null;
};

export const useGetRecieverNsiStationsApi = ({
  restoredRecieverSations,
}: useSearchRecieverSationsProps) => {
  const [search, setSearch] = useState('');
  const [fetchStations, { data }] = useGetNsiStationsLazyQuery();

  const handleChangeRecieverSationsSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchStations({
        variables: {
          where: { name: { icontains: q } },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchStations],
  );

  const recieverSations = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiStations?.items ?? [])
      : [];

    return restoredRecieverSations
      ? compareRecords(items, restoredRecieverSations)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredRecieverSations, search]);

  return {
    handleChangeRecieverSationsSearch,
    recieverSations,
  };
};
