import {
  useEntityNotificationsSubscription,
  useIrcExtractFileNamesInstructionMutation,
} from 'graphql/generated/generated';
import {
  createContext,
  FC,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useFormContext } from 'react-hook-form';
import { useParams, useSearchParams } from 'react-router-dom';

import { makeNotification } from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { getStableRequestDate } from 'shared/utils/date';
import { decodeOperationError } from 'shared/utils/decodeOperationError';

import { CREATE_INSTRUCTION_FORM_NAMES } from '../lib/constants';
import { getInputInstructionDataTabFieldName } from '../lib/getFormFields';
import { parseInstructionExtractedFileNames } from '../lib/parseInstructionExtractedFileNames';
import { CreateInstructionFormValues } from '../lib/types';
import { useRestoredInstructionContext } from './RestoredInstructionContext';

type InstructionExtractedFileNamesContextValue = {
  getDisplayName: (file: {
    id?: string | null;
    prefix?: string | null;
  }) => string;
  isLoadingFileNames: boolean;
};

const EXTRACT_MUTATION_DELAY_MS = 250;
// Ответ по WS может приходить с любым entityType, поэтому подписываемся без фильтра.
const SUBSCRIBE_ALL_ENTITY_TYPES: string[] | undefined = undefined;

const InstructionExtractedFileNamesContext =
  createContext<InstructionExtractedFileNamesContextValue | null>(null);

export const useInstructionExtractedFileNames = () => {
  const ctx = useContext(InstructionExtractedFileNamesContext);
  if (!ctx) {
    return {
      getDisplayName: (file: { id?: string | null; prefix?: string | null }) =>
        file.prefix?.trim() || '',
      isLoadingFileNames: false,
    };
  }
  return ctx;
};

type ProviderProps = {
  children: ReactNode;
  refreshTick?: number;
  printTabRefreshTick?: number;
};

export const InstructionExtractedFileNamesProvider: FC<ProviderProps> = ({
  children,
  refreshTick,
  printTabRefreshTick,
}) => {
  const { masterId } = useParams<{ masterId?: string }>();
  const [searchParams] = useSearchParams();
  const copyFrom = searchParams.get('copyFrom');
  const instructionId = masterId ?? copyFrom ?? null;

  const calcDateParam = searchParams.get('calcDate');

  const resolveRequestDate = useCallback(() => {
    // В режиме копирования всегда используем текущую дату,
    // а не calcDate исходной инструкции.
    if (copyFrom) {
      return getStableRequestDate();
    }

    if (calcDateParam) {
      const timestamp = Number(calcDateParam);
      return !Number.isNaN(timestamp)
        ? new Date(timestamp).toISOString()
        : getStableRequestDate();
    }
    return getStableRequestDate();
  }, [copyFrom, calcDateParam]);

  const { watch } = useFormContext<CreateInstructionFormValues>();
  const typeFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.TYPES,
  );
  const instructionTypeIdFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.INSTRUCTION_TYPE_ID,
  );
  const senderFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.SENDER_STANTION,
  );
  const receiverFieldName = getInputInstructionDataTabFieldName(
    CREATE_INSTRUCTION_FORM_NAMES.RECIEVER_STANTION,
  );
  const selectedType = watch(typeFieldName);
  const instructionTypeIdFromForm = watch(instructionTypeIdFieldName);
  const senderStationId = watch(senderFieldName)?.id ?? null;
  const receiverStationId = watch(receiverFieldName)?.id ?? null;
  const { restoredInstructionData, loading: instructionLoading } =
    useRestoredInstructionContext();

  const restoredTypeId = restoredInstructionData?.instructionType?.id ?? null;
  const selectedTypeId = selectedType?.id ?? null;
  const restoredSenderStationId =
    restoredInstructionData?.senderStation?.id ?? null;
  const restoredReceiverStationId =
    restoredInstructionData?.receiverStation?.id ?? null;

  const needsRestoredInstruction = Boolean(masterId || copyFrom);

  const stationsMatchRestored =
    senderStationId === restoredSenderStationId &&
    receiverStationId === restoredReceiverStationId;

  const effectiveTypeId = useMemo(() => {
    if (selectedTypeId) return selectedTypeId;
    if (instructionTypeIdFromForm) return instructionTypeIdFromForm;

    // Тип из restored — только пока станции совпадают с восстановленными
    // (при смене станции тип в форме сбрасывается, restoredTypeId использовать нельзя).
    if (
      needsRestoredInstruction &&
      restoredInstructionData?.id === instructionId &&
      !instructionLoading &&
      stationsMatchRestored
    ) {
      return restoredTypeId;
    }

    return null;
  }, [
    selectedTypeId,
    instructionTypeIdFromForm,
    needsRestoredInstruction,
    restoredInstructionData?.id,
    instructionId,
    instructionLoading,
    stationsMatchRestored,
    restoredTypeId,
  ]);

  const isExtractInputsReady =
    Boolean(instructionId && effectiveTypeId && !instructionLoading) &&
    (!needsRestoredInstruction ||
      restoredInstructionData?.id === instructionId);

  // Стабильный correlationId на весь жизненный цикл провайдера — как в PrintForm /
  // useInstructionFormSubmit: подписка всегда активна, без skip и гонки с пересозданием канала.
  const extractFileNamesCorrelationId = useMemo(() => UUID(), []);

  const [displayNamesByFileId, setDisplayNamesByFileId] = useState<
    Record<string, string>
  >({});
  const [isLoadingFileNames, setIsLoadingFileNames] = useState(false);
  const extractInFlightRef = useRef(false);
  const extractRerunRequestedRef = useRef(false);
  const extractMutationTimeoutRef = useRef<ReturnType<
    typeof setTimeout
  > | null>(null);
  const lastExtractTriggerKeyRef = useRef<string | null>(null);
  const handledNotificationRef = useRef(false);

  const [extractMutation] = useIrcExtractFileNamesInstructionMutation();

  const runExtractRef = useRef<() => void>(() => {});

  const clearExtractMutationTimeout = useCallback(() => {
    if (extractMutationTimeoutRef.current != null) {
      clearTimeout(extractMutationTimeoutRef.current);
      extractMutationTimeoutRef.current = null;
    }
  }, []);

  const cancelExtract = useCallback(() => {
    clearExtractMutationTimeout();
    extractInFlightRef.current = false;
    extractRerunRequestedRef.current = false;
    handledNotificationRef.current = true;
    setIsLoadingFileNames(false);
  }, [clearExtractMutationTimeout]);

  const finalizeExtract = useCallback(() => {
    clearExtractMutationTimeout();
    extractInFlightRef.current = false;
    setIsLoadingFileNames(false);

    if (extractRerunRequestedRef.current) {
      extractRerunRequestedRef.current = false;
      runExtractRef.current();
    }
  }, [clearExtractMutationTimeout]);

  const subscriptionVariables = useMemo(
    () => ({
      entityTypes: SUBSCRIBE_ALL_ENTITY_TYPES,
    }),
    [],
  );

  useEntityNotificationsSubscription({
    variables: subscriptionVariables,
    shouldResubscribe: true,
    onData: ({ data }) => {
      const notification = data.data?.entityNotifications;
      if (!notification) return;
      if (!extractInFlightRef.current) return;
      // WS приходит с input.correlationId; мутация возвращает instructionId (uuid) — не путать.
      if (notification.correlationId !== extractFileNamesCorrelationId) return;
      if (handledNotificationRef.current) return;

      handledNotificationRef.current = true;

      if (notification.error) {
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: decodeOperationError(notification.error, 'instruction'),
        });
        finalizeExtract();
        return;
      }

      const map = parseInstructionExtractedFileNames(notification.extensions);
      setDisplayNamesByFileId(map);
      finalizeExtract();
    },
    onError: () => {
      if (!extractInFlightRef.current) return;
      handledNotificationRef.current = true;
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Не удалось получить названия файлов инструкции',
      });
      finalizeExtract();
    },
  });

  const runExtract = useCallback(() => {
    const requestDate = resolveRequestDate();
    if (!instructionId || !requestDate || !effectiveTypeId) return;
    if (instructionLoading) return;
    if (extractInFlightRef.current) {
      extractRerunRequestedRef.current = true;
      return;
    }

    clearExtractMutationTimeout();
    extractInFlightRef.current = true;
    handledNotificationRef.current = false;
    setIsLoadingFileNames(true);
    setDisplayNamesByFileId({});

    extractMutationTimeoutRef.current = setTimeout(() => {
      extractMutationTimeoutRef.current = null;

      void (async () => {
        try {
          await extractMutation({
            variables: {
              input: {
                correlationId: extractFileNamesCorrelationId,
                id: instructionId,
                instructionTypeId: effectiveTypeId,
                requestDate,
              },
            },
          });
        } catch {
          makeNotification({
            variant: 'error',
            title: 'Ошибка!',
            message: 'Не удалось получить названия файлов инструкции',
          });
          finalizeExtract();
        }
      })();
    }, EXTRACT_MUTATION_DELAY_MS);
  }, [
    instructionId,
    resolveRequestDate,
    effectiveTypeId,
    instructionLoading,
    extractFileNamesCorrelationId,
    extractMutation,
    finalizeExtract,
    clearExtractMutationTimeout,
  ]);

  runExtractRef.current = runExtract;

  const extractTriggerKey = useMemo(
    () =>
      [
        instructionId ?? '',
        effectiveTypeId ?? '',
        String(senderStationId ?? ''),
        String(receiverStationId ?? ''),
        calcDateParam ?? '',
        copyFrom ?? '',
        String(refreshTick ?? 0),
        String(printTabRefreshTick ?? 0),
      ].join('|'),
    [
      instructionId,
      effectiveTypeId,
      senderStationId,
      receiverStationId,
      calcDateParam,
      copyFrom,
      refreshTick,
      printTabRefreshTick,
    ],
  );

  useEffect(() => {
    if (!instructionId || instructionLoading) return;
    if (extractTriggerKey === lastExtractTriggerKeyRef.current) return;

    lastExtractTriggerKeyRef.current = extractTriggerKey;

    if (isExtractInputsReady) {
      runExtractRef.current();
      return;
    }

    cancelExtract();
    setDisplayNamesByFileId({});
  }, [
    extractTriggerKey,
    instructionId,
    instructionLoading,
    isExtractInputsReady,
    cancelExtract,
  ]);

  // Если зависли в статусе in-flight без ответа, освобождаем очередь при размонтировании.
  useEffect(() => {
    return () => {
      clearExtractMutationTimeout();
      extractInFlightRef.current = false;
      extractRerunRequestedRef.current = false;
      handledNotificationRef.current = false;
      lastExtractTriggerKeyRef.current = null;
    };
  }, [clearExtractMutationTimeout]);

  const getDisplayName = useCallback(
    (file: { id?: string | null; prefix?: string | null }) => {
      const id = file.id?.toLowerCase();
      if (id && displayNamesByFileId[id]) {
        return displayNamesByFileId[id];
      }
      return file.prefix?.trim() ?? '';
    },
    [displayNamesByFileId],
  );

  const value = useMemo(
    () => ({
      getDisplayName,
      isLoadingFileNames,
    }),
    [getDisplayName, isLoadingFileNames],
  );

  return (
    <InstructionExtractedFileNamesContext.Provider value={value}>
      {children}
    </InstructionExtractedFileNamesContext.Provider>
  );
};
