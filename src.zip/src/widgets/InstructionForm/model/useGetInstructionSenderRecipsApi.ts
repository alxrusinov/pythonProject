import {
  ImpOrgPassport,
  useImpOrgPassportsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import {
  FILTER_TYPE_NAME_KONTRAGENT,
  impOrgPassportMatchesCounterpartyType,
} from '../lib/constants';
import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchSenderRecipProps = {
  restoredSenderRecip: ImpOrgPassport | null;
};

export const useGetInstructionSenderRecipsApi = ({
  restoredSenderRecip,
}: useSearchSenderRecipProps) => {
  const [search, setSearch] = useState('');
  const [fetchRecips, { data }] = useImpOrgPassportsLazyQuery();

  const handleChangeSenderRecipSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchRecips({
        variables: {
          where: {
            and: [
              { lastRec: { eq: true } },
              {
                or: [
                  { typeName: { iin: [FILTER_TYPE_NAME_KONTRAGENT] } },
                  { typeName: { icontains: FILTER_TYPE_NAME_KONTRAGENT } },
                ],
              },
              {
                or: [
                  { shortName: { icontains: q } },
                  { okpo: { icontains: q } },
                ],
              },
            ],
          },
          requestDate: getStableRequestDate(),
          take: 200,
        },
      });
    },
    [fetchRecips],
  );

  const senderRecips = useMemo(() => {
    const raw = canFetchLookup(search)
      ? (data?.impOrgPassports?.items ?? []).filter(item =>
          impOrgPassportMatchesCounterpartyType(item.typeName),
        )
      : [];

    return restoredSenderRecip
      ? compareRecords(raw, restoredSenderRecip)
      : [...raw, { id: null, name: undefined }];
  }, [data, restoredSenderRecip, search]);

  return {
    handleChangeSenderRecipSearch,
    senderRecips,
  };
};
