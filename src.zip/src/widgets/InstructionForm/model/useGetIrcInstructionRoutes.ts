import {
  IrcCalculateRouteInstructionInput,
  useGetIrcCalculateRouteInstructionMutation,
} from 'graphql/generated/generated';

type useGetIrcInstructionRoutesProps = {
  correlationId: string;
  senderStationId: number | null;
  receiverStationId: number | null;
};

export const useGetIrcInstructionRoutes = ({
  correlationId,
  senderStationId,
  receiverStationId,
}: useGetIrcInstructionRoutesProps) => {
  const routesInputData: IrcCalculateRouteInstructionInput = {
    input: {
      correlationId: correlationId,
      stations: [
        ...(senderStationId !== null
          ? [
              {
                stId: senderStationId,
                borderSign: '0',
                ferryImEx: '0',
                ferrySign: '0',
                riverImEx: '0',
                seaImEx: '0',
              },
            ]
          : []),
        ...(receiverStationId !== null
          ? [
              {
                stId: receiverStationId,
                borderSign: '0',
                ferryImEx: '0',
                ferrySign: '0',
                riverImEx: '0',
                seaImEx: '0',
              },
            ]
          : []),
      ],
    },
  };

  const [getIrcCalculateRouteInstructionMutation] =
    useGetIrcCalculateRouteInstructionMutation();

  const getRoutes = () => {
    getIrcCalculateRouteInstructionMutation({
      variables: {
        input: routesInputData,
      },
    });
  };

  return {
    getRoutes,
  };
};
