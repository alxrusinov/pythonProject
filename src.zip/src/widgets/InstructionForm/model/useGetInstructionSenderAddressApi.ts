import {
  ImpOrgAddress,
  ImpOrgPassport,
  useGetImpOrgAddressLazyQuery,
} from 'graphql/generated/generated';
import { useEffect, useMemo } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';
import { enrichImpOrgAddressesForSelect } from 'shared/utils/formatImpOrgAddressSelectLabel';

type useSearchSenderAddressProps = {
  restoredSenderRecip: ImpOrgPassport | null;
  restoredSenderAddress: ImpOrgAddress | null;
};

export const useGetInstructionSenderAddressApi = ({
  restoredSenderAddress,
  restoredSenderRecip,
}: useSearchSenderAddressProps) => {
  const [fetchAddresses, { data, loading }] = useGetImpOrgAddressLazyQuery();

  useEffect(() => {
    if (restoredSenderRecip?.id == null) return;

    fetchAddresses({
      variables: {
        where: {
          orgPassport: { id: { eq: restoredSenderRecip.id } },
          lastRec: { eq: true },
        },
        requestDate: getStableRequestDate(),
      },
    });
  }, [restoredSenderRecip?.id, fetchAddresses]);

  const backendSenderAddresses = data?.impOrgAddresses?.items || [];

  const senderAddressesForSelect = useMemo(
    () =>
      enrichImpOrgAddressesForSelect(
        restoredSenderAddress &&
          restoredSenderAddress?.orgPassport?.id === restoredSenderRecip?.id
          ? compareRecords(backendSenderAddresses, restoredSenderAddress)
          : backendSenderAddresses,
      ),
    [backendSenderAddresses, restoredSenderAddress, restoredSenderRecip?.id],
  );

  return {
    senderAddresses: senderAddressesForSelect,
    senderAddressesBackendCount: backendSenderAddresses.length,
    senderAddressesLoading: loading,
  };
};
