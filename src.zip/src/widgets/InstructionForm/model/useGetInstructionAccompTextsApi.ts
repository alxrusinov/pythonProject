import {
  IrcAccompText,
  useGetIrcAccompTextsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useEffect, useMemo } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchAccompTextProps = {
  restoredAccompText: IrcAccompText | null;
};

export const useGetInstructionAccompTextsApi = ({
  restoredAccompText,
}: useSearchAccompTextProps) => {
  const [fetchAccompTexts, { data }] = useGetIrcAccompTextsLazyQuery();

  const loadAccompTexts = useCallback(
    (value = '') => {
      const q = normalizeLookupSearch(value);

      fetchAccompTexts({
        variables: {
          where: q ? { text: { icontains: q } } : undefined,
        },
      });
    },
    [fetchAccompTexts],
  );

  useEffect(() => {
    loadAccompTexts('');
  }, [loadAccompTexts]);

  const handleChangeAccompTextSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      if (!canFetchLookup(q)) {
        if (!q) {
          loadAccompTexts('');
        }
        return;
      }
      loadAccompTexts(q);
    },
    [loadAccompTexts],
  );

  const accompTexts = useMemo(() => {
    const items = data?.ircAccompTexts?.items ?? [];

    return restoredAccompText
      ? compareRecords(items, restoredAccompText)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredAccompText]);

  return {
    handleChangeAccompTextSearch,
    accompTexts,
  };
};
