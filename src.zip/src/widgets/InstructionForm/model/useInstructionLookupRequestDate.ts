import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';

import { resolveInstructionLookupRequestDate } from '../lib/resolveInstructionLookupRequestDate';

export const useInstructionLookupRequestDate = (): string => {
  const [searchParams] = useSearchParams();
  const calcDateParam = searchParams.get('calcDate');

  return useMemo(
    () => resolveInstructionLookupRequestDate(calcDateParam),
    [calcDateParam],
  );
};
