import {
  NsiFreight,
  useGetNsiFreightsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchPrevFreightProps = {
  restoredPrevFreight: NsiFreight | null;
};

export const useGetInstructionPrevFreightsApi = ({
  restoredPrevFreight,
}: useSearchPrevFreightProps) => {
  const [search, setSearch] = useState('');
  const [fetchFreights, { data }] = useGetNsiFreightsLazyQuery();

  const handleChangePrevFreightSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchFreights({
        variables: {
          where: {
            or: [{ name: { icontains: q } }, { codeEtsng: { icontains: q } }],
          },
          requestDate: getStableRequestDate(),
        },
      });
    },
    [fetchFreights],
  );

  const prevFreights = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.nsiFreights?.items ?? [])
      : [];

    return restoredPrevFreight
      ? compareRecords(items, restoredPrevFreight)
      : [...items, { id: null, name: undefined }];
  }, [data, restoredPrevFreight, search]);

  return {
    handleChangePrevFreightSearch,
    prevFreights,
  };
};
