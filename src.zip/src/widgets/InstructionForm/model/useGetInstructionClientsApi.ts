import {
  ImpOrgPassport,
  useImpOrgPassportsLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import {
  FILTER_TYPE_NAME_KONTRAGENT,
  FILTER_TYPE_NAME_TCFTO,
  impOrgPassportMatchesInstructionClientType,
} from '../lib/constants';
import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchClientProps = {
  restoredClient: ImpOrgPassport | null;
};

export const useGetInstructionClientsApi = ({
  restoredClient,
}: useSearchClientProps) => {
  const [search, setSearch] = useState('');
  const [fetchClients, { data }] = useImpOrgPassportsLazyQuery();

  const handleChangeClientsSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchClients({
        variables: {
          where: {
            and: [
              { lastRec: { eq: true } },
              {
                or: [
                  {
                    typeName: {
                      iin: [
                        FILTER_TYPE_NAME_TCFTO,
                        FILTER_TYPE_NAME_KONTRAGENT,
                      ],
                    },
                  },
                  { typeName: { icontains: FILTER_TYPE_NAME_TCFTO } },
                  { typeName: { icontains: FILTER_TYPE_NAME_KONTRAGENT } },
                ],
              },
              {
                or: [
                  { shortName: { icontains: q } },
                  { okpo: { icontains: q } },
                ],
              },
            ],
          },
          requestDate: getStableRequestDate(),
          take: 200,
        },
      });
    },
    [fetchClients],
  );

  const clients = useMemo(() => {
    const raw = canFetchLookup(search)
      ? (data?.impOrgPassports?.items ?? []).filter(item =>
          impOrgPassportMatchesInstructionClientType(item.typeName),
        )
      : [];

    return restoredClient
      ? compareRecords(raw, restoredClient)
      : [...raw, { id: null, name: undefined }];
  }, [data, restoredClient, search]);

  return {
    handleChangeClientsSearch,
    clients,
  };
};
