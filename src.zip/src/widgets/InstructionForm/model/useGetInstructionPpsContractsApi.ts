import {
  PpsContract,
  useGetPpsContractsQuery,
} from 'graphql/generated/generated';
import { useEffect, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';
import { getStableRequestDate } from 'shared/utils/date';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchPpsContractProps = {
  restoredPpsContract: PpsContract | null;
};

export const useGetInstructionPpsContractsApi = ({
  restoredPpsContract,
}: useSearchPpsContractProps) => {
  const [ppsContractSearchParams, setPpsContractSearchParams] = useState('');
  const [ppsContracts, setPpsContracts] = useState<PpsContract[]>([]);
  const searchQuery = normalizeLookupSearch(ppsContractSearchParams);

  const requestDate = useMemo(() => getStableRequestDate(), [searchQuery]);

  const { data } = useGetPpsContractsQuery({
    skip: !canFetchLookup(searchQuery),
    variables: {
      where: { contractName: { icontains: searchQuery } },
      requestDate,
    },
  });

  useEffect(() => {
    setPpsContracts(data?.ppsContracts?.items || []);
  }, [data]);

  const handleChangePpsContractSearch = (value: string) => {
    setPpsContractSearchParams(normalizeLookupSearch(value));
  };

  return {
    handleChangePpsContractSearch,
    ppsContracts: restoredPpsContract
      ? compareRecords(ppsContracts, restoredPpsContract)
      : [...ppsContracts, { id: null, name: undefined }],
  };
};
