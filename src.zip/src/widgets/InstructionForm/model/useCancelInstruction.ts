import {
  GetInstructionsDocument,
  useCancelInstructionMutation,
  useEntityNotificationsSubscription,
} from 'graphql/generated/generated';
import { useMemo, useRef } from 'react';
import { generatePath, useNavigate } from 'react-router-dom';

import { useApolloClient } from '@apollo/client';

import { makeNotification } from 'shared_ui/components';
import { UUID } from 'shared_ui/utils';

import { paths } from 'shared/routes/paths';
import { buildPath } from 'shared/utils/buildPath';
import { decodeOperationError } from 'shared/utils/decodeOperationError';

// См. комментарий в useSendInstruction: ответы по WS могут приходить с другим entityType.
const SUBSCRIBE_ALL_ENTITY_TYPES: string[] | undefined = undefined;

export const useCancelInstruction = () => {
  const navigate = useNavigate();
  const apolloClient = useApolloClient();
  const cancelInstructionUUID = useMemo(() => UUID(), []);
  const cancelInFlightRef = useRef(false);
  const handledCancelNotificationRef = useRef(false);

  const [cancelInstructionMutation] = useCancelInstructionMutation();

  const subscriptionVariables = useMemo(
    () => ({
      entityTypes: SUBSCRIBE_ALL_ENTITY_TYPES,
    }),
    [],
  );

  useEntityNotificationsSubscription({
    variables: subscriptionVariables,
    shouldResubscribe: true,
    onData: ({ data }) => {
      const notification = data.data?.entityNotifications;
      if (!notification) return;
      if (!cancelInFlightRef.current) return;
      if (notification.correlationId !== cancelInstructionUUID) return;
      if (handledCancelNotificationRef.current) return;

      handledCancelNotificationRef.current = true;
      cancelInFlightRef.current = false;

      if (notification.error) {
        makeNotification({
          variant: 'error',
          title: 'Ошибка!',
          message: decodeOperationError(notification.error, 'instruction'),
        });
        return;
      }

      if (notification.entityId) {
        makeNotification({
          variant: 'success',
          title: 'Успех!',
          message: `Инструкция отменена успешно`,
        });

        void apolloClient
          .refetchQueries({
            include: [GetInstructionsDocument],
          })
          .finally(() => {
            navigate(buildPath(generatePath(paths.carInstructions)));
          });
      }
    },
    onError: () => {
      if (!cancelInFlightRef.current) return;
      handledCancelNotificationRef.current = true;
      cancelInFlightRef.current = false;
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: `Ошибка отмены инструкции`,
      });
    },
  });

  const cancelInstruction = async (id: string) => {
    try {
      cancelInFlightRef.current = true;
      handledCancelNotificationRef.current = false;
      await cancelInstructionMutation({
        variables: {
          input: {
            id,
            correlationId: cancelInstructionUUID,
          },
        },
      });
    } catch {
      cancelInFlightRef.current = false;
      makeNotification({
        variant: 'error',
        title: 'Ошибка!',
        message: 'Непредвиденная ошибка при выполнении запроса',
      });
    }
  };

  return { cancelInstruction };
};
