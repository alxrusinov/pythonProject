import {
  ImpRepairContract,
  useGetImpRepairContractsQuery,
} from 'graphql/generated/generated';
import { useEffect, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';

import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchRepairContractProps = {
  restoredRepairContract: ImpRepairContract | null;
};

export const useGetInstructionRepairContractsApi = ({
  restoredRepairContract,
}: useSearchRepairContractProps) => {
  const [repairContractSearchParams, setRepairContractSearchParams] =
    useState('');
  const [repairContracts, setRepairContracts] = useState<ImpRepairContract[]>(
    [],
  );

  const searchQuery = normalizeLookupSearch(repairContractSearchParams);

  const { data } = useGetImpRepairContractsQuery({
    skip: !canFetchLookup(searchQuery),
    variables: {
      where: { contractNum: { icontains: searchQuery } },
    },
  });

  useEffect(() => {
    setRepairContracts(data?.impRepairContracts?.items || []);
  }, [data]);

  const handleChangeRepairContractSearch = (value: string) => {
    setRepairContractSearchParams(normalizeLookupSearch(value));
  };

  return {
    handleChangeRepairContractSearch,
    repairContracts: restoredRepairContract
      ? compareRecords(repairContracts, restoredRepairContract)
      : [...repairContracts, { id: null, name: undefined }],
  };
};
