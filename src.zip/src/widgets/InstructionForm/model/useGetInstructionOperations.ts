import { useInstructionOperationsByIdLazyQuery } from 'graphql/generated/generated';
import { useCallback, useEffect, useMemo } from 'react';
import { useParams } from 'react-router-dom';

import { InstructionParams } from '../lib/types';

export const useGetInstructionOperations = (enabled = false) => {
  const { masterId } = useParams<InstructionParams>();

  const [fetchOperations, { data, loading, refetch }] =
    useInstructionOperationsByIdLazyQuery();

  const loadOperations = useCallback(() => {
    if (!masterId) return;

    fetchOperations({
      variables: { id: masterId },
      fetchPolicy: 'network-only',
    });
  }, [fetchOperations, masterId]);

  useEffect(() => {
    if (enabled && masterId) {
      loadOperations();
    }
  }, [enabled, masterId, loadOperations]);

  const operations = useMemo(() => {
    const items = data?.ircInstructionOperations?.items ?? [];
    return [...items].sort((a, b) => {
      const dateA = a.date ? new Date(a.date).getTime() : 0;
      const dateB = b.date ? new Date(b.date).getTime() : 0;
      return dateA - dateB;
    });
  }, [data]);

  return {
    operations,
    loading,
    refetch: loadOperations,
  };
};
