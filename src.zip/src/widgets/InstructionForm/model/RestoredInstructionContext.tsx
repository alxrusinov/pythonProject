import { createContext, ReactNode, useContext } from 'react';

import { useGetRestoredInstructionData } from './useGetRestoredInstructionData';

type RestoredInstructionContextValue = ReturnType<
  typeof useGetRestoredInstructionData
>;

const RestoredInstructionContext =
  createContext<RestoredInstructionContextValue | null>(null);

export const RestoredInstructionProvider = ({
  children,
}: {
  children: ReactNode;
}) => {
  const value = useGetRestoredInstructionData();

  return (
    <RestoredInstructionContext.Provider value={value}>
      {children}
    </RestoredInstructionContext.Provider>
  );
};

export const useRestoredInstructionContext = () => {
  const context = useContext(RestoredInstructionContext);

  if (!context) {
    throw new Error(
      'useRestoredInstructionContext must be used within RestoredInstructionProvider',
    );
  }

  return context;
};
