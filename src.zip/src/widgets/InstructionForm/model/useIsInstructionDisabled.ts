import { useParams, useSearchParams } from 'react-router-dom';

import { INSTRUCTION_STATUSES } from '../lib/constants';
import { InstructionParams } from '../lib/types';
import { useRestoredInstructionContext } from './RestoredInstructionContext';

export const useIsInstructionDisabled = () => {
  const { masterId } = useParams<InstructionParams>();
  const [searchParams] = useSearchParams();
  const copyFrom = searchParams.get('copyFrom');
  const { restoredInstructionData } = useRestoredInstructionContext();

  const isCopyMode = !masterId && !!copyFrom;
  const status = restoredInstructionData?.status?.name;
  const isCorrectionInstruction =
    !isCopyMode && !!restoredInstructionData?.parent?.id;

  const isDisabled =
    !isCopyMode &&
    (status === INSTRUCTION_STATUSES.canceled ||
      status === INSTRUCTION_STATUSES.sended);

  return { isDisabled, isCorrectionInstruction };
};
