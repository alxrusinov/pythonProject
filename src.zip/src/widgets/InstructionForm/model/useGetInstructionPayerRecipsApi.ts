import {
  ImpOrgPassport,
  ImpOrgPayer,
  useGetImpOrgPayersLazyQuery,
} from 'graphql/generated/generated';
import { useCallback, useMemo, useState } from 'react';

import { compareRecords } from 'shared/utils/compareRecords';

import { PAYER_TYPE_ID } from '../lib/constants';
import { canFetchLookup, normalizeLookupSearch } from '../lib/lookupSearch';

type useSearchPayerRecipProps = {
  restoredPayerRecip: ImpOrgPayer | ImpOrgPassport | null;
};

export const useGetInstructionPayerRecipsApi = ({
  restoredPayerRecip,
}: useSearchPayerRecipProps) => {
  const [search, setSearch] = useState('');

  const [fetchPayers, { data }] = useGetImpOrgPayersLazyQuery();

  const handleChangePayerRecipSearch = useCallback(
    (value: string) => {
      const q = normalizeLookupSearch(value);
      setSearch(q);
      if (!canFetchLookup(q)) return;

      fetchPayers({
        variables: {
          where: {
            and: [
              { name: { icontains: q } },
              {
                or: [{ payerTypeId: { eq: PAYER_TYPE_ID } }],
              },
            ],
          },
        },
      });
    },
    [fetchPayers],
  );

  const payerRecips = useMemo(() => {
    const items = canFetchLookup(search)
      ? (data?.impOrgPayers?.items ?? [])
      : [];

    return restoredPayerRecip
      ? compareRecords(
          items,
          restoredPayerRecip as ImpOrgPayer & { id?: number | null },
        )
      : [
          ...items,
          { id: null, name: undefined } as ImpOrgPayer & { id?: number | null },
        ];
  }, [data, restoredPayerRecip, search]);

  return {
    handleChangePayerRecipSearch,
    payerRecips,
  };
};
