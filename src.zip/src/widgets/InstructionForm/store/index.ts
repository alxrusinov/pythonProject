import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

import { StoreState, StoreType } from '../lib/types';

const initialState: StoreState = {
  preFillingFields: null,
};

const useFieldsPrefilling = create<StoreType>()(
  devtools((set, get) => ({
    ...initialState,
    setPreFillingFields: preFillingFields => {
      set({ preFillingFields });
    },
    resetSenderStation: () => {
      const state = get();
      if (state.preFillingFields) {
        set({
          preFillingFields: { ...state.preFillingFields, senderStation: null },
        });
      }
    },
    resetClient: () => {
      const state = get();
      if (state.preFillingFields) {
        set({
          preFillingFields: {
            ...state.preFillingFields,
            client: null,
          },
        });
      }
    },
    resetSenderRecip: () => {
      const state = get();
      if (state.preFillingFields) {
        set({
          preFillingFields: {
            ...state.preFillingFields,
            senderRecip: null,
          },
        });
      }
    },
    resetCustomPrevFreight: () => {
      const state = get();
      if (state.preFillingFields) {
        set({
          preFillingFields: {
            ...state.preFillingFields,
            customPrevFreight: null,
          },
        });
      }
    },
    resetCustomPrevGngFreight: () => {
      const state = get();
      if (state.preFillingFields) {
        set({
          preFillingFields: {
            ...state.preFillingFields,
            customPrevGngFreight: null,
          },
        });
      }
    },
    reset: () => {
      set({ ...initialState });
    },
  })),
);

export { useFieldsPrefilling };
