import { useEffect, useRef, useState } from 'react';

import { DatePicker } from 'shared_ui/components';
import { CalendarChangeEvent } from 'shared_ui/primereact';

type RequestDateFilterProps = {
  onChange?: (value: Date | undefined) => void;
  value?: Date | undefined;
};

export const RequestDateFilter = ({
  onChange,
  value,
}: RequestDateFilterProps) => {
  const [inputValue, setInputValue] = useState<Date | undefined>(value);
  const pendingValueRef = useRef<Date | undefined>(value);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastEmittedValueRef = useRef<Date | undefined>(value);

  const isSameDateValue = (
    left: Date | undefined,
    right: Date | undefined,
  ): boolean => {
    if (!left && !right) return true;
    if (!left || !right) return false;
    return left.getTime() === right.getTime();
  };

  const emitChange = (nextValue: Date | undefined) => {
    if (isSameDateValue(lastEmittedValueRef.current, nextValue)) {
      return;
    }
    lastEmittedValueRef.current = nextValue;
    onChange?.(nextValue);
  };

  const emitChangeDebounced = (nextValue: Date | undefined) => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      emitChange(nextValue);
    }, 250);
  };

  useEffect(() => {
    setInputValue(value);
    pendingValueRef.current = value;
    lastEmittedValueRef.current = value;
  }, [value]);

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, []);

  const handleChange = (e: CalendarChangeEvent) => {
    const newValue = e.value;
    if (newValue && !Array.isArray(newValue)) {
      const date = newValue as Date;
      pendingValueRef.current = date;
      setInputValue(date);
      emitChangeDebounced(date);
      return;
    }

    pendingValueRef.current = undefined;
    setInputValue(undefined);
    emitChangeDebounced(undefined);
  };

  const handleBlur = () => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    emitChange(pendingValueRef.current);
  };

  return (
    <div>
      <DatePicker
        panelClassName="md:min-w-min"
        selectionMode="single"
        value={inputValue ?? null}
        onChange={handleChange}
        onBlur={handleBlur}
        showTime={true}
        size="medium"
      />
    </div>
  );
};
