import { paths } from 'shared/routes/paths';

export type TabMenuModelType = {
  label: string;
  url: string;
};

export const tabMenuModel: TabMenuModelType[] = [
  {
    label: 'Журнал инструкций',
    url: paths.carInstructions,
  },
  {
    label: 'Справочник типов инструкций',
    url: paths.carInstructionTemplates,
  },
  {
    label: 'Справочник email-адресов',
    url: paths.orgEmails,
  },
];
