import { Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { NavigationBar, Progress, TabMenu } from 'shared_ui/components';

import { useMainNavigate } from './model/useMainNavigate';

export const MainNavigate = () => {
  const { menuElements } = useMainNavigate();

  return (
    <div className="flex flex-column flex-1 min-h-0 h-full gap-2">
      <NavigationBar title="Инструкции на возврат вагонов">
        <TabMenu
          className="white-space-nowrap"
          elements={menuElements}
          type="navigation"
        />
      </NavigationBar>
      <div className="flex flex-column flex-1 min-h-0 overflow-hidden">
        <Suspense fallback={<Progress />}>
          <Outlet />
        </Suspense>
      </div>
    </div>
  );
};
