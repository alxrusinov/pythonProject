import { tabMenuModel, TabMenuModelType } from '../lib/constants';

export const useMainNavigate = () => {
  const menuElements: TabMenuModelType[] = tabMenuModel;

  return {
    menuElements,
  };
};
