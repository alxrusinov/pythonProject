import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import {
  Box,
  Column,
  DataTableRowEvent,
  DataTableSelectionSingleChangeEvent,
  DataTableValueArray,
  Table,
} from 'shared_ui/components';
import {
  DataTableContextMenuSelectionChangeEvent,
  DataTablePageEvent,
  DataTableRowClickEvent,
} from 'shared_ui/primereact';

import { InstructionModels, InstructionTypeModels } from 'shared/types/common';

import { normalizeFilterMeta } from '../lib/normalizeFilterMeta';
import { renderFilterElement } from '../lib/renderColumnLocalFilter';
import {
  getNextSortState,
  sortTableRows,
  TableSortState,
} from '../lib/sortTableRows';
import {
  ColumnLocalFilterType,
  ColumnsMetaDataType,
  TableProps,
} from '../lib/types';
import { useColumnData } from '../lib/useColumnData';

interface InstructionTableTemplateProps<T> {
  dataKey: TableProps['dataKey'];
  header?: TableProps['header'];
  value: TableProps['value'];
  filters?: TableProps['filters'];
  onFilter?: TableProps['onFilter'];
  tableMetaData: ColumnsMetaDataType<T>[];
  loading?: boolean;

  selectedItem: unknown;
  onContextMenuSelectionChange: (
    e: DataTableContextMenuSelectionChangeEvent<DataTableValueArray>,
  ) => void;
  onContextMenu: (e: DataTableRowEvent) => void;
  onSelectionChange: (
    e: DataTableSelectionSingleChangeEvent<DataTableValueArray>,
  ) => void;
  onRowDoubleClick: (e: DataTableRowClickEvent) => void;
  onSelect?: (value: InstructionTypeModels | InstructionModels | null) => void;

  scrollHeight?: string;
  stateKey?: string;
}

const ROWS = 100;

function loadFirst(stateKey?: string): number {
  if (!stateKey) return 0;
  try {
    const v = sessionStorage.getItem(`${stateKey}-first`);
    if (v != null) return Number(v) || 0;
  } catch {
    /* ignore */
  }
  return 0;
}

function saveFirst(stateKey: string | undefined, first: number) {
  if (!stateKey) return;
  try {
    sessionStorage.setItem(`${stateKey}-first`, String(first));
  } catch {
    /* ignore */
  }
}

function loadSort(stateKey?: string): TableSortState {
  if (!stateKey) return { field: undefined, order: undefined };
  try {
    const raw = sessionStorage.getItem(`${stateKey}-sort`);
    if (raw) {
      const parsed = JSON.parse(raw) as TableSortState;
      if (!parsed.order) {
        return { field: undefined, order: undefined };
      }
      return parsed;
    }
  } catch {
    /* ignore */
  }
  return { field: undefined, order: undefined };
}

function saveSort(stateKey: string | undefined, sort: TableSortState) {
  if (!stateKey) return;
  try {
    sessionStorage.setItem(`${stateKey}-sort`, JSON.stringify(sort));
  } catch {
    /* ignore */
  }
}

export const InstructionTableTemplate = <T,>({
  dataKey,
  header,
  value,
  filters,
  onFilter,
  tableMetaData,
  loading,
  selectedItem,
  onContextMenuSelectionChange,
  onContextMenu,
  onSelectionChange,
  onRowDoubleClick,
  onSelect,
  scrollHeight,
  stateKey,
}: InstructionTableTemplateProps<T>) => {
  const { columnDataMap, setTableValue } = useColumnData<T>({
    value,
    tableMetaData,
  });

  const columnDataMapRef = useRef(columnDataMap);
  columnDataMapRef.current = columnDataMap;

  const normalizedFilters = useMemo(
    () => normalizeFilterMeta(filters as Record<string, unknown>),
    [filters],
  );

  const fieldFilterTypes = useMemo(() => {
    const map = new Map<string, ColumnLocalFilterType | undefined>();
    tableMetaData.forEach(({ field, filterType }) => {
      map.set(field, filterType);
    });
    return map;
  }, [tableMetaData]);

  const savedFirst = useRef(loadFirst(stateKey));
  const pageUnlocked = useRef(false);
  const [first, setFirst] = useState(savedFirst.current);

  useEffect(() => {
    if (pageUnlocked.current) return;
    if (!Array.isArray(value) || value.length === 0) return;

    setFirst(savedFirst.current);

    const raf = requestAnimationFrame(() => {
      pageUnlocked.current = true;
    });
    return () => cancelAnimationFrame(raf);
  }, [value]);

  const onPage = useCallback(
    (e: DataTablePageEvent) => {
      if (!pageUnlocked.current) return;
      setFirst(e.first);
      saveFirst(stateKey, e.first);
    },
    [stateKey],
  );

  const [sort, setSort] = useState<TableSortState>(() => loadSort(stateKey));

  const onSort = useCallback(
    (e: { sortField?: string; sortOrder?: 1 | 0 | -1 | null }) => {
      const next = getNextSortState(sort, e.sortField);
      setSort(next);
      saveSort(stateKey, next);
    },
    [sort, stateKey],
  );

  const sortedValue = useMemo(
    () =>
      sortTableRows(
        value as Record<string, unknown>[] | undefined,
        sort,
        fieldFilterTypes,
      ),
    [value, sort, fieldFilterTypes],
  );

  const sh = scrollHeight ?? 'flex';

  return (
    <Box className="p-2 flex-1 min-h-0 flex flex-column" rounded>
      <Table
        dataKey={dataKey}
        tableClassName="white-space-nowrap"
        header={header}
        emptyMessage="Нет доступных записей"
        paginator
        rows={ROWS}
        first={first}
        onPage={onPage}
        scrollable
        scrollHeight={sh}
        selection={selectedItem!}
        onContextMenuSelectionChange={onContextMenuSelectionChange}
        onContextMenu={onContextMenu}
        showGridlines
        removableSort
        sortField={sort.field}
        sortOrder={sort.order}
        onSort={onSort}
        value={sortedValue}
        selectionMode="single"
        onSelectionChange={e => {
          onSelectionChange(e);
          if (onSelect) {
            onSelect(e.value);
          }
        }}
        onRowDoubleClick={onRowDoubleClick as any}
        filters={normalizedFilters as TableProps['filters']}
        onFilter={onFilter}
        onValueChange={setTableValue}
        loading={loading}
      >
        {tableMetaData.map(({ field, header, filterType, ...rest }) => (
          <Column
            key={field}
            field={field}
            header={header}
            filter
            filterField={field}
            sortable
            showAddButton={false}
            showFilterOperator={false}
            filterElement={options =>
              renderFilterElement({
                options,
                filterType,
                rawColumnData: columnDataMapRef.current.get(field),
              })
            }
            {...rest}
          />
        ))}
      </Table>
    </Box>
  );
};
