export { InstructionTableTemplate } from './ui/InstructionTableTemplate';
export type { ColumnsMetaDataType, TableProps } from './lib/types';
