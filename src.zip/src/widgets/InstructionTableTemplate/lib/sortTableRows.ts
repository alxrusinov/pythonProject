import { ColumnLocalFilterType } from './types';

export type TableSortState = {
  field: string | undefined;
  order: 1 | 0 | -1 | null | undefined;
};

const isEmpty = (value: unknown): boolean => value == null || value === '';

const compareValues = (
  a: unknown,
  b: unknown,
  filterType?: ColumnLocalFilterType,
): number => {
  if (isEmpty(a) && isEmpty(b)) return 0;
  if (isEmpty(a)) return 1;
  if (isEmpty(b)) return -1;

  if (filterType === 'datetime') {
    const ta = a instanceof Date ? a.getTime() : new Date(String(a)).getTime();
    const tb = b instanceof Date ? b.getTime() : new Date(String(b)).getTime();
    if (Number.isNaN(ta) && Number.isNaN(tb)) return 0;
    if (Number.isNaN(ta)) return 1;
    if (Number.isNaN(tb)) return -1;
    return ta - tb;
  }

  if (filterType === 'number') {
    return Number(a) - Number(b);
  }

  if (typeof a === 'boolean' || typeof b === 'boolean') {
    return Number(Boolean(a)) - Number(Boolean(b));
  }

  if (typeof a === 'number' && typeof b === 'number') {
    return a - b;
  }

  return String(a).localeCompare(String(b), 'ru', { numeric: true });
};

/** Цикл: asc → desc → без сортировки (по текущему состоянию, не по событию PrimeReact) */
export const getNextSortState = (
  current: TableSortState,
  clickedField?: string,
): TableSortState => {
  if (!clickedField) {
    return { field: undefined, order: undefined };
  }

  if (current.field !== clickedField) {
    return { field: clickedField, order: 1 };
  }

  if (current.order === 1) {
    return { field: clickedField, order: -1 };
  }

  if (current.order === -1) {
    return { field: undefined, order: undefined };
  }

  return { field: clickedField, order: 1 };
};

export const sortTableRows = <T extends Record<string, unknown>>(
  rows: T[] | null | undefined,
  sort: TableSortState,
  fieldFilterTypes: Map<string, ColumnLocalFilterType | undefined>,
): T[] => {
  const source = rows ?? [];
  const { field, order } = sort;

  if (!field || order == null || order === 0 || !source.length) {
    return source;
  }

  const filterType = fieldFilterTypes.get(field);

  return [...source].sort((rowA, rowB) => {
    const cmp = compareValues(rowA[field], rowB[field], filterType);
    return order > 0 ? cmp : -cmp;
  });
};
