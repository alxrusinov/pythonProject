import { FilterMatchMode, FilterOperator } from 'shared_ui/api';
import type { DataTableOperatorFilterMetaData } from 'shared_ui/primereact';

type FilterMeta = Record<string, unknown>;

export function normalizeFilterMeta(
  filters: FilterMeta | undefined,
): FilterMeta {
  if (!filters || typeof filters !== 'object') return filters ?? {};
  const out = { ...filters };
  for (const key of Object.keys(out)) {
    if (key === 'global') continue;
    const entry = out[key] as Record<string, unknown> | undefined;
    if (!entry) continue;
    if (Array.isArray(entry.constraints) && entry.constraints.length > 0)
      continue;
    const value = entry.value;
    const matchMode = entry.matchMode ?? FilterMatchMode.CONTAINS;
    (out as Record<string, unknown>)[key] = {
      operator: FilterOperator.AND,
      constraints: [{ value, matchMode }],
    } as DataTableOperatorFilterMetaData;
  }
  return out;
}
