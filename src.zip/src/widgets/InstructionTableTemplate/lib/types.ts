import { ComponentProps } from 'react';

import { ITableColumn } from 'shared_ui/components';
import { DataTable } from 'shared_ui/primereact';

export type ColumnLocalFilterType =
  | 'boolean'
  | 'datetime'
  | 'number'
  | 'text'
  | 'multi';

export type ColumnsMetaDataType<T> = ITableColumn & {
  field: Extract<keyof T, string>;
  filterType?: ColumnLocalFilterType;
};

export type CellDataType = string | number | boolean | Date;

export type TableProps = ComponentProps<typeof DataTable>;
