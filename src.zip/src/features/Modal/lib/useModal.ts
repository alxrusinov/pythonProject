import { useContext } from 'react';

import { ModalContext } from '../context/modalContext';

const useModal = () => {
  const { onClose } = useContext(ModalContext);

  return { onClose };
};

export { useModal };
