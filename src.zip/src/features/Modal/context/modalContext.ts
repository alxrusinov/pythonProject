import { createContext } from 'react';

type ContextValue = {
  onClose?: () => void;
};

const ModalContext = createContext<ContextValue>({
  onClose: undefined,
});

export { ModalContext };
