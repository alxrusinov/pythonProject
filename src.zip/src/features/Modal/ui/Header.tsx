import { FC } from 'react';

import { Button, Icons } from 'shared_ui/components';

import styles from '../Modal.module.scss';

type Props = {
  title: string;
  subtitle?: string;
  onClose(): void;
};

const Header: FC<Props> = ({ onClose, title, subtitle }) => (
  <>
    <div>
      <div className={styles.title}>{title}</div>
      <div className={styles.subtitle}>{subtitle}</div>
    </div>
    <Button onClick={onClose} variant="text" className={styles.close}>
      <Icons.Cross.Md />
    </Button>
  </>
);

export { Header };
