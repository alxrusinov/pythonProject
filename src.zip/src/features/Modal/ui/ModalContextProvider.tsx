import { FC, ReactNode } from 'react';

import { ModalContext } from '../context/modalContext';

type Props = {
  onClose: () => void;
  children: ReactNode;
};

const ModalContextProvider: FC<Props> = ({ children, onClose }) => {
  return (
    <ModalContext.Provider value={{ onClose }}>
      {children}
    </ModalContext.Provider>
  );
};

export { ModalContextProvider };
