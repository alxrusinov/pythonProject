import clsx from 'clsx';
import { FC, ReactNode } from 'react';

import { Modal as SharedModal } from 'shared_ui/components';
import { DialogProps } from 'shared_ui/primereact';

import styles from './Modal.module.scss';
import { Header } from './ui/Header';
import { ModalContextProvider } from './ui/ModalContextProvider';

type Props = Omit<DialogProps, 'onHide'> & {
  title: string;
  subtitle?: string;
  visible: boolean;
  onClose(): void;
  children?: ReactNode;
  size?: 'large' | 'medium' | 'small';
};

const Modal: FC<Props> = ({
  className,
  onClose,
  children,
  visible = false,
  maskClassName,
  appendTo = 'self',
  maskStyle = { position: 'absolute' },
  title,
  subtitle,
  size = 'medium',
  ...rest
}) => {
  return (
    <SharedModal
      {...rest}
      draggable={false}
      footer={undefined}
      title={title}
      appendTo={appendTo}
      maskStyle={maskStyle}
      closable={false}
      visible={visible}
      onClose={onClose}
      className={clsx('pb-3', className)}
      maskClassName={clsx(maskClassName, styles.modal)}
      header={<Header onClose={onClose} title={title} subtitle={subtitle} />}
      size={size}
      footerHide
    >
      <ModalContextProvider onClose={onClose}>{children}</ModalContextProvider>
    </SharedModal>
  );
};

export { Modal };
