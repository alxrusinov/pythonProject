export type InstructionTypeFormTabMenuStore = {
  activeTab?: string;
  setActiveTab: (activeTab: string) => void;
};
