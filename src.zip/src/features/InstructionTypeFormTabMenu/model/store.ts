import { create } from 'zustand';

import { InstructionTypeFormTabMenuStore } from '../lib/types';

export const useInstructionTypeFormTabMenuStore =
  create<InstructionTypeFormTabMenuStore>()(set => ({
    setActiveTab: (activeTab: string) => set({ activeTab }),
  }));
