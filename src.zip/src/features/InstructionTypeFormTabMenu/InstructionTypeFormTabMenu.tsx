import { TabMenu } from 'shared_ui/components';

import { TabMenuElements } from 'shared/types/common';

import { useInstructionTypeFormTabMenuStore } from './model/store';

interface InstructionTypeFormHeaderProps {
  onChooseCb?: () => void | boolean | Promise<boolean | void>;
  elements: TabMenuElements[];
  initialTab: string;
}

export const InstructionTypeFormTabMenu = ({
  onChooseCb,
  elements,
  initialTab,
}: InstructionTypeFormHeaderProps) => {
  const activeTab =
    useInstructionTypeFormTabMenuStore(state => state.activeTab) ?? initialTab;
  const setActiveTab = useInstructionTypeFormTabMenuStore(
    state => state.setActiveTab,
  );

  const handleTabChange = async (nextTab: string) => {
    const shouldProcess = await onChooseCb?.();

    if (shouldProcess === false) return;

    setActiveTab(nextTab);
  };

  return (
    <TabMenu
      type="manual"
      elements={elements}
      active={activeTab}
      onChoose={handleTabChange}
    />
  );
};
