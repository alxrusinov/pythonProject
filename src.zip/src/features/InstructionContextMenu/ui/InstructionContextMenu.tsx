import { forwardRef } from 'react';

import {
  ContextMenu,
  IMenuItem,
  MenuItemCommandEvent,
} from 'shared_ui/components';
import { ContextMenu as ContextMenuPrime } from 'shared_ui/primereact';

import styles from './InstructionContextMenu.module.scss';

export enum InstructionContextMenuItemIds {
  Card = 'card',
  Edit = 'edit',
  Copy = 'copy',
  Create = 'create',
}

export type InstructionContextMenuItem = IMenuItem & {
  id?: InstructionContextMenuItemIds;
};

type InstructionMenuItemCommandEvent = MenuItemCommandEvent & {
  item: InstructionContextMenuItem;
};

interface InstructionContextMenuProps {
  onHide?: () => void;
  onCommand?: (item: InstructionContextMenuItem) => void;
}

export const InstructionContextMenu = forwardRef<
  ContextMenuPrime,
  InstructionContextMenuProps
>(({ onHide, onCommand }: InstructionContextMenuProps, ref) => {
  const command = (e: InstructionMenuItemCommandEvent) => {
    if (onCommand) {
      onCommand(e.item);
    }
  };

  const contextMenuModel: InstructionContextMenuItem[] = [
    {
      id: InstructionContextMenuItemIds.Edit,
      label: 'Открыть',
      command,
    },
    { separator: true },
    {
      id: InstructionContextMenuItemIds.Copy,
      label: 'Копировать',
      command,
    },
  ];

  return (
    <ContextMenu
      model={contextMenuModel}
      ref={ref}
      onHide={onHide}
      className={styles.contextMenu}
    />
  );
});

InstructionContextMenu.displayName = 'InstructionContextMenu';
