import { TabMenu } from 'shared_ui/components';

import { TabMenuElements } from 'shared/types/common';

import { useInstructionFormTabMenuStore } from './model/store';

interface InstructionFormTabMenuProps {
  onChooseCb?: (nextTab: string) => void | boolean | Promise<boolean | void>;
  elements: TabMenuElements[];
  initialTab: string;
}

export const InstructionFormTabMenu = ({
  onChooseCb,
  elements,
  initialTab,
}: InstructionFormTabMenuProps) => {
  const activeTab =
    useInstructionFormTabMenuStore(state => state.activeTab) ?? initialTab;
  const setActiveTab = useInstructionFormTabMenuStore(
    state => state.setActiveTab,
  );

  const handleTabChange = async (nextTab: string) => {
    const shouldProcess = await onChooseCb?.(nextTab);

    if (shouldProcess === false) return;

    setActiveTab(nextTab);
  };

  return (
    <TabMenu
      type="manual"
      elements={elements}
      active={activeTab}
      onChoose={handleTabChange}
    />
  );
};
