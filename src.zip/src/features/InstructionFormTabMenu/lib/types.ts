export type InstructionFormTabMenuStore = {
  activeTab?: string;
  setActiveTab: (activeTab: string) => void;
};
