import { create } from 'zustand';

import { InstructionFormTabMenuStore } from '../lib/types';

export const useInstructionFormTabMenuStore =
  create<InstructionFormTabMenuStore>()(set => ({
    setActiveTab: (activeTab: string) => set({ activeTab }),
  }));
