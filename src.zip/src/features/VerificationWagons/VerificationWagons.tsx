import clsx from 'clsx';
import {
  ShpFlight,
  useGetShpCarFlightsLazyQuery,
} from 'graphql/generated/generated';
import { FC, useEffect, useState } from 'react';

import { Loader, makeNotification } from 'shared_ui/components';

import {
  resetSelector,
  selectedSelector,
  setComparatorSelector,
  setSelectedSelector,
  setWagonDataSelector,
  wagonDataSelector,
} from './lib/selectors';
import { createComparator } from './lib/table';
import {
  getNonExistentWagons,
  getRequestVariables,
  mapDataToWagonData,
} from './lib/wagonData';
import { useExportingDataCook } from './model/useExportingDataCook';
import { useWagons } from './store';
import { CompareItem, ExportingData } from './types';
import { Footer } from './ui/Footer';
import { Table } from './ui/Table';
import styles from './VerificationWagons.module.scss';

type Props = {
  wagonNumbers: string[];
  fields: {
    station: CompareItem<number> | null;
    customer: CompareItem<number> | null;
  };
  className?: string;
  onSave: (data: ExportingData) => void;
};

const VerificationWagons: FC<Props> = ({
  wagonNumbers,
  fields,
  onSave,
  className,
}) => {
  const setWagonData = useWagons(setWagonDataSelector);
  const wagonData = useWagons(wagonDataSelector);
  const selected = useWagons(selectedSelector);
  const setSelected = useWagons(setSelectedSelector);
  const reset = useWagons(resetSelector);

  const setComparator = useWagons(setComparatorSelector);

  const { prepareExportingData } = useExportingDataCook();
  const [isSaving, setIsSaving] = useState(false);

  const [query, { loading: queryLoading }] = useGetShpCarFlightsLazyQuery({
    fetchPolicy: 'network-only',
  });

  const isLoading = queryLoading || isSaving;

  useEffect(() => {
    if (wagonNumbers.length === 0) {
      return;
    }

    let cancelled = false;

    reset();

    query({
      variables: getRequestVariables(wagonNumbers),
    }).then(({ data }) => {
      if (cancelled) {
        return;
      }

      const items = data?.shpCarFlights?.items
        ? data.shpCarFlights.items.reduce(
            (acc, item) => (item.flight ? [...acc, item.flight] : acc),
            [] as ShpFlight[],
          )
        : [];

      const mappedData = mapDataToWagonData(items);

      const nonExistentWagons = getNonExistentWagons(wagonNumbers)(mappedData);

      if (nonExistentWagons.length) {
        makeNotification({
          title: 'Несуществующие номера вагонов',
          message: nonExistentWagons.join(', '),
          variant: 'error',
        });
      }

      setWagonData(mappedData);
      setSelected(mappedData);

      const stationFromFields = fields.station;
      const customerFromFields = fields.customer;

      const stationFromQuery = {
        name: items[0]?.stationTo?.name || '',
        id: items[0]?.stationTo?.id || 0,
      };
      const customerFromQuery = {
        name: items[0]?.contract?.customer?.name || '',
        id: items[0]?.contract?.customer?.id || 0,
      };

      const mergedField = {
        station: stationFromFields || stationFromQuery,
        customer: customerFromFields || customerFromQuery,
      };

      setComparator(createComparator(mergedField));
    });

    return () => {
      cancelled = true;
      reset();
    };
  }, [wagonNumbers]);

  const onSaveHandler = async () => {
    setIsSaving(true);
    try {
      const data = await prepareExportingData(selected);
      onSave(data);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className={clsx(styles.main, className)}>
      <div className={clsx(styles.table)}>
        {isLoading && (
          <div className={styles.loaderOverlay}>
            <Loader variant="local" />
          </div>
        )}
        <Table value={wagonData} />
      </div>
      <div className={clsx(styles.footer)}>
        <Footer onSave={onSaveHandler} disabled={isLoading} />
      </div>
    </div>
  );
};

export { VerificationWagons };
