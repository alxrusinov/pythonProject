import {
  useGetNsiFreightsLazyQuery,
  useGetNsiGngFreights2001LazyQuery,
  useGetNsiStationsLazyQuery,
  useImpOrgPassportByIdLazyQuery,
} from 'graphql/generated/generated';

import { ExportingData, WagonData } from '../types';

type PrepareExportingData = (selected: WagonData[]) => Promise<ExportingData>;

type ReturnType = {
  prepareExportingData: PrepareExportingData;
};

type UseExportingDataCook = () => ReturnType;

const useExportingDataCook: UseExportingDataCook = () => {
  const [getStation] = useGetNsiStationsLazyQuery({
    fetchPolicy: 'network-only',
  });

  const [getOrg] = useImpOrgPassportByIdLazyQuery({
    fetchPolicy: 'network-only',
  });

  const [getFreight] = useGetNsiFreightsLazyQuery({
    fetchPolicy: 'network-only',
  });

  const [getFreightGng] = useGetNsiGngFreights2001LazyQuery({
    fetchPolicy: 'network-only',
  });

  const prepareExportingData: PrepareExportingData = async selected => {
    const selectedItem = selected[0];
    const senderStation = selectedItem.stationTo.id
      ? await getStation({
          variables: {
            where: { id: { eq: selectedItem.stationTo.id } },
            requestDate: new Date().toISOString(),
          },
        }).then(data => data.data?.nsiStations?.items?.[0] || null)
      : null;

    const client = selectedItem.contract.customer.id
      ? await getOrg({
          variables: {
            id: selectedItem.contract.customer.id,
            requestDate: new Date().toISOString(),
          },
        }).then(data => data.data?.impOrgPassportById || null)
      : null;

    const senderRecip = selectedItem.recipient.id
      ? await getOrg({
          variables: {
            id: selectedItem.recipient.id,
            requestDate: new Date().toISOString(),
          },
        }).then(data => data.data?.impOrgPassportById || null)
      : null;

    const customPrevFreight = selectedItem.freight.id
      ? await getFreight({
          variables: {
            where: { id: { eq: selectedItem.freight.id } },
            requestDate: new Date().toISOString(),
          },
        }).then(data => data.data?.nsiFreights?.items?.[0] || null)
      : null;

    const customPrevGngFreight = selectedItem.gngFreight.id
      ? await getFreightGng({
          variables: {
            where: {
              id: { eq: selectedItem.gngFreight.id },
            },
            requestDate: new Date().toISOString(),
          },
        }).then(data => data.data?.nsiGngFreights2001?.items?.[0] || null)
      : null;

    const result: ExportingData = {
      carNumbers: selected.map(({ carNumber }) => carNumber),
      senderStation,
      stationFromName: selectedItem?.stationFrom?.name || null,
      client,
      senderRecip,
      customPrevFreight,
      customPrevGngFreight,
    };

    return result;
  };

  return { prepareExportingData };
};

export { useExportingDataCook };
