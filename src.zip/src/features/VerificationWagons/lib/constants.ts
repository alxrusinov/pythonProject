import { ColumnsConfig } from '../types';

enum Status {
  INPUT = 'INPUT',
  READY = 'READY',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERRORS = 'ERRORS',
}

const ERROR_BG_STYLE = 'bg-red-200';
const SUCCESS_BG_STYLE = '';
const EMPTY_STRING = '';
const EMPTY_NUMBER = 0;

const Columns: ColumnsConfig = {
  carNumber: {
    header: 'Вагон',
    field: 'carNumber',
  },
  loadingStation: {
    header: 'Станция погрузки',
    field: 'stationFrom',
  },
  loadingRailway: {
    header: 'Дорога погрузки',
    field: 'stationFrom.railway',
  },
  station: {
    header: 'Станция выгрузки',
    field: 'stationTo',
  },
  railway: {
    header: 'Дорога выгрузки',
    field: 'stationTo.railway',
  },
  client: {
    header: 'Клиент',
    field: 'contract.customer',
  },
  recipient: {
    header: 'Грузополучатель',
    field: 'recipient',
  },
  freight: {
    header: 'Груз ЕТСНГ',
    field: 'freight',
  },
  gng: {
    header: 'Груз ГНГ',
    field: 'gngFreight',
  },
  empty: {
    header: 'Груженый',
    field: 'isEmpty',
  },
};

export {
  Status,
  ERROR_BG_STYLE,
  SUCCESS_BG_STYLE,
  EMPTY_NUMBER,
  EMPTY_STRING,
  Columns,
};
