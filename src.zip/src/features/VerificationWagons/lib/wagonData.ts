import {
  Exact,
  GetShpFlightsQuery,
  InputMaybe,
  Scalars,
  ShpCarFlightFilterInput,
} from 'graphql/generated/generated';

import { getStableRequestDate } from 'shared/utils/date';

import { WagonData } from '../types';

type RequestDataItem = NonNullable<
  NonNullable<GetShpFlightsQuery['shpFlights']>['items']
>[0];

type MapDataToWagonData = (items: RequestDataItem[]) => WagonData[];

const mapDataToWagonData: MapDataToWagonData = items => {
  const wagonNumbers = new Set<string>();

  return items.reduce<WagonData[]>((acc, value) => {
    const wagonNumber = value.carNumber;
    const stationFromRailway = (
      value.stationFrom as
        | {
            railway?: {
              id?: number | null;
              name?: string | null;
            } | null;
          }
        | null
        | undefined
    )?.railway;

    if (wagonNumber && !wagonNumbers.has(wagonNumber)) {
      wagonNumbers.add(wagonNumber);
      return [
        ...acc,
        {
          carNumber: value.carNumber || '',
          id: value.id || '',
          freight: {
            id: value.freight?.id || 0,
            codeEtsng: value.freight?.codeEtsng || '',
          },
          gngFreight: {
            id: value.gngFreight?.id || 0,
            code: value.gngFreight?.code || '',
          },
          isEmpty: Boolean(value.isEmpty),
          recipient: {
            id: value.recipient?.id || 0,
            name: value.recipient?.name || '',
          },
          stationFrom: {
            name: value.stationFrom?.name || '',
            id: value.stationFrom?.id || 0,
            railway: {
              id: stationFromRailway?.id || 0,
              name: stationFromRailway?.name || '',
            },
          },
          stationTo: {
            name: value.stationTo?.name || '',
            id: value.stationTo?.id || 0,
            railway: {
              id: value.stationTo?.railway?.id || 0,
              name: value.stationTo?.railway?.name || '',
            },
          },
          contract: {
            customer: {
              id: value?.contract?.customer?.id || 0,
              name: value?.contract?.customer?.name || '',
            },
          },
        },
      ];
    }
    return acc;
  }, [] as WagonData[]);
};

const getNonExistentWagons =
  (carNumbers: string[]) =>
  (data: WagonData[]): string[] => {
    const existsSet = new Set<string>(data.map(item => item.carNumber));

    return carNumbers.filter(item => !existsSet.has(item));
  };

type GetRequestVariables = (wagonNumbers: string[]) => Exact<{
  where?: InputMaybe<ShpCarFlightFilterInput>;
  requestDate?: InputMaybe<Scalars['DateTime']['input']>;
}>;

const getRequestVariables: GetRequestVariables = wagonNumbers => {
  return {
    requestDate: getStableRequestDate(),
    where: {
      and: [
        { flight: { effectiveFrom: { lte: getStableRequestDate() } } },
        { flight: { effectiveTo: { gt: getStableRequestDate() } } },
        { carNumber: { in: wagonNumbers } },
      ],
    },
  };
};

export { mapDataToWagonData, getRequestVariables, getNonExistentWagons };
