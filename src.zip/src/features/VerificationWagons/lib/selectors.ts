import { StoreType } from '../types';

// store selectors
const wagonDataSelector = (store: StoreType) => store.wagonData;
const comparatorSelector = (store: StoreType) => store.comparator;
const selectedSelector = (store: StoreType) => store.selected;

// action selectors
const setComparatorSelector = (store: StoreType) => store.setComparator;
const setWagonDataSelector = (store: StoreType) => store.setWagonData;
const setSelectedSelector = (store: StoreType) => store.setSelected;
const resetSelector = (store: StoreType) => store.reset;

export {
  wagonDataSelector,
  resetSelector,
  setWagonDataSelector,
  comparatorSelector,
  setComparatorSelector,
  selectedSelector,
  setSelectedSelector,
};
