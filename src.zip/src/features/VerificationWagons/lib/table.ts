import { CompareItem, FieldComparator, FieldForComparsion, Id } from '../types';
import {
  EMPTY_NUMBER,
  EMPTY_STRING,
  ERROR_BG_STYLE,
  SUCCESS_BG_STYLE,
} from './constants';

type CheckForErrors = (
  comparator: FieldComparator,
) => (data: { field: FieldForComparsion; value: string }) => string;

const createComparator = (fields: {
  station: CompareItem<number>;
  customer: CompareItem<number>;
}): FieldComparator => ({
  [FieldForComparsion.STATION]: fields.station,
  [FieldForComparsion.CUSTOMER]: fields.customer,
});

const isNumber = (value: Id): boolean => typeof value === 'number';

const isEmpty = (value: Id) =>
  isNumber(value) ? value === EMPTY_NUMBER : value === EMPTY_STRING;

const castStringToIdType =
  (comparedValue: Id) =>
  (value: string): Id =>
    isNumber(comparedValue) ? Number(value) : value;

const checkForErrors: CheckForErrors =
  comparator =>
  ({ field, value }) => {
    const comparedValue = comparator[field].id;
    if (isEmpty(comparedValue)) {
      return SUCCESS_BG_STYLE;
    }

    const castedValue = castStringToIdType(comparedValue)(value);
    return comparedValue !== castedValue ? ERROR_BG_STYLE : SUCCESS_BG_STYLE;
  };

export { checkForErrors, createComparator };
