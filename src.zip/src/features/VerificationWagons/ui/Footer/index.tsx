import clsx from 'clsx';
import { FC } from 'react';

import { Button } from 'shared_ui/components';

type Props = {
  disabled?: boolean;
  onSave: () => void;
};

const Footer: FC<Props> = ({ onSave, disabled }) => {
  return (
    <div
      className={clsx(
        'flex',
        'justify-content-end',
        'align-items-center',
        'gap-3',
      )}
    >
      <Button
        className="md:w-8rem"
        size="medium"
        type="button"
        variant="primary"
        onClick={onSave}
        disabled={disabled}
      >
        Сохранить
      </Button>
    </div>
  );
};

export { Footer };
