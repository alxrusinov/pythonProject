// import { GetShpFlightsQuery } from "graphql/generated/generated";
import { FC } from 'react';

import { CellRenderBoolean } from 'shared_ui/components';
import {
  Column,
  DataTable,
  DataTableSelectionMultipleChangeEvent,
} from 'shared_ui/primereact';

import { Columns } from 'features/VerificationWagons/lib/constants';
import {
  comparatorSelector,
  selectedSelector,
  setSelectedSelector,
} from 'features/VerificationWagons/lib/selectors';
import { checkForErrors } from 'features/VerificationWagons/lib/table';
import { useWagons } from 'features/VerificationWagons/store';
import {
  FieldForComparsion,
  WagonData,
} from 'features/VerificationWagons/types';

type Props = {
  value: WagonData[];
  className?: string;
};

const Table: FC<Props> = ({ value, className }) => {
  const comparator = useWagons(comparatorSelector);
  const selected = useWagons(selectedSelector);
  const setSelected = useWagons(setSelectedSelector);

  const onSelect = (e: DataTableSelectionMultipleChangeEvent<WagonData[]>) => {
    setSelected(e.value);
  };
  return (
    <div className={className}>
      <DataTable<WagonData[]>
        emptyMessage="Нет вагонов"
        style={{ minWidth: '1200px' }}
        selectionMode="multiple"
        value={value}
        selection={selected}
        onSelectionChange={onSelect}
        cellClassName={(data, options) => {
          return comparator && options.field in comparator
            ? checkForErrors(comparator)({
                field: options.field as FieldForComparsion,
                value: data?.id || 0,
              })
            : '';
        }}
        showGridlines
      >
        <Column selectionMode="multiple" />
        <Column
          header={Columns.carNumber.header}
          field={Columns.carNumber.field}
        />
        <Column
          header={Columns.loadingStation.header}
          field={Columns.loadingStation.field}
          body={({ stationFrom }) => stationFrom.name}
        />
        <Column
          header={Columns.loadingRailway.header}
          field={Columns.loadingRailway.field}
          body={({ stationFrom }) => stationFrom.railway.name}
        />
        <Column
          header={Columns.station.header}
          field={Columns.station.field}
          body={({ stationTo }) => stationTo.name}
        />
        <Column
          header={Columns.railway.header}
          field={Columns.railway.field}
          body={({ stationTo: { railway } }) => railway.name}
        />
        <Column
          header={Columns.client.header}
          field={Columns.client.field}
          body={({ contract: { customer } }) => customer.name}
        />
        <Column
          header={Columns.recipient.header}
          field={Columns.recipient.field}
          body={({ recipient }) => recipient.name}
        />
        <Column
          header={Columns.freight.header}
          field={Columns.freight.header}
          body={({ freight }) => freight.codeEtsng}
        />
        <Column
          header={Columns.gng.header}
          field={Columns.gng.field}
          body={({ gngFreight }) => gngFreight.code}
        />
        <Column
          header={Columns.empty.header}
          field={Columns.empty.field}
          body={({ isEmpty }) => <CellRenderBoolean value={!isEmpty} />}
        />
      </DataTable>
    </div>
  );
};

export { Table };
