import {
  ImpOrgPassport,
  NsiFreight,
  NsiGngFreight2001,
  NsiStation,
} from 'graphql/generated/generated';

type WagonInputTableItem = {
  wagonNumber: string;
};

type WagonInputTable = WagonInputTableItem[];

type StoreState = {
  wagonData: WagonData[];
  comparator: FieldComparator | null;
  selected: WagonData[];
};

type StoreAction = {
  setWagonData: (wagonData: WagonData[]) => void;
  setComparator: (comparator: FieldComparator) => void;
  setSelected: (selected: WagonData[]) => void;
  reset: () => void;
};

type StoreType = StoreState & StoreAction;

type WagonData = {
  carNumber: string;
  id: string;
  freight: {
    id: number;
    codeEtsng: string;
  };
  gngFreight: {
    id: number;
    code: string;
  };
  isEmpty: boolean;
  recipient: {
    id: number;
    name?: string;
  };
  stationFrom: {
    name: string;
    id: number;
    railway: {
      id: number;
      name: string;
    };
  };
  stationTo: {
    name: string;
    id: number;
    railway: {
      id: number;
      name: string;
    };
  };
  contract: {
    customer: {
      id: number;
      name: string;
    };
  };
};

type Id = string | number;

type CompareItem<T extends Id = string> = {
  name: string;
  id: T;
};

enum FieldForComparsion {
  STATION = 'stationTo',
  CUSTOMER = 'contract.customer',
}

type FieldComparator = Record<FieldForComparsion, CompareItem<Id>>;

type ExportingData = {
  carNumbers: string[];
  senderStation: NsiStation | null;
  stationFromName: string | null;
  client: ImpOrgPassport | null;
  senderRecip: ImpOrgPassport | null;
  customPrevFreight: NsiFreight | null;
  customPrevGngFreight: NsiGngFreight2001 | null;
};

type ColumnConfig = {
  header: string;
  field: string;
};

type ColumnName =
  | 'carNumber'
  | 'loadingStation'
  | 'loadingRailway'
  | 'station'
  | 'railway'
  | 'client'
  | 'recipient'
  | 'freight'
  | 'gng'
  | 'empty';

type ColumnsConfig = Record<ColumnName, ColumnConfig>;

export type {
  WagonInputTable,
  WagonInputTableItem,
  StoreType,
  StoreState,
  WagonData,
  FieldComparator,
  CompareItem,
  Id,
  ExportingData,
  ColumnsConfig,
};

export { FieldForComparsion };
