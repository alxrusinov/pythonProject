export { VerificationWagons } from './VerificationWagons';
export type { Id, CompareItem, WagonData, ExportingData } from './types';
