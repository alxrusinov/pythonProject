import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

import { StoreState, StoreType } from '../types';

const initialSttate: StoreState = {
  wagonData: [],
  comparator: null,
  selected: [],
};

const useWagons = create<StoreType>()(
  devtools(set => ({
    ...initialSttate,
    setWagonData: wagonData => {
      set({ wagonData });
    },
    setComparator: comparator => {
      set({ comparator });
    },
    setSelected: selected => {
      set({ selected });
    },
    reset: () => {
      set({ ...initialSttate });
    },
  })),
);

export { useWagons };
