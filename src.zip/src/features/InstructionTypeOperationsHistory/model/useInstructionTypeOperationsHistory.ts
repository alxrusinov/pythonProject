import { useInstructionTypeOperationsByIdQuery } from 'graphql/generated/generated';
import { useMemo } from 'react';

import { InstructionTypeModels } from 'shared/types/common';
import { transformData } from 'shared/utils/transformData';

export const useInstructionTypeOperationsHistory = (
  selectedInstruction: InstructionTypeModels | null,
  visible: boolean,
) => {
  const id = selectedInstruction?.id;

  const { data, loading } = useInstructionTypeOperationsByIdQuery({
    variables: { id: id || '' },
    skip: !id || !visible,
  });

  const transformedData = useMemo(
    () =>
      transformData({
        data: data?.ircInstructionTypes?.items || [],
      }),
    [data],
  );

  const timeFinish = 0;

  return { timeFinish, transformedData, loading };
};
