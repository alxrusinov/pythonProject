export { InstructionTypeOperationsHistory } from './ui/InstructionTypeOperationsHistory';
