import { ColumnsMetaDataType, DynamicRow } from './types';

export const columnsMetaData: ColumnsMetaDataType<DynamicRow>[] = [
  {
    field: 'operationName',
    header: 'Наименование операции',
    filter: false,
    sortable: false,
    type: 'string',
  },
  {
    field: 'startDateTime',
    header: 'Дата и время начала операции',
    filter: false,
    sortable: false,
    type: 'date',
  },
  {
    field: 'endDateTime',
    header: 'Дата и время окончания операции',
    filter: false,
    sortable: false,
    type: 'date',
  },
  {
    field: 'operationTime',
    header: 'Время выполнения операции',
    filter: false,
    sortable: false,
    type: 'time',
  },
  {
    field: 'operationResultName',
    header: 'Результат операции',
    filter: false,
    sortable: false,
    type: 'result',
  },
  {
    field: 'userName',
    header: 'ФИО пользователя',
    filter: false,
    sortable: false,
    type: 'string',
  },
];
