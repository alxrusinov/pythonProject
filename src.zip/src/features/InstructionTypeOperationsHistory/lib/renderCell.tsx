import { OperationStatus } from 'graphql/generated/generated';
import { ComponentProps, ReactNode } from 'react';

import { CellRenderDateTime, Tag } from 'shared_ui/components';

import { NoDataMark } from 'shared/ui/NoDataMark';

import { ColumnMetaType, RowDataType } from './types';

type TagColor = ComponentProps<typeof Tag>['color'];

const operationResultMap: Record<
  OperationStatus,
  { color: TagColor; label: string }
> = {
  [OperationStatus.Failure]: { color: 'red', label: 'Ошибка' },
  [OperationStatus.InProgress]: { color: 'yellow', label: 'В процессе' },
  [OperationStatus.InQueue]: { color: 'gray', label: 'Назначено' },
  [OperationStatus.NotActive]: { color: 'red', label: 'Недействительный' },
  [OperationStatus.Success]: { color: 'green', label: 'Успешно' },
};

const renderCellMap: Record<ColumnMetaType, (value: RowDataType) => ReactNode> =
  {
    string: value => value ?? <NoDataMark />,
    number: value => value ?? <NoDataMark />,
    time: value => value ?? <NoDataMark />,
    date: value =>
      ((value as unknown) instanceof Date ||
        typeof value === 'string' ||
        typeof value === 'number') &&
      typeof value !== 'boolean' ? (
        <CellRenderDateTime date={value} />
      ) : (
        <NoDataMark />
      ),
    result: value =>
      Object.values(OperationStatus).includes(value as OperationStatus) ? (
        <Tag
          color={operationResultMap[value as OperationStatus].color}
          label={operationResultMap[value as OperationStatus].label}
        />
      ) : (
        <NoDataMark />
      ),
  };

export const renderCell = (value: RowDataType, type: ColumnMetaType) => {
  return renderCellMap[type]?.(value) ?? <NoDataMark />;
};
