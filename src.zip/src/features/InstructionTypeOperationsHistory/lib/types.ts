import { OperationHistory, OperationStatus } from 'graphql/generated/generated';

import { ITableColumn } from 'shared_ui/components';

export type RowDataType = string | number | boolean | OperationStatus;
export type ColumnMetaType = 'string' | 'number' | 'date' | 'time' | 'result';

export type ColumnsMetaDataType<T> = ITableColumn & {
  field: Extract<keyof T, string>;
  type: ColumnMetaType;
};

export type DynamicRow = Record<keyof OperationHistory, RowDataType>;
