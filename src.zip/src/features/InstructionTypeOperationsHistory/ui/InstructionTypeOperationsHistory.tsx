import { Column, Modal, Table } from 'shared_ui/components';

import { InstructionTypeModels } from 'shared/types/common';

import { renderCell } from '../lib/renderCell';
import { columnsMetaData } from '../lib/tableMetaData';
import { useInstructionTypeOperationsHistory } from '../model/useInstructionTypeOperationsHistory';

interface InstructionTypeOperationsHistoryProps {
  visible: boolean;
  onClose: () => void;
  selectedInstruction: InstructionTypeModels | null;
}

export const InstructionTypeOperationsHistory = ({
  visible,
  onClose,
  selectedInstruction,
}: InstructionTypeOperationsHistoryProps) => {
  const { timeFinish, transformedData, loading } =
    useInstructionTypeOperationsHistory(selectedInstruction, visible);

  const footer = `Общее время: ${timeFinish ? timeFinish : 0}`;

  return (
    <Modal
      visible={visible}
      title="История операций"
      resizable={false}
      draggable={false}
      onClose={onClose}
      closeOnEscape
      textClose="Назад"
    >
      <Table
        tableClassName="white-space-nowrap"
        dataKey="id"
        emptyMessage="Нет доступных операций"
        rows={50}
        scrollable
        scrollHeight="calc(100vh - 400px)"
        showGridlines
        value={transformedData}
        footer={footer}
        loading={loading}
      >
        {columnsMetaData.map(({ field, header, type, ...rest }) => {
          return (
            <Column
              key={field}
              field={field}
              header={header}
              filter
              filterField={field}
              sortable
              body={rowData => renderCell(rowData[field], type)}
              {...rest}
            />
          );
        })}
      </Table>
    </Modal>
  );
};
