import { useLayoutEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';

import { useUser } from 'core_auth/hooks';
import { AuthProvider } from 'core_auth/providers';
import { useTranslation } from 'core_i18n/hooks';
import { LanguageProvider } from 'core_i18n/providers';

import { NotificationContainer, Progress } from 'shared_ui/components';
import { Theme } from 'shared_ui/theme';

import AppRouter from './AppRouter';
import './shared/styles/layout/layout.scss';

/**
 * That file is required for development purposes only.
 * It adds different wrappers and allows to develop app module independently
 * from container and layout layers
 */

const Main = () => {
  const user = useUser();
  const { i18n } = useTranslation();

  useLayoutEffect(() => {
    if (user?.locale) {
      void i18n.changeLanguage(user.locale);
    }
  }, [user, i18n]);

  return (
    <div className="layout-main">
      {/** Your app  */}
      <AppRouter />
    </div>
  );
};

const Container = () => {
  const { i18n } = useTranslation();

  return (
    <Theme locale={i18n.language}>
      {/**
       * Block to turn on toast notifications
       */}
      <NotificationContainer enableMultiContainer />
      {/**
       * Wrap to AuthProvider. It handles authorization flow
       */}
      <AuthProvider
        host={process.env.REACT_APP_API_GATEWAY ?? 'http://localhost:5000'}
        Logging={<Progress />}
      >
        <Main />
      </AuthProvider>
    </Theme>
  );
};

const container = document.getElementById('root');

if (!container) {
  throw new Error('Root is missing');
}
const root = createRoot(container);

root.render(
  <BrowserRouter>
    {/**
     * Wrap to language provider to define language preferences
     */}
    <LanguageProvider>
      <Container />
    </LanguageProvider>
  </BrowserRouter>,
);
