import { useApi } from 'core_auth/hooks';
import { GraphQLProvider } from 'core_client/providers';
import { TranslationProvider } from 'core_i18n/providers';

import { AppLayout } from 'shared/ui/AppLayout';

import { Routers } from './app/routers/Routers';

const AppRouter = () => {
  const api = useApi();

  return (
    <GraphQLProvider
      name={process.env.REACT_APP_NAME}
      httpOptions={{
        uri: process.env.REACT_APP_API_APOLLO,
        fetch: api.fetch,
      }}
      cacheConfig={{
        addTypename: false,
      }}
      wsOptions={{
        url:
          process.env.REACT_APP_API_APOLLO_WS ||
          'wss://tt-dev.nts.local/api/ws/',
      }}
    >
      <TranslationProvider
        name={process.env.REACT_APP_NAME ?? 'empty'}
        path={`${
          process.env.NODE_ENV === 'development'
            ? process.env.REACT_APP_HOST
            : process.env.PUBLIC_URL
        }/locales`}
      >
        <AppLayout>
          <Routers />
        </AppLayout>
      </TranslationProvider>
    </GraphQLProvider>
  );
};
export default AppRouter;
